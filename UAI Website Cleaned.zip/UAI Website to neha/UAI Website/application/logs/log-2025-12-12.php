<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-12-12 09:31:08 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated D:\UAI Website\system\core\URI.php 102
ERROR - 2025-12-12 09:31:08 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated D:\UAI Website\system\core\Router.php 128
ERROR - 2025-12-12 09:31:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2025-12-12 09:31:08 --> Severity: Warning --> include(D:\UAI Website\application\views\errors\html\error_404.php): Failed to open stream: No such file or directory D:\UAI Website\system\core\Exceptions.php 183
ERROR - 2025-12-12 09:31:08 --> Severity: Warning --> include(): Failed opening 'D:\UAI Website\application\views\errors\html\error_404.php' for inclusion (include_path='.;C:\php\pear') D:\UAI Website\system\core\Exceptions.php 183
ERROR - 2025-12-12 09:36:44 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated D:\UAI Website\system\core\URI.php 102
ERROR - 2025-12-12 09:36:44 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated D:\UAI Website\system\core\Router.php 128
ERROR - 2025-12-12 09:36:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2025-12-12 09:39:26 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated D:\UAI Website\system\core\URI.php 102
ERROR - 2025-12-12 09:39:26 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated D:\UAI Website\system\core\Router.php 128
ERROR - 2025-12-12 09:39:26 --> Severity: 8192 --> Creation of dynamic property Auth::$benchmark is deprecated D:\UAI Website\system\core\Controller.php 83
ERROR - 2025-12-12 09:39:26 --> Severity: 8192 --> Creation of dynamic property Auth::$hooks is deprecated D:\UAI Website\system\core\Controller.php 83
ERROR - 2025-12-12 09:39:26 --> Severity: 8192 --> Creation of dynamic property Auth::$config is deprecated D:\UAI Website\system\core\Controller.php 83
ERROR - 2025-12-12 09:39:26 --> Severity: 8192 --> Creation of dynamic property Auth::$log is deprecated D:\UAI Website\system\core\Controller.php 83
ERROR - 2025-12-12 09:39:26 --> Severity: 8192 --> Creation of dynamic property Auth::$utf8 is deprecated D:\UAI Website\system\core\Controller.php 83
ERROR - 2025-12-12 09:39:26 --> Severity: 8192 --> Creation of dynamic property Auth::$uri is deprecated D:\UAI Website\system\core\Controller.php 83
ERROR - 2025-12-12 09:39:26 --> Severity: 8192 --> Creation of dynamic property Auth::$exceptions is deprecated D:\UAI Website\system\core\Controller.php 83
ERROR - 2025-12-12 09:39:26 --> Severity: 8192 --> Creation of dynamic property Auth::$router is deprecated D:\UAI Website\system\core\Controller.php 83
ERROR - 2025-12-12 09:39:26 --> Severity: 8192 --> Creation of dynamic property Auth::$output is deprecated D:\UAI Website\system\core\Controller.php 83
ERROR - 2025-12-12 09:39:26 --> Severity: 8192 --> Creation of dynamic property Auth::$security is deprecated D:\UAI Website\system\core\Controller.php 83
ERROR - 2025-12-12 09:39:26 --> Severity: 8192 --> Creation of dynamic property Auth::$input is deprecated D:\UAI Website\system\core\Controller.php 83
ERROR - 2025-12-12 09:39:26 --> Severity: 8192 --> Creation of dynamic property Auth::$lang is deprecated D:\UAI Website\system\core\Controller.php 83
ERROR - 2025-12-12 09:39:27 --> Severity: 8192 --> Creation of dynamic property Auth::$db is deprecated D:\UAI Website\system\core\Loader.php 397
ERROR - 2025-12-12 09:39:27 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated D:\UAI Website\system\database\DB_driver.php 372
ERROR - 2025-12-12 09:39:27 --> Severity: error --> Exception: Class "mysqli_driver" not found D:\UAI Website\system\database\drivers\mysqli\mysqli_driver.php 123
ERROR - 2025-12-12 09:39:27 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\UAI Website\system\core\Exceptions.php:272) D:\UAI Website\system\core\Common.php 571
ERROR - 2025-12-12 09:39:27 --> Severity: Warning --> include(D:\UAI Website\application\views\errors\html\error_exception.php): Failed to open stream: No such file or directory D:\UAI Website\system\core\Exceptions.php 220
ERROR - 2025-12-12 09:39:27 --> Severity: Warning --> include(): Failed opening 'D:\UAI Website\application\views\errors\html\error_exception.php' for inclusion (include_path='.;C:\php\pear') D:\UAI Website\system\core\Exceptions.php 220
ERROR - 2025-12-12 09:39:45 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated D:\UAI Website\system\core\URI.php 102
ERROR - 2025-12-12 09:39:45 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated D:\UAI Website\system\core\Router.php 128
ERROR - 2025-12-12 09:39:45 --> Severity: 8192 --> Creation of dynamic property Auth::$benchmark is deprecated D:\UAI Website\system\core\Controller.php 83
ERROR - 2025-12-12 09:39:45 --> Severity: 8192 --> Creation of dynamic property Auth::$hooks is deprecated D:\UAI Website\system\core\Controller.php 83
ERROR - 2025-12-12 09:39:45 --> Severity: 8192 --> Creation of dynamic property Auth::$config is deprecated D:\UAI Website\system\core\Controller.php 83
ERROR - 2025-12-12 09:39:45 --> Severity: 8192 --> Creation of dynamic property Auth::$log is deprecated D:\UAI Website\system\core\Controller.php 83
ERROR - 2025-12-12 09:39:45 --> Severity: 8192 --> Creation of dynamic property Auth::$utf8 is deprecated D:\UAI Website\system\core\Controller.php 83
ERROR - 2025-12-12 09:39:45 --> Severity: 8192 --> Creation of dynamic property Auth::$uri is deprecated D:\UAI Website\system\core\Controller.php 83
ERROR - 2025-12-12 09:39:45 --> Severity: 8192 --> Creation of dynamic property Auth::$exceptions is deprecated D:\UAI Website\system\core\Controller.php 83
ERROR - 2025-12-12 09:39:45 --> Severity: 8192 --> Creation of dynamic property Auth::$router is deprecated D:\UAI Website\system\core\Controller.php 83
ERROR - 2025-12-12 09:39:45 --> Severity: 8192 --> Creation of dynamic property Auth::$output is deprecated D:\UAI Website\system\core\Controller.php 83
ERROR - 2025-12-12 09:39:45 --> Severity: 8192 --> Creation of dynamic property Auth::$security is deprecated D:\UAI Website\system\core\Controller.php 83
ERROR - 2025-12-12 09:39:45 --> Severity: 8192 --> Creation of dynamic property Auth::$input is deprecated D:\UAI Website\system\core\Controller.php 83
ERROR - 2025-12-12 09:39:45 --> Severity: 8192 --> Creation of dynamic property Auth::$lang is deprecated D:\UAI Website\system\core\Controller.php 83
ERROR - 2025-12-12 09:39:45 --> Severity: 8192 --> Creation of dynamic property Auth::$db is deprecated D:\UAI Website\system\core\Loader.php 397
ERROR - 2025-12-12 09:39:45 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated D:\UAI Website\system\database\DB_driver.php 372
ERROR - 2025-12-12 09:39:45 --> Severity: error --> Exception: Class "mysqli_driver" not found D:\UAI Website\system\database\drivers\mysqli\mysqli_driver.php 123
ERROR - 2025-12-12 09:39:45 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\UAI Website\system\core\Exceptions.php:272) D:\UAI Website\system\core\Common.php 571
ERROR - 2025-12-12 09:39:45 --> Severity: Warning --> include(D:\UAI Website\application\views\errors\html\error_exception.php): Failed to open stream: No such file or directory D:\UAI Website\system\core\Exceptions.php 220
ERROR - 2025-12-12 09:39:45 --> Severity: Warning --> include(): Failed opening 'D:\UAI Website\application\views\errors\html\error_exception.php' for inclusion (include_path='.;C:\php\pear') D:\UAI Website\system\core\Exceptions.php 220
ERROR - 2025-12-12 09:40:14 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated D:\UAI Website\system\core\URI.php 102
ERROR - 2025-12-12 09:40:14 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated D:\UAI Website\system\core\Router.php 128
ERROR - 2025-12-12 09:40:14 --> Severity: 8192 --> Creation of dynamic property Auth::$benchmark is deprecated D:\UAI Website\system\core\Controller.php 83
ERROR - 2025-12-12 09:40:14 --> Severity: 8192 --> Creation of dynamic property Auth::$hooks is deprecated D:\UAI Website\system\core\Controller.php 83
ERROR - 2025-12-12 09:40:14 --> Severity: 8192 --> Creation of dynamic property Auth::$config is deprecated D:\UAI Website\system\core\Controller.php 83
ERROR - 2025-12-12 09:40:14 --> Severity: 8192 --> Creation of dynamic property Auth::$log is deprecated D:\UAI Website\system\core\Controller.php 83
ERROR - 2025-12-12 09:40:14 --> Severity: 8192 --> Creation of dynamic property Auth::$utf8 is deprecated D:\UAI Website\system\core\Controller.php 83
ERROR - 2025-12-12 09:40:14 --> Severity: 8192 --> Creation of dynamic property Auth::$uri is deprecated D:\UAI Website\system\core\Controller.php 83
ERROR - 2025-12-12 09:40:14 --> Severity: 8192 --> Creation of dynamic property Auth::$exceptions is deprecated D:\UAI Website\system\core\Controller.php 83
ERROR - 2025-12-12 09:40:14 --> Severity: 8192 --> Creation of dynamic property Auth::$router is deprecated D:\UAI Website\system\core\Controller.php 83
ERROR - 2025-12-12 09:40:14 --> Severity: 8192 --> Creation of dynamic property Auth::$output is deprecated D:\UAI Website\system\core\Controller.php 83
ERROR - 2025-12-12 09:40:14 --> Severity: 8192 --> Creation of dynamic property Auth::$security is deprecated D:\UAI Website\system\core\Controller.php 83
ERROR - 2025-12-12 09:40:14 --> Severity: 8192 --> Creation of dynamic property Auth::$input is deprecated D:\UAI Website\system\core\Controller.php 83
ERROR - 2025-12-12 09:40:14 --> Severity: 8192 --> Creation of dynamic property Auth::$lang is deprecated D:\UAI Website\system\core\Controller.php 83
ERROR - 2025-12-12 09:40:14 --> Severity: 8192 --> Creation of dynamic property Auth::$db is deprecated D:\UAI Website\system\core\Loader.php 397
ERROR - 2025-12-12 09:40:14 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated D:\UAI Website\system\database\DB_driver.php 372
ERROR - 2025-12-12 09:40:14 --> Severity: error --> Exception: Class "mysqli_driver" not found D:\UAI Website\system\database\drivers\mysqli\mysqli_driver.php 123
ERROR - 2025-12-12 09:40:14 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\UAI Website\system\core\Exceptions.php:272) D:\UAI Website\system\core\Common.php 571
ERROR - 2025-12-12 09:40:14 --> Severity: Warning --> include(D:\UAI Website\application\views\errors\html\error_exception.php): Failed to open stream: No such file or directory D:\UAI Website\system\core\Exceptions.php 220
ERROR - 2025-12-12 09:40:14 --> Severity: Warning --> include(): Failed opening 'D:\UAI Website\application\views\errors\html\error_exception.php' for inclusion (include_path='.;C:\php\pear') D:\UAI Website\system\core\Exceptions.php 220
ERROR - 2025-12-12 09:41:02 --> Severity: error --> Exception: Class "mysqli_driver" not found D:\UAI Website\system\database\drivers\mysqli\mysqli_driver.php 123
ERROR - 2025-12-12 09:41:02 --> Severity: Warning --> include(D:\UAI Website\application\views\errors\html\error_exception.php): Failed to open stream: No such file or directory D:\UAI Website\system\core\Exceptions.php 220
ERROR - 2025-12-12 09:41:02 --> Severity: Warning --> include(): Failed opening 'D:\UAI Website\application\views\errors\html\error_exception.php' for inclusion (include_path='.;C:\php\pear') D:\UAI Website\system\core\Exceptions.php 220
ERROR - 2025-12-12 09:44:50 --> Severity: error --> Exception: Class "mysqli_driver" not found D:\UAI Website\system\database\drivers\mysqli\mysqli_driver.php 123
ERROR - 2025-12-12 09:50:40 --> Severity: Warning --> mkdir(): Invalid path D:\UAI Website\system\libraries\Session\drivers\Session_files_driver.php 137
ERROR - 2025-12-12 09:50:40 --> Session: Configured save path '' is not a directory, doesn't exist or cannot be created.
ERROR - 2025-12-12 09:50:40 --> Severity: Warning --> session_start(): Failed to initialize storage module: user (path: ) D:\UAI Website\system\libraries\Session\Session.php 137
ERROR - 2025-12-12 09:50:48 --> Severity: Warning --> mkdir(): Invalid path D:\UAI Website\system\libraries\Session\drivers\Session_files_driver.php 137
ERROR - 2025-12-12 09:50:48 --> Session: Configured save path '' is not a directory, doesn't exist or cannot be created.
ERROR - 2025-12-12 09:50:48 --> Severity: Warning --> session_start(): Failed to initialize storage module: user (path: ) D:\UAI Website\system\libraries\Session\Session.php 137
ERROR - 2025-12-12 09:52:50 --> Severity: Warning --> mkdir(): Invalid path D:\UAI Website\system\libraries\Session\drivers\Session_files_driver.php 137
ERROR - 2025-12-12 09:52:50 --> Session: Configured save path '' is not a directory, doesn't exist or cannot be created.
ERROR - 2025-12-12 09:52:50 --> Severity: Warning --> session_start(): Failed to initialize storage module: user (path: ) D:\UAI Website\system\libraries\Session\Session.php 137
ERROR - 2025-12-12 09:53:03 --> Severity: Warning --> mkdir(): Invalid path D:\UAI Website\system\libraries\Session\drivers\Session_files_driver.php 137
ERROR - 2025-12-12 09:53:03 --> Session: Configured save path '' is not a directory, doesn't exist or cannot be created.
ERROR - 2025-12-12 09:53:03 --> Severity: Warning --> session_start(): Failed to initialize storage module: user (path: ) D:\UAI Website\system\libraries\Session\Session.php 137
ERROR - 2025-12-12 09:53:43 --> Severity: Warning --> mkdir(): Invalid path D:\UAI Website\system\libraries\Session\drivers\Session_files_driver.php 137
ERROR - 2025-12-12 09:53:43 --> Session: Configured save path '' is not a directory, doesn't exist or cannot be created.
ERROR - 2025-12-12 09:53:43 --> Severity: Warning --> session_start(): Failed to initialize storage module: user (path: ) D:\UAI Website\system\libraries\Session\Session.php 137
ERROR - 2025-12-12 09:57:01 --> Severity: Warning --> mkdir(): Invalid path D:\UAI Website\system\libraries\Session\drivers\Session_files_driver.php 137
ERROR - 2025-12-12 09:57:01 --> Session: Configured save path '' is not a directory, doesn't exist or cannot be created.
ERROR - 2025-12-12 09:57:01 --> Severity: Warning --> session_start(): Failed to initialize storage module: user (path: ) D:\UAI Website\system\libraries\Session\Session.php 137
ERROR - 2025-12-12 09:59:57 --> Severity: Warning --> mkdir(): Invalid path D:\UAI Website\system\libraries\Session\drivers\Session_files_driver.php 137
ERROR - 2025-12-12 09:59:57 --> Session: Configured save path '' is not a directory, doesn't exist or cannot be created.
ERROR - 2025-12-12 09:59:57 --> Severity: Warning --> session_start(): Failed to initialize storage module: user (path: ) D:\UAI Website\system\libraries\Session\Session.php 137
ERROR - 2025-12-12 10:05:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2025-12-12 10:11:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2025-12-12 10:13:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2025-12-12 10:14:17 --> 404 Page Not Found: Working_portal/index
ERROR - 2025-12-12 10:27:19 --> Severity: error --> Exception: Class "Simple_Controller" not found D:\UAI Website\application\controllers\Portal.php 8
ERROR - 2025-12-12 10:27:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2025-12-12 10:28:35 --> Severity: error --> Exception: Class "Simple_Controller" not found D:\UAI Website\application\controllers\Portal.php 8
ERROR - 2025-12-12 10:28:39 --> Severity: error --> Exception: Class "Simple_Controller" not found D:\UAI Website\application\controllers\Portal.php 8
