<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-12-23 05:41:42 --> 404 Page Not Found: Simple_portal/resource_management
