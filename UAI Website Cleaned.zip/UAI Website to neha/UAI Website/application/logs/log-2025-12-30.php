<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-12-30 08:52:56 --> 404 Page Not Found: Simple_portal/faculty_dashboard
ERROR - 2025-12-30 09:17:22 --> 404 Page Not Found: Simple_portal/faculty_dashboard
ERROR - 2025-12-30 09:29:12 --> 404 Page Not Found: Simple_portal/faculty_dashboard
ERROR - 2025-12-30 09:37:42 --> Severity: error --> Exception: Call to undefined function formatFileSize() C:\Users\nehas\Downloads\UAI Website AI Questions-mid (1)\UAI Website AI Questions-final\UAI Website\application\views\simple_portal\resource_management.php 1268
ERROR - 2025-12-30 09:37:52 --> Severity: error --> Exception: Call to undefined function formatFileSize() C:\Users\nehas\Downloads\UAI Website AI Questions-mid (1)\UAI Website AI Questions-final\UAI Website\application\views\simple_portal\resource_management.php 1268
