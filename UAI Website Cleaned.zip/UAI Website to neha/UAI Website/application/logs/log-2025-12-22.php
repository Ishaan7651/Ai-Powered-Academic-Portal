<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-12-22 18:40:02 --> 404 Page Not Found: Simple_portal/resource_management
