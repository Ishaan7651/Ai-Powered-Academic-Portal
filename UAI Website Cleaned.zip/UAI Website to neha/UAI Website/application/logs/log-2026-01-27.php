<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2026-01-27 07:27:48 --> 404 Page Not Found: Faviconico/index
