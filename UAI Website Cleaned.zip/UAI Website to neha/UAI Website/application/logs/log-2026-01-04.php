<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2026-01-04 09:21:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2026-01-04 09:26:11 --> Severity: Warning --> Undefined array key "name" D:\Versions\UAI App\Neha's Version\FInal final\UAI Website\application\libraries\AI_service.php 707
ERROR - 2026-01-04 09:26:11 --> Severity: Warning --> Undefined array key "name" D:\Versions\UAI App\Neha's Version\FInal final\UAI Website\application\libraries\AI_service.php 707
ERROR - 2026-01-04 09:26:11 --> Severity: Warning --> Undefined array key "name" D:\Versions\UAI App\Neha's Version\FInal final\UAI Website\application\libraries\AI_service.php 707
ERROR - 2026-01-04 09:45:17 --> Severity: Warning --> Undefined array key "name" D:\Versions\UAI App\Neha's Version\FInal final\UAI Website\application\libraries\AI_service.php 732
ERROR - 2026-01-04 09:45:17 --> Severity: Warning --> Undefined array key "name" D:\Versions\UAI App\Neha's Version\FInal final\UAI Website\application\libraries\AI_service.php 732
ERROR - 2026-01-04 09:45:17 --> Severity: Warning --> Undefined array key "name" D:\Versions\UAI App\Neha's Version\FInal final\UAI Website\application\libraries\AI_service.php 732
ERROR - 2026-01-04 09:58:10 --> 404 Page Not Found: Ai_buddy/dashboard
ERROR - 2026-01-04 19:03:18 --> 404 Page Not Found: Simple_portal/subject_resources
ERROR - 2026-01-04 19:03:23 --> Severity: error --> Exception: Call to undefined function formatFileSize() D:\Versions\UAI App\Neha's Version\FInal final\UAI Website\application\views\simple_portal\resource_management.php 1268
ERROR - 2026-01-04 19:22:06 --> Severity: error --> Exception: Call to undefined function formatFileSize() D:\Versions\UAI App\Neha's Version\FInal final\UAI Website\application\views\simple_portal\resource_management.php 1268
ERROR - 2026-01-04 19:55:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2026-01-04 19:55:51 --> 404 Page Not Found: Simple_portal/my_students
ERROR - 2026-01-04 19:56:00 --> Severity: error --> Exception: Call to undefined function formatFileSize() D:\Versions\UAI App\Neha's Version\FInal final\UAI Website\application\views\simple_portal\resource_management.php 1268
