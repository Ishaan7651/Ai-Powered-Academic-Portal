<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2026-01-05 08:58:14 --> 404 Page Not Found: Ai_buddy/dashboard
ERROR - 2026-01-05 19:00:45 --> Severity: error --> Exception: syntax error, unexpected token "public", expecting end of file D:\Versions\UAI App\Neha's Version\FInal final\UAI Website\application\controllers\AI_buddy.php 1102
ERROR - 2026-01-05 19:00:50 --> Severity: error --> Exception: syntax error, unexpected token "public", expecting end of file D:\Versions\UAI App\Neha's Version\FInal final\UAI Website\application\controllers\AI_buddy.php 1102
ERROR - 2026-01-05 19:00:54 --> Severity: error --> Exception: syntax error, unexpected token "public", expecting end of file D:\Versions\UAI App\Neha's Version\FInal final\UAI Website\application\controllers\AI_buddy.php 1102
ERROR - 2026-01-05 19:12:20 --> Severity: error --> Exception: Unable to locate the model you have specified: User_model D:\Versions\UAI App\Neha's Version\FInal final\UAI Website\system\core\Loader.php 349
ERROR - 2026-01-05 19:28:36 --> 404 Page Not Found: Ai_buddy/dashboard
ERROR - 2026-01-05 20:16:11 --> Severity: error --> Exception: Unable to locate the model you have specified: User_model D:\Versions\UAI App\Neha's Version\FInal final\UAI Website\system\core\Loader.php 349
ERROR - 2026-01-05 20:19:16 --> Severity: Warning --> Undefined property: stdClass::$question_count D:\Versions\UAI App\Neha's Version\FInal final\UAI Website\application\views\simple_portal\student_quizzes.php 438
ERROR - 2026-01-05 20:19:16 --> Severity: Warning --> Undefined property: stdClass::$question_count D:\Versions\UAI App\Neha's Version\FInal final\UAI Website\application\views\simple_portal\student_quizzes.php 457
ERROR - 2026-01-05 20:19:16 --> Severity: Warning --> Undefined property: stdClass::$duration_minutes D:\Versions\UAI App\Neha's Version\FInal final\UAI Website\application\views\simple_portal\student_quizzes.php 461
ERROR - 2026-01-05 20:27:22 --> Severity: Warning --> Undefined property: stdClass::$question_count D:\Versions\UAI App\Neha's Version\FInal final\UAI Website\application\views\simple_portal\student_quizzes.php 438
ERROR - 2026-01-05 20:27:25 --> Severity: Warning --> Undefined property: stdClass::$content D:\Versions\UAI App\Neha's Version\FInal final\UAI Website\application\controllers\Simple_portal.php 1976
ERROR - 2026-01-05 20:27:43 --> Severity: Warning --> Undefined property: stdClass::$question_count D:\Versions\UAI App\Neha's Version\FInal final\UAI Website\application\views\simple_portal\student_quizzes.php 438
ERROR - 2026-01-05 20:39:47 --> Severity: Warning --> Undefined property: stdClass::$question_count D:\Versions\UAI App\Neha's Version\FInal final\UAI Website\application\views\simple_portal\student_quizzes.php 438
ERROR - 2026-01-05 20:39:48 --> Severity: Warning --> Undefined property: stdClass::$question_count D:\Versions\UAI App\Neha's Version\FInal final\UAI Website\application\views\simple_portal\student_quizzes.php 438
ERROR - 2026-01-05 20:39:49 --> Severity: Warning --> Undefined property: stdClass::$question_count D:\Versions\UAI App\Neha's Version\FInal final\UAI Website\application\views\simple_portal\student_quizzes.php 438
ERROR - 2026-01-05 20:39:50 --> Severity: Warning --> Undefined property: stdClass::$question_count D:\Versions\UAI App\Neha's Version\FInal final\UAI Website\application\views\simple_portal\student_quizzes.php 438
ERROR - 2026-01-05 20:39:58 --> Severity: Warning --> Undefined property: stdClass::$question_count D:\Versions\UAI App\Neha's Version\FInal final\UAI Website\application\views\simple_portal\student_quizzes.php 438
ERROR - 2026-01-05 20:40:15 --> Severity: Warning --> Undefined property: stdClass::$question_count D:\Versions\UAI App\Neha's Version\FInal final\UAI Website\application\views\simple_portal\student_quizzes.php 438
ERROR - 2026-01-05 20:40:18 --> Severity: Warning --> Undefined property: stdClass::$question_count D:\Versions\UAI App\Neha's Version\FInal final\UAI Website\application\views\simple_portal\student_quizzes.php 438
ERROR - 2026-01-05 20:40:21 --> Severity: Warning --> Undefined property: stdClass::$question_count D:\Versions\UAI App\Neha's Version\FInal final\UAI Website\application\views\simple_portal\student_quizzes.php 438
ERROR - 2026-01-05 20:40:24 --> Severity: Warning --> Undefined property: stdClass::$question_count D:\Versions\UAI App\Neha's Version\FInal final\UAI Website\application\views\simple_portal\student_quizzes.php 438
ERROR - 2026-01-05 20:40:27 --> Severity: Warning --> Undefined property: stdClass::$question_count D:\Versions\UAI App\Neha's Version\FInal final\UAI Website\application\views\simple_portal\student_quizzes.php 438
ERROR - 2026-01-05 21:57:36 --> Severity: Warning --> Undefined property: stdClass::$question_count D:\Versions\UAI App\Neha's Version\FInal final\UAI Website\application\views\simple_portal\student_quizzes.php 438
ERROR - 2026-01-05 21:57:37 --> Severity: Warning --> Undefined property: stdClass::$question_count D:\Versions\UAI App\Neha's Version\FInal final\UAI Website\application\views\simple_portal\student_quizzes.php 438
ERROR - 2026-01-05 21:57:38 --> Severity: Warning --> Undefined property: stdClass::$question_count D:\Versions\UAI App\Neha's Version\FInal final\UAI Website\application\views\simple_portal\student_quizzes.php 438
ERROR - 2026-01-05 21:57:38 --> Severity: Warning --> Undefined property: stdClass::$question_count D:\Versions\UAI App\Neha's Version\FInal final\UAI Website\application\views\simple_portal\student_quizzes.php 438
ERROR - 2026-01-05 21:57:39 --> Severity: Warning --> Undefined property: stdClass::$question_count D:\Versions\UAI App\Neha's Version\FInal final\UAI Website\application\views\simple_portal\student_quizzes.php 438
ERROR - 2026-01-05 21:57:48 --> Severity: Warning --> Undefined property: stdClass::$question_count D:\Versions\UAI App\Neha's Version\FInal final\UAI Website\application\views\simple_portal\student_quizzes.php 438
ERROR - 2026-01-05 22:03:24 --> Severity: Warning --> Undefined property: stdClass::$question_count D:\Versions\UAI App\Neha's Version\FInal final\UAI Website\application\views\simple_portal\student_quizzes.php 446
ERROR - 2026-01-05 22:03:36 --> Severity: Warning --> Undefined property: stdClass::$question_count D:\Versions\UAI App\Neha's Version\FInal final\UAI Website\application\views\simple_portal\student_quizzes.php 446
ERROR - 2026-01-05 22:03:38 --> Severity: Warning --> Undefined property: stdClass::$question_count D:\Versions\UAI App\Neha's Version\FInal final\UAI Website\application\views\simple_portal\student_quizzes.php 446
ERROR - 2026-01-05 22:03:41 --> Severity: Warning --> Undefined property: stdClass::$question_count D:\Versions\UAI App\Neha's Version\FInal final\UAI Website\application\views\simple_portal\student_quizzes.php 446
ERROR - 2026-01-05 22:03:43 --> Severity: Warning --> Undefined property: stdClass::$question_count D:\Versions\UAI App\Neha's Version\FInal final\UAI Website\application\views\simple_portal\student_quizzes.php 446
