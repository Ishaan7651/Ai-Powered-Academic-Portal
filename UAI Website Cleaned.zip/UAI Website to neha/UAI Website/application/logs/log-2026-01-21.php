<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2026-01-21 07:25:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2026-01-21 07:27:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2026-01-21 07:28:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2026-01-21 09:15:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2026-01-21 09:16:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2026-01-21 09:16:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2026-01-21 09:26:16 --> 404 Page Not Found: Ai_buddy/dashboard
ERROR - 2026-01-21 15:15:47 --> Severity: error --> Exception: Unable to locate the model you have specified: User_model D:\Versions\Deployed\UAI Website to neha\UAI Website\system\core\Loader.php 349
ERROR - 2026-01-21 15:15:59 --> Severity: error --> Exception: Unable to locate the model you have specified: User_model D:\Versions\Deployed\UAI Website to neha\UAI Website\system\core\Loader.php 349
