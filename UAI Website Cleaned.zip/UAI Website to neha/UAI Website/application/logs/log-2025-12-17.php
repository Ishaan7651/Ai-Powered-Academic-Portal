<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-12-17 06:12:39 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it C:\Users\nehas\Downloads\UAI Website Simple Portal\UAI Website\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2025-12-17 06:12:39 --> Unable to connect to the database
