<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2026-01-06 04:55:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2026-01-06 04:56:06 --> Severity: Warning --> Undefined property: stdClass::$question_count D:\Versions\UAI App\Neha's Version\FInal final\UAI Website\application\views\simple_portal\student_quizzes.php 446
ERROR - 2026-01-06 04:56:16 --> Severity: Warning --> Undefined property: stdClass::$question_count D:\Versions\UAI App\Neha's Version\FInal final\UAI Website\application\views\simple_portal\student_quizzes.php 446
ERROR - 2026-01-06 04:56:20 --> Severity: Warning --> Undefined property: stdClass::$question_count D:\Versions\UAI App\Neha's Version\FInal final\UAI Website\application\views\simple_portal\student_quizzes.php 446
ERROR - 2026-01-06 04:56:24 --> Severity: Warning --> Undefined property: stdClass::$question_count D:\Versions\UAI App\Neha's Version\FInal final\UAI Website\application\views\simple_portal\student_quizzes.php 446
ERROR - 2026-01-06 05:04:26 --> Severity: Warning --> Undefined property: stdClass::$question_count D:\Versions\UAI App\Neha's Version\FInal final\UAI Website\application\views\simple_portal\student_quizzes.php 446
ERROR - 2026-01-06 05:09:07 --> 404 Page Not Found: Ai_buddy/dashboard
ERROR - 2026-01-06 05:09:14 --> 404 Page Not Found: Ai_buddy/dashboard
ERROR - 2026-01-06 05:09:19 --> 404 Page Not Found: Ai_buddy/dashboard
ERROR - 2026-01-06 05:09:32 --> 404 Page Not Found: Ai_buddy/dashboard
ERROR - 2026-01-06 05:10:21 --> Gemini API error (HTTP 400): {
  "error": {
    "code": 400,
    "message": "* GenerateContentRequest.contents: contents is not specified\n",
    "status": "INVALID_ARGUMENT"
  }
}

ERROR - 2026-01-06 06:51:53 --> Gemini API error (HTTP 400): {
  "error": {
    "code": 400,
    "message": "* GenerateContentRequest.contents: contents is not specified\n",
    "status": "INVALID_ARGUMENT"
  }
}

ERROR - 2026-01-06 06:51:53 --> Attempt 1 failed with error: AI service error (HTTP 400). Please try again later.
ERROR - 2026-01-06 06:51:54 --> Gemini API error (HTTP 400): {
  "error": {
    "code": 400,
    "message": "* GenerateContentRequest.contents: contents is not specified\n",
    "status": "INVALID_ARGUMENT"
  }
}

ERROR - 2026-01-06 06:51:54 --> Attempt 2 failed with error: AI service error (HTTP 400). Please try again later.
ERROR - 2026-01-06 06:51:55 --> Gemini API error (HTTP 400): {
  "error": {
    "code": 400,
    "message": "* GenerateContentRequest.contents: contents is not specified\n",
    "status": "INVALID_ARGUMENT"
  }
}

ERROR - 2026-01-06 06:51:55 --> Attempt 3 failed with error: AI service error (HTTP 400). Please try again later.
ERROR - 2026-01-06 06:54:44 --> Severity: error --> Exception: Unable to locate the model you have specified: User_model D:\Versions\UAI App\Neha's Version\FInal final\UAI Website\system\core\Loader.php 349
ERROR - 2026-01-06 06:55:02 --> Severity: Warning --> Undefined property: stdClass::$question_count D:\Versions\UAI App\Neha's Version\FInal final\UAI Website\application\views\simple_portal\student_quizzes.php 446
ERROR - 2026-01-06 06:55:02 --> Severity: Warning --> Undefined property: stdClass::$question_count D:\Versions\UAI App\Neha's Version\FInal final\UAI Website\application\views\simple_portal\student_quizzes.php 446
ERROR - 2026-01-06 06:56:18 --> Severity: Warning --> Undefined property: stdClass::$question_count D:\Versions\UAI App\Neha's Version\FInal final\UAI Website\application\views\simple_portal\student_quizzes.php 446
ERROR - 2026-01-06 06:56:18 --> Severity: Warning --> Undefined property: stdClass::$question_count D:\Versions\UAI App\Neha's Version\FInal final\UAI Website\application\views\simple_portal\student_quizzes.php 446
ERROR - 2026-01-06 06:56:56 --> Severity: Warning --> Undefined property: stdClass::$question_count D:\Versions\UAI App\Neha's Version\FInal final\UAI Website\application\views\simple_portal\student_quizzes.php 446
ERROR - 2026-01-06 06:56:56 --> Severity: Warning --> Undefined property: stdClass::$question_count D:\Versions\UAI App\Neha's Version\FInal final\UAI Website\application\views\simple_portal\student_quizzes.php 446
ERROR - 2026-01-06 06:58:52 --> Severity: Warning --> Undefined property: stdClass::$content D:\Versions\UAI App\Neha's Version\FInal final\UAI Website\application\views\simple_portal\view_question_paper.php 286
ERROR - 2026-01-06 06:59:02 --> Severity: Warning --> Undefined property: stdClass::$content D:\Versions\UAI App\Neha's Version\FInal final\UAI Website\application\controllers\Simple_portal.php 1823
ERROR - 2026-01-06 07:40:02 --> Severity: error --> Exception: Unable to locate the model you have specified: User_model D:\Versions\UAI App\Neha's Version\FInal final\UAI Website\system\core\Loader.php 349
ERROR - 2026-01-06 07:40:33 --> Severity: Warning --> Undefined property: stdClass::$question_count D:\Versions\UAI App\Neha's Version\FInal final\UAI Website\application\views\simple_portal\student_quizzes.php 446
ERROR - 2026-01-06 07:40:33 --> Severity: Warning --> Undefined property: stdClass::$question_count D:\Versions\UAI App\Neha's Version\FInal final\UAI Website\application\views\simple_portal\student_quizzes.php 446
ERROR - 2026-01-06 07:43:01 --> 404 Page Not Found: Ai_buddy/session
ERROR - 2026-01-06 08:46:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2026-01-06 08:53:11 --> Severity: Warning --> Undefined property: stdClass::$question_count D:\Versions\UAI App\Neha's Version\FInal final\UAI Website\application\views\simple_portal\student_quizzes.php 446
ERROR - 2026-01-06 08:53:11 --> Severity: Warning --> Undefined property: stdClass::$question_count D:\Versions\UAI App\Neha's Version\FInal final\UAI Website\application\views\simple_portal\student_quizzes.php 446
ERROR - 2026-01-06 08:54:20 --> Severity: error --> Exception: Unable to locate the model you have specified: User_model D:\Versions\UAI App\Neha's Version\FInal final\UAI Website\system\core\Loader.php 349
ERROR - 2026-01-06 09:01:48 --> Severity: Warning --> Undefined property: stdClass::$question_count D:\Versions\UAI App\Neha's Version\FInal final\UAI Website\application\views\simple_portal\student_quizzes.php 446
ERROR - 2026-01-06 09:01:48 --> Severity: Warning --> Undefined property: stdClass::$question_count D:\Versions\UAI App\Neha's Version\FInal final\UAI Website\application\views\simple_portal\student_quizzes.php 446
ERROR - 2026-01-06 09:01:48 --> Severity: Warning --> Undefined property: stdClass::$question_count D:\Versions\UAI App\Neha's Version\FInal final\UAI Website\application\views\simple_portal\student_quizzes.php 446
ERROR - 2026-01-06 09:02:13 --> Severity: Warning --> Undefined property: stdClass::$question_count D:\Versions\UAI App\Neha's Version\FInal final\UAI Website\application\views\simple_portal\student_quizzes.php 446
ERROR - 2026-01-06 09:02:13 --> Severity: Warning --> Undefined property: stdClass::$question_count D:\Versions\UAI App\Neha's Version\FInal final\UAI Website\application\views\simple_portal\student_quizzes.php 446
ERROR - 2026-01-06 09:02:13 --> Severity: Warning --> Undefined property: stdClass::$question_count D:\Versions\UAI App\Neha's Version\FInal final\UAI Website\application\views\simple_portal\student_quizzes.php 446
ERROR - 2026-01-06 09:30:27 --> 404 Page Not Found: Simple_portal/subject_resources
ERROR - 2026-01-06 09:31:53 --> 404 Page Not Found: Simple_portal/faculty_dashboard
ERROR - 2026-01-06 09:38:05 --> 404 Page Not Found: Ai_buddy/dashboard
ERROR - 2026-01-06 09:38:08 --> 404 Page Not Found: Ai_buddy/dashboard
ERROR - 2026-01-06 09:38:39 --> 404 Page Not Found: Ai_buddy/dashboard
ERROR - 2026-01-06 09:39:18 --> 404 Page Not Found: Ai_buddy/dashboard
ERROR - 2026-01-06 09:39:20 --> 404 Page Not Found: Ai_buddy/dashboard
ERROR - 2026-01-06 09:39:45 --> Gemini API error (HTTP 400): {
  "error": {
    "code": 400,
    "message": "* GenerateContentRequest.contents: contents is not specified\n",
    "status": "INVALID_ARGUMENT"
  }
}

ERROR - 2026-01-06 09:49:19 --> 404 Page Not Found: Ai_buddy/dashboard
ERROR - 2026-01-06 09:50:55 --> Gemini API error (HTTP 400): {
  "error": {
    "code": 400,
    "message": "* GenerateContentRequest.contents: contents is not specified\n",
    "status": "INVALID_ARGUMENT"
  }
}

ERROR - 2026-01-06 09:57:12 --> Gemini API error (HTTP 400): {
  "error": {
    "code": 400,
    "message": "* GenerateContentRequest.contents: contents is not specified\n",
    "status": "INVALID_ARGUMENT"
  }
}

ERROR - 2026-01-06 09:57:58 --> Gemini API error (HTTP 400): {
  "error": {
    "code": 400,
    "message": "* GenerateContentRequest.contents: contents is not specified\n",
    "status": "INVALID_ARGUMENT"
  }
}

ERROR - 2026-01-06 10:11:40 --> Gemini API error (HTTP 400): {
  "error": {
    "code": 400,
    "message": "* GenerateContentRequest.contents: contents is not specified\n",
    "status": "INVALID_ARGUMENT"
  }
}

ERROR - 2026-01-06 10:12:19 --> Gemini API error (HTTP 400): {
  "error": {
    "code": 400,
    "message": "* GenerateContentRequest.contents: contents is not specified\n",
    "status": "INVALID_ARGUMENT"
  }
}

ERROR - 2026-01-06 10:16:14 --> AI CHAT DEBUG: Starting chat with 1 messages, system_prompt: YES
ERROR - 2026-01-06 10:16:14 --> AI CHAT DEBUG: Added system prompt, length: 3086
ERROR - 2026-01-06 10:16:14 --> AI CHAT DEBUG: Message 0 is object, role: user, has content: YES
ERROR - 2026-01-06 10:16:14 --> AI CHAT DEBUG: Added message 0 to formatted_messages
ERROR - 2026-01-06 10:16:14 --> AI CHAT DEBUG: Total formatted messages: 2
ERROR - 2026-01-06 10:16:14 --> AI API DEBUG: Received 2 messages to process
ERROR - 2026-01-06 10:16:14 --> AI API DEBUG: Found system message, length: 3086
ERROR - 2026-01-06 10:16:14 --> AI API DEBUG: Added user message, length: 15
ERROR - 2026-01-06 10:16:14 --> AI API DEBUG: After initial processing, contents count: 1
ERROR - 2026-01-06 10:16:14 --> AI API DEBUG: After filtering, contents count: 1
ERROR - 2026-01-06 10:16:14 --> AI API DEBUG: Prepended system instruction. Original: 15, New: 3103
ERROR - 2026-01-06 10:16:14 --> AI API DEBUG: Final contents count before sending: 1
ERROR - 2026-01-06 10:16:14 --> AI API DEBUG: Contents structure: [{"role":"user","text_length":3103}]
ERROR - 2026-01-06 10:16:14 --> AI API DEBUG: Data structure to send: {"contents_count":1}
ERROR - 2026-01-06 10:16:14 --> Gemini API error (HTTP 400): {
  "error": {
    "code": 400,
    "message": "* GenerateContentRequest.contents: contents is not specified\n",
    "status": "INVALID_ARGUMENT"
  }
}

ERROR - 2026-01-06 10:21:24 --> AI CHAT DEBUG: Starting chat with 1 messages, system_prompt: YES
ERROR - 2026-01-06 10:21:24 --> AI CHAT DEBUG: Added system prompt, length: 3086
ERROR - 2026-01-06 10:21:24 --> AI CHAT DEBUG: Message 0 is object, role: user, has content: YES
ERROR - 2026-01-06 10:21:24 --> AI CHAT DEBUG: Added message 0 to formatted_messages
ERROR - 2026-01-06 10:21:24 --> AI CHAT DEBUG: Total formatted messages: 2
ERROR - 2026-01-06 10:21:24 --> AI API DEBUG: Received 2 messages to process
ERROR - 2026-01-06 10:21:24 --> AI API DEBUG: Found system message, length: 3086
ERROR - 2026-01-06 10:21:24 --> AI API DEBUG: Added user message, length: 15
ERROR - 2026-01-06 10:21:24 --> AI API DEBUG: After initial processing, contents count: 1
ERROR - 2026-01-06 10:21:24 --> AI API DEBUG: After filtering, contents count: 1
ERROR - 2026-01-06 10:21:24 --> AI API DEBUG: Prepended system instruction. Original: 15, New: 3103
ERROR - 2026-01-06 10:21:24 --> AI API DEBUG: Final contents count before sending: 1
ERROR - 2026-01-06 10:21:24 --> AI API DEBUG: Contents structure: [{"role":"user","text_length":3103}]
ERROR - 2026-01-06 10:21:24 --> AI API DEBUG: Data structure to send: {"contents_count":1}
ERROR - 2026-01-06 10:21:24 --> AI API DEBUG: JSON encode error code: 5
ERROR - 2026-01-06 10:21:24 --> AI API DEBUG: JSON payload length: 0
ERROR - 2026-01-06 10:21:24 --> AI API DEBUG: JSON payload (first 1000 chars): 
ERROR - 2026-01-06 10:21:24 --> AI API DEBUG: Raw contents array count: 1
ERROR - 2026-01-06 10:21:24 --> AI API DEBUG: First content item: 
ERROR - 2026-01-06 10:21:24 --> Gemini API error (HTTP 400): {
  "error": {
    "code": 400,
    "message": "* GenerateContentRequest.contents: contents is not specified\n",
    "status": "INVALID_ARGUMENT"
  }
}

ERROR - 2026-01-06 10:23:24 --> AI CHAT DEBUG: Starting chat with 1 messages, system_prompt: YES
ERROR - 2026-01-06 10:23:24 --> AI CHAT DEBUG: Added system prompt, length: 3086
ERROR - 2026-01-06 10:23:24 --> AI CHAT DEBUG: Message 0 is object, role: user, has content: YES
ERROR - 2026-01-06 10:23:24 --> AI CHAT DEBUG: Added message 0 to formatted_messages
ERROR - 2026-01-06 10:23:24 --> AI CHAT DEBUG: Total formatted messages: 2
ERROR - 2026-01-06 10:23:24 --> AI API DEBUG: Received 2 messages to process
ERROR - 2026-01-06 10:23:24 --> AI API DEBUG: Found system message, length: 3086
ERROR - 2026-01-06 10:23:24 --> AI API DEBUG: Added user message, length: 15
ERROR - 2026-01-06 10:23:24 --> AI API DEBUG: After initial processing, contents count: 1
ERROR - 2026-01-06 10:23:24 --> AI API DEBUG: After filtering, contents count: 1
ERROR - 2026-01-06 10:23:24 --> AI API DEBUG: Prepended system instruction. Original: 15, New: 3103
ERROR - 2026-01-06 10:23:24 --> AI API DEBUG: Final contents count before sending: 1
ERROR - 2026-01-06 10:23:24 --> AI API DEBUG: Contents structure: [{"role":"user","text_length":3103}]
ERROR - 2026-01-06 10:23:24 --> AI API DEBUG: Data structure to send: {"contents_count":1}
ERROR - 2026-01-06 10:23:24 --> AI API DEBUG: JSON encode error code: 0
ERROR - 2026-01-06 10:23:24 --> AI API DEBUG: JSON payload length: 1869
ERROR - 2026-01-06 10:23:24 --> AI API DEBUG: JSON payload (first 1000 chars): {"contents":[{"role":"user","parts":[{"text":"You are an AI teaching assistant helping with educational content.\n\nDocument Context:\nǮ*˾kz(13C2e>|NK!5e^7mØ>|I~N^m^ӬLw[ݛ}o_^w:w{scoqqǽG]I^\/ΫӪ?YVin7856+0P'Pӝu{;_Ebr,G}&B4ҕuڏuK3hA\"VerLе<mUMvKlyz[_b_(vCWmURE~N[J<Ʋ:laj\r6vHRj7OQۘY*bs7rU7C5\nwUޕoq{>4ZH_h6oۮ];N'\"ܕcw.f赴Cy\\j(oeR5s1EiT^]5hZ}krXеy׌2CiN@~C9mCMQ1oTEPLCͫooފ(S3@G\\\t1n<jȋaVI0\t+ƣrqL$˅cCoGEvOI\/GtRZPr\\_*f[%-2zRETE>QPN\"7b5\"Y4_oH e }L#\tc9dN\\Dhq~|9D\nlsT8a#\n ,hUH2N8=C4H0k<ҋ7ACaY\nZW0d#[w\r(Di+\/I{; W\tI1\"ViE48VfV\t7lUBw#$q7ybL1*Q[cw 5`?W\r2A-ULL̍ҊkӐs _'O%EQtH]g.ehd^\\Ѯϋ<V5\\hU|7dL~BZפ$i\r|F.ovGFH|;M a`uԧ!vwmU_CZS]?dOwh[]oC38ufAǱZ>S׶Yy蜐zUcxɮ=NL'\r&h4i{\nDShQv5Bys_\\bIЗHh}N3LXGw(v^'_m\"(˝ڜ}4`FDX4\rc#E~hg#?=D#\r76FndcGod:Rl8\t.'dcl:iHNgK6G,O*J4FNw$rl\n[l.Lit!_T#+MuP5d,$'tAذlPSXcjQ]EK5eChCv}Sd]WH%|9\/B `r\/fW:L2EBLH8d^8T+sCF^C&+4d|tfؚ3,x+~#;c<^p&u4ueG]\\p1vVO:OI-\r,v:fo\\PV%.}wS\n8$ńpjz[,@٢-paȍ\"s_!M&Rzf!'W ÂOBO6H+zJyiE5PR|Wv+ЍnmJ
ERROR - 2026-01-06 10:23:24 --> AI API DEBUG: Raw contents array count: 1
ERROR - 2026-01-06 10:23:24 --> AI API DEBUG: First content item: {"role":"user","parts":[{"text":"You are an AI teaching assistant helping with educational content.\n\nDocument Context:\n\u01ee*\u02fekz(13C2e>|NK!5e^7m\u00d8>|I~N^m^\u04ecLw[\u075b}o_^w:w{scoqq\u01fdG]I^\/\u03ab\u04ea?YVin7856+0P'P\u04ddu{;_Ebr,G}&B4\u0495u\u068fuK3hA\"VerL\u0435<mUMvKlyz[_b_(vCWmURE~N[J<\u01b2:laj\r6vHRj7OQ\u06d8Y*bs7rU7C5\nwU\u0795oq{>4ZH_h6o\u06ee];N'\"\u0715cw.f\u8d74Cy\\j(oeR5s1EiT^]5hZ}krX\u0435y\u05cc2CiN@~C9mCMQ1oTEPLC\u036boo\u078a(S3@G\\\t1n<j\u020baVI0\t+\u01a3rqL$\u02c5cCoGEvOI\/GtRZPr\\_*f[%-2zRETE>QPN\"7b5\"Y4_oH e }L#\tc9dN\\Dhq~|9D\nlsT8a#\n ,hUH2N8=C4H0k<\u048b7ACaY\nZW0d#[w\r(Di+\/I{; W\tI1\"ViE48VfV\t7lUBw#$q7ybL1*Q[cw 5`?W\r2A-ULL\u030d\u048ak\u04d0s \u0093_'O%EQtH]g.ehd^\\\u046e\u03cb<V5\\hU|7dL~BZ\u05e4$i\r|F.ovGFH|;M a`u\u0527!vwmU_CZS]?dOwh[]oC38ufA\u01f1Z>S\u05f6Yy\u8710zUcx\u026e=NL'\r&h4i{\nDShQv5Bys_\\bI\u0417Hh}N3LXGw(v^'_m\"(\u02dd\u069c}4`FDX4\rc#E~hg#?=D#\r76FndcGod:Rl8\t.'dcl:iHNgK6G,O*J4FNw$rl\n[l.Lit!_T#+MuP5d,$'tA\u0630lPSXcjQ]EK5eChCv}Sd]WH%|9\/B `r\/fW:L2EBLH8d^8T+sCF^C&+4d|tf\u061a3,x+~#;c<^p&u4ueG]\\p1vVO:OI-\r,v:fo\\PV%.}wS\n8$\u0144pjz[,@\u0662-pa\u020d\"s_!M&Rzf!'W \u00c2OBO6H+zJyiE5PR|Wv+\u040dnmJ\/&wAuQ%LY\u0609Mm2}~h@l\u049aL\u06ce{`D[0k\nl*\nLzYX@#O4ARqU8Y\"\rU1\r\n8p}lL^h,\u00c9\u03b4t[RL}t\u04b2P7VKH?m^5kl77}r ^kZ\\j_9`[Zq$q'#dJ \u062dn\ub725=*,kM7+6Ku>,&WZ\u027apFK9Yf\u038a\u019dSTm-`~H\/\u0585?LNFt\\u^$`n58-#Rn|:Y\n &J\u057cww\r~qy{\u035anHTD5Z}J[X\/jj`1Qo]MK|Ijs_?9\u0719\u050f(S\\yI\\(4\r\u05bcC\u0464T 2Z?&r\\-9c<\u071dSl\nB\/]\\#K\u046eOd''E $9e%gIc8m2\u047f2zD1=X`Oiq\u50223< \u01bfL3JGd\nendstream\nendobj\n1 0 obj\n<< \/Type \/Page \/Parent 2 0 R \/Resources 4 0 R \/Contents 3 0 R \/MediaBox [0 0 612 792]\n>>\nendobj\n4 0 obj\n<< \/ProcSet [ \/PDF \/Text ] \/ColorSpace << \/Cs1 5 0 R >> \/Font << \/TT2 7 0 R\n\/TT4 9 0 R \/TT6 11 0 R \/TT8 13 0 R \/TT10 15 0 R \/TT11 16 0 R \/TT13 18 0 R\n>> >>\nendobj\n19 0 obj\n<< \/N 3 \/Alternate \/DeviceRGB \/Length 2612 \/Filter \/FlateDecode >>\nstream\nxwTS\u03fd7\" %z\t ;HQIP&vDF L0_&l2E9r9hxg\n\ngive me summary"}]}
ERROR - 2026-01-06 10:23:35 --> CURL error: Resolving timed out after 10006 milliseconds
ERROR - 2026-01-06 10:26:57 --> AI CHAT DEBUG: Starting chat with 1 messages, system_prompt: YES
ERROR - 2026-01-06 10:26:57 --> AI CHAT DEBUG: Added system prompt, length: 3086
ERROR - 2026-01-06 10:26:57 --> AI CHAT DEBUG: Message 0 is object, role: user, has content: YES
ERROR - 2026-01-06 10:26:57 --> AI CHAT DEBUG: Added message 0 to formatted_messages
ERROR - 2026-01-06 10:26:57 --> AI CHAT DEBUG: Total formatted messages: 2
ERROR - 2026-01-06 10:26:57 --> AI API DEBUG: Received 2 messages to process
ERROR - 2026-01-06 10:26:57 --> AI API DEBUG: Found system message, length: 3086
ERROR - 2026-01-06 10:26:57 --> AI API DEBUG: Added user message, length: 15
ERROR - 2026-01-06 10:26:57 --> AI API DEBUG: After initial processing, contents count: 1
ERROR - 2026-01-06 10:26:57 --> AI API DEBUG: After filtering, contents count: 1
ERROR - 2026-01-06 10:26:57 --> AI API DEBUG: Prepended system instruction. Original: 15, New: 3103
ERROR - 2026-01-06 10:26:57 --> AI API DEBUG: Final contents count before sending: 1
ERROR - 2026-01-06 10:26:57 --> AI API DEBUG: Contents structure: [{"role":"user","text_length":3103}]
ERROR - 2026-01-06 10:26:57 --> AI API DEBUG: Data structure to send: {"contents_count":1}
ERROR - 2026-01-06 10:26:57 --> AI API DEBUG: JSON encode error code: 0
ERROR - 2026-01-06 10:26:57 --> AI API DEBUG: JSON payload length: 1869
ERROR - 2026-01-06 10:26:57 --> AI API DEBUG: JSON payload (first 1000 chars): {"contents":[{"role":"user","parts":[{"text":"You are an AI teaching assistant helping with educational content.\n\nDocument Context:\nǮ*˾kz(13C2e>|NK!5e^7mØ>|I~N^m^ӬLw[ݛ}o_^w:w{scoqqǽG]I^\/ΫӪ?YVin7856+0P'Pӝu{;_Ebr,G}&B4ҕuڏuK3hA\"VerLе<mUMvKlyz[_b_(vCWmURE~N[J<Ʋ:laj\r6vHRj7OQۘY*bs7rU7C5\nwUޕoq{>4ZH_h6oۮ];N'\"ܕcw.f赴Cy\\j(oeR5s1EiT^]5hZ}krXеy׌2CiN@~C9mCMQ1oTEPLCͫooފ(S3@G\\\t1n<jȋaVI0\t+ƣrqL$˅cCoGEvOI\/GtRZPr\\_*f[%-2zRETE>QPN\"7b5\"Y4_oH e }L#\tc9dN\\Dhq~|9D\nlsT8a#\n ,hUH2N8=C4H0k<ҋ7ACaY\nZW0d#[w\r(Di+\/I{; W\tI1\"ViE48VfV\t7lUBw#$q7ybL1*Q[cw 5`?W\r2A-ULL̍ҊkӐs _'O%EQtH]g.ehd^\\Ѯϋ<V5\\hU|7dL~BZפ$i\r|F.ovGFH|;M a`uԧ!vwmU_CZS]?dOwh[]oC38ufAǱZ>S׶Yy蜐zUcxɮ=NL'\r&h4i{\nDShQv5Bys_\\bIЗHh}N3LXGw(v^'_m\"(˝ڜ}4`FDX4\rc#E~hg#?=D#\r76FndcGod:Rl8\t.'dcl:iHNgK6G,O*J4FNw$rl\n[l.Lit!_T#+MuP5d,$'tAذlPSXcjQ]EK5eChCv}Sd]WH%|9\/B `r\/fW:L2EBLH8d^8T+sCF^C&+4d|tfؚ3,x+~#;c<^p&u4ueG]\\p1vVO:OI-\r,v:fo\\PV%.}wS\n8$ńpjz[,@٢-paȍ\"s_!M&Rzf!'W ÂOBO6H+zJyiE5PR|Wv+ЍnmJ
ERROR - 2026-01-06 10:26:57 --> AI API DEBUG: Raw contents array count: 1
ERROR - 2026-01-06 10:26:57 --> AI API DEBUG: First content item: {"role":"user","parts":[{"text":"You are an AI teaching assistant helping with educational content.\n\nDocument Context:\n\u01ee*\u02fekz(13C2e>|NK!5e^7m\u00d8>|I~N^m^\u04ecLw[\u075b}o_^w:w{scoqq\u01fdG]I^\/\u03ab\u04ea?YVin7856+0P'P\u04ddu{;_Ebr,G}&B4\u0495u\u068fuK3hA\"VerL\u0435<mUMvKlyz[_b_(vCWmURE~N[J<\u01b2:laj\r6vHRj7OQ\u06d8Y*bs7rU7C5\nwU\u0795oq{>4ZH_h6o\u06ee];N'\"\u0715cw.f\u8d74Cy\\j(oeR5s1EiT^]5hZ}krX\u0435y\u05cc2CiN@~C9mCMQ1oTEPLC\u036boo\u078a(S3@G\\\t1n<j\u020baVI0\t+\u01a3rqL$\u02c5cCoGEvOI\/GtRZPr\\_*f[%-2zRETE>QPN\"7b5\"Y4_oH e }L#\tc9dN\\Dhq~|9D\nlsT8a#\n ,hUH2N8=C4H0k<\u048b7ACaY\nZW0d#[w\r(Di+\/I{; W\tI1\"ViE48VfV\t7lUBw#$q7ybL1*Q[cw 5`?W\r2A-ULL\u030d\u048ak\u04d0s \u0093_'O%EQtH]g.ehd^\\\u046e\u03cb<V5\\hU|7dL~BZ\u05e4$i\r|F.ovGFH|;M a`u\u0527!vwmU_CZS]?dOwh[]oC38ufA\u01f1Z>S\u05f6Yy\u8710zUcx\u026e=NL'\r&h4i{\nDShQv5Bys_\\bI\u0417Hh}N3LXGw(v^'_m\"(\u02dd\u069c}4`FDX4\rc#E~hg#?=D#\r76FndcGod:Rl8\t.'dcl:iHNgK6G,O*J4FNw$rl\n[l.Lit!_T#+MuP5d,$'tA\u0630lPSXcjQ]EK5eChCv}Sd]WH%|9\/B `r\/fW:L2EBLH8d^8T+sCF^C&+4d|tf\u061a3,x+~#;c<^p&u4ueG]\\p1vVO:OI-\r,v:fo\\PV%.}wS\n8$\u0144pjz[,@\u0662-pa\u020d\"s_!M&Rzf!'W \u00c2OBO6H+zJyiE5PR|Wv+\u040dnmJ\/&wAuQ%LY\u0609Mm2}~h@l\u049aL\u06ce{`D[0k\nl*\nLzYX@#O4ARqU8Y\"\rU1\r\n8p}lL^h,\u00c9\u03b4t[RL}t\u04b2P7VKH?m^5kl77}r ^kZ\\j_9`[Zq$q'#dJ \u062dn\ub725=*,kM7+6Ku>,&WZ\u027apFK9Yf\u038a\u019dSTm-`~H\/\u0585?LNFt\\u^$`n58-#Rn|:Y\n &J\u057cww\r~qy{\u035anHTD5Z}J[X\/jj`1Qo]MK|Ijs_?9\u0719\u050f(S\\yI\\(4\r\u05bcC\u0464T 2Z?&r\\-9c<\u071dSl\nB\/]\\#K\u046eOd''E $9e%gIc8m2\u047f2zD1=X`Oiq\u50223< \u01bfL3JGd\nendstream\nendobj\n1 0 obj\n<< \/Type \/Page \/Parent 2 0 R \/Resources 4 0 R \/Contents 3 0 R \/MediaBox [0 0 612 792]\n>>\nendobj\n4 0 obj\n<< \/ProcSet [ \/PDF \/Text ] \/ColorSpace << \/Cs1 5 0 R >> \/Font << \/TT2 7 0 R\n\/TT4 9 0 R \/TT6 11 0 R \/TT8 13 0 R \/TT10 15 0 R \/TT11 16 0 R \/TT13 18 0 R\n>> >>\nendobj\n19 0 obj\n<< \/N 3 \/Alternate \/DeviceRGB \/Length 2612 \/Filter \/FlateDecode >>\nstream\nxwTS\u03fd7\" %z\t ;HQIP&vDF L0_&l2E9r9hxg\n\ngive me summary"}]}
ERROR - 2026-01-06 10:27:07 --> CURL error: Connection timed out after 10007 milliseconds
ERROR - 2026-01-06 10:33:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2026-01-06 10:35:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2026-01-06 10:41:40 --> 404 Page Not Found: Simple_portal/faculty_dashboard
ERROR - 2026-01-06 10:42:34 --> 404 Page Not Found: Ai_buddy/session
ERROR - 2026-01-06 10:42:55 --> AI CHAT DEBUG: Starting chat with 1 messages, system_prompt: YES
ERROR - 2026-01-06 10:42:55 --> AI CHAT DEBUG: Added system prompt, length: 3086
ERROR - 2026-01-06 10:42:55 --> AI CHAT DEBUG: Message 0 is object, role: user, has content: YES
ERROR - 2026-01-06 10:42:55 --> AI CHAT DEBUG: Added message 0 to formatted_messages
ERROR - 2026-01-06 10:42:55 --> AI CHAT DEBUG: Total formatted messages: 2
ERROR - 2026-01-06 10:42:55 --> AI API DEBUG: Received 2 messages to process
ERROR - 2026-01-06 10:42:55 --> AI API DEBUG: Found system message, length: 3086
ERROR - 2026-01-06 10:42:55 --> AI API DEBUG: Added user message, length: 15
ERROR - 2026-01-06 10:42:55 --> AI API DEBUG: After initial processing, contents count: 1
ERROR - 2026-01-06 10:42:55 --> AI API DEBUG: After filtering, contents count: 1
ERROR - 2026-01-06 10:42:55 --> AI API DEBUG: Prepended system instruction. Original: 15, New: 3103
ERROR - 2026-01-06 10:42:55 --> AI API DEBUG: Final contents count before sending: 1
ERROR - 2026-01-06 10:42:55 --> AI API DEBUG: Contents structure: [{"role":"user","text_length":3103}]
ERROR - 2026-01-06 10:42:55 --> AI API DEBUG: Data structure to send: {"contents_count":1}
ERROR - 2026-01-06 10:42:55 --> AI API DEBUG: JSON encode error code: 0
ERROR - 2026-01-06 10:42:55 --> AI API DEBUG: JSON payload length: 1869
ERROR - 2026-01-06 10:42:55 --> AI API DEBUG: JSON payload (first 1000 chars): {"contents":[{"role":"user","parts":[{"text":"You are an AI teaching assistant helping with educational content.\n\nDocument Context:\nǮ*˾kz(13C2e>|NK!5e^7mØ>|I~N^m^ӬLw[ݛ}o_^w:w{scoqqǽG]I^\/ΫӪ?YVin7856+0P'Pӝu{;_Ebr,G}&B4ҕuڏuK3hA\"VerLе<mUMvKlyz[_b_(vCWmURE~N[J<Ʋ:laj\r6vHRj7OQۘY*bs7rU7C5\nwUޕoq{>4ZH_h6oۮ];N'\"ܕcw.f赴Cy\\j(oeR5s1EiT^]5hZ}krXеy׌2CiN@~C9mCMQ1oTEPLCͫooފ(S3@G\\\t1n<jȋaVI0\t+ƣrqL$˅cCoGEvOI\/GtRZPr\\_*f[%-2zRETE>QPN\"7b5\"Y4_oH e }L#\tc9dN\\Dhq~|9D\nlsT8a#\n ,hUH2N8=C4H0k<ҋ7ACaY\nZW0d#[w\r(Di+\/I{; W\tI1\"ViE48VfV\t7lUBw#$q7ybL1*Q[cw 5`?W\r2A-ULL̍ҊkӐs _'O%EQtH]g.ehd^\\Ѯϋ<V5\\hU|7dL~BZפ$i\r|F.ovGFH|;M a`uԧ!vwmU_CZS]?dOwh[]oC38ufAǱZ>S׶Yy蜐zUcxɮ=NL'\r&h4i{\nDShQv5Bys_\\bIЗHh}N3LXGw(v^'_m\"(˝ڜ}4`FDX4\rc#E~hg#?=D#\r76FndcGod:Rl8\t.'dcl:iHNgK6G,O*J4FNw$rl\n[l.Lit!_T#+MuP5d,$'tAذlPSXcjQ]EK5eChCv}Sd]WH%|9\/B `r\/fW:L2EBLH8d^8T+sCF^C&+4d|tfؚ3,x+~#;c<^p&u4ueG]\\p1vVO:OI-\r,v:fo\\PV%.}wS\n8$ńpjz[,@٢-paȍ\"s_!M&Rzf!'W ÂOBO6H+zJyiE5PR|Wv+ЍnmJ
ERROR - 2026-01-06 10:42:55 --> AI API DEBUG: Raw contents array count: 1
ERROR - 2026-01-06 10:42:55 --> AI API DEBUG: First content item: {"role":"user","parts":[{"text":"You are an AI teaching assistant helping with educational content.\n\nDocument Context:\n\u01ee*\u02fekz(13C2e>|NK!5e^7m\u00d8>|I~N^m^\u04ecLw[\u075b}o_^w:w{scoqq\u01fdG]I^\/\u03ab\u04ea?YVin7856+0P'P\u04ddu{;_Ebr,G}&B4\u0495u\u068fuK3hA\"VerL\u0435<mUMvKlyz[_b_(vCWmURE~N[J<\u01b2:laj\r6vHRj7OQ\u06d8Y*bs7rU7C5\nwU\u0795oq{>4ZH_h6o\u06ee];N'\"\u0715cw.f\u8d74Cy\\j(oeR5s1EiT^]5hZ}krX\u0435y\u05cc2CiN@~C9mCMQ1oTEPLC\u036boo\u078a(S3@G\\\t1n<j\u020baVI0\t+\u01a3rqL$\u02c5cCoGEvOI\/GtRZPr\\_*f[%-2zRETE>QPN\"7b5\"Y4_oH e }L#\tc9dN\\Dhq~|9D\nlsT8a#\n ,hUH2N8=C4H0k<\u048b7ACaY\nZW0d#[w\r(Di+\/I{; W\tI1\"ViE48VfV\t7lUBw#$q7ybL1*Q[cw 5`?W\r2A-ULL\u030d\u048ak\u04d0s \u0093_'O%EQtH]g.ehd^\\\u046e\u03cb<V5\\hU|7dL~BZ\u05e4$i\r|F.ovGFH|;M a`u\u0527!vwmU_CZS]?dOwh[]oC38ufA\u01f1Z>S\u05f6Yy\u8710zUcx\u026e=NL'\r&h4i{\nDShQv5Bys_\\bI\u0417Hh}N3LXGw(v^'_m\"(\u02dd\u069c}4`FDX4\rc#E~hg#?=D#\r76FndcGod:Rl8\t.'dcl:iHNgK6G,O*J4FNw$rl\n[l.Lit!_T#+MuP5d,$'tA\u0630lPSXcjQ]EK5eChCv}Sd]WH%|9\/B `r\/fW:L2EBLH8d^8T+sCF^C&+4d|tf\u061a3,x+~#;c<^p&u4ueG]\\p1vVO:OI-\r,v:fo\\PV%.}wS\n8$\u0144pjz[,@\u0662-pa\u020d\"s_!M&Rzf!'W \u00c2OBO6H+zJyiE5PR|Wv+\u040dnmJ\/&wAuQ%LY\u0609Mm2}~h@l\u049aL\u06ce{`D[0k\nl*\nLzYX@#O4ARqU8Y\"\rU1\r\n8p}lL^h,\u00c9\u03b4t[RL}t\u04b2P7VKH?m^5kl77}r ^kZ\\j_9`[Zq$q'#dJ \u062dn\ub725=*,kM7+6Ku>,&WZ\u027apFK9Yf\u038a\u019dSTm-`~H\/\u0585?LNFt\\u^$`n58-#Rn|:Y\n &J\u057cww\r~qy{\u035anHTD5Z}J[X\/jj`1Qo]MK|Ijs_?9\u0719\u050f(S\\yI\\(4\r\u05bcC\u0464T 2Z?&r\\-9c<\u071dSl\nB\/]\\#K\u046eOd''E $9e%gIc8m2\u047f2zD1=X`Oiq\u50223< \u01bfL3JGd\nendstream\nendobj\n1 0 obj\n<< \/Type \/Page \/Parent 2 0 R \/Resources 4 0 R \/Contents 3 0 R \/MediaBox [0 0 612 792]\n>>\nendobj\n4 0 obj\n<< \/ProcSet [ \/PDF \/Text ] \/ColorSpace << \/Cs1 5 0 R >> \/Font << \/TT2 7 0 R\n\/TT4 9 0 R \/TT6 11 0 R \/TT8 13 0 R \/TT10 15 0 R \/TT11 16 0 R \/TT13 18 0 R\n>> >>\nendobj\n19 0 obj\n<< \/N 3 \/Alternate \/DeviceRGB \/Length 2612 \/Filter \/FlateDecode >>\nstream\nxwTS\u03fd7\" %z\t ;HQIP&vDF L0_&l2E9r9hxg\n\ngive me summary"}]}
ERROR - 2026-01-06 10:44:09 --> 404 Page Not Found: Ai_buddy/dashboard
ERROR - 2026-01-06 10:44:21 --> 404 Page Not Found: Ai_buddy/dashboard
ERROR - 2026-01-06 10:55:29 --> AI CHAT DEBUG: Starting chat with 1 messages, system_prompt: YES
ERROR - 2026-01-06 10:55:29 --> AI CHAT DEBUG: Added system prompt, length: 3086
ERROR - 2026-01-06 10:55:29 --> AI CHAT DEBUG: Message 0 is object, role: user, has content: YES
ERROR - 2026-01-06 10:55:29 --> AI CHAT DEBUG: Added message 0 to formatted_messages
ERROR - 2026-01-06 10:55:29 --> AI CHAT DEBUG: Total formatted messages: 2
ERROR - 2026-01-06 10:55:29 --> AI API DEBUG: Received 2 messages to process
ERROR - 2026-01-06 10:55:29 --> AI API DEBUG: Found system message, length: 3086
ERROR - 2026-01-06 10:55:29 --> AI API DEBUG: Added user message, length: 15
ERROR - 2026-01-06 10:55:29 --> AI API DEBUG: After initial processing, contents count: 1
ERROR - 2026-01-06 10:55:29 --> AI API DEBUG: After filtering, contents count: 1
ERROR - 2026-01-06 10:55:29 --> AI API DEBUG: Prepended system instruction. Original: 15, New: 3103
ERROR - 2026-01-06 10:55:29 --> AI API DEBUG: Final contents count before sending: 1
ERROR - 2026-01-06 10:55:29 --> AI API DEBUG: Contents structure: [{"role":"user","text_length":3103}]
ERROR - 2026-01-06 10:55:29 --> AI API DEBUG: Data structure to send: {"contents_count":1}
ERROR - 2026-01-06 10:55:29 --> AI API DEBUG: JSON encode error code: 0
ERROR - 2026-01-06 10:55:29 --> AI API DEBUG: JSON payload length: 1728
ERROR - 2026-01-06 10:55:29 --> AI API DEBUG: JSON payload (first 1000 chars): {"contents":[{"role":"user","parts":[{"text":"You are an AI teaching assistant helping with educational content.\n\nDocument Context:\nen F֎p:_8ASwk2mĉ!eUtT'U҅jpAfg^ăآ92G:dZ\rI^S\\d$\n\\#'Ǐ}##CW:rw'eRS.<v-K[;GI8pZBSKxsGvD\/]Iv0#J?kEؒ.aK^^UGRZflTRv9+*SPbNK5^]^S݆V\r<i;#x9~Ӽчa9Yi~g<KdPykda9s,*9IWfF7\nҥW7U.oyЎMousvﰗaoD?'jfؖZN@jmi򖦹8Y6zPNS|YXؒTi|!Q'PtD0\/O.w[n4-8~xw;Iiѡp֫\t7Mhbi;}@h$(|3X^+rC~kol%\\\r1%-fa*g&ɸu\nw{;#^hi$9򊰷<z-V>lqt\"c\tv+;OхD;&I\tANRl_HX\"Qe#Iªb'w'V(|A2v{L#$\r-<PY(p\nO:#ٛ#7Hsn1A<TA\n._?@i<Ǔ#@B!2u-ɪ᭤|}+E\t'n=̷2\\-t>褰QNe,DMM?usySǗ;\n,=^'O'$7m9_#tJVEzd2C\rӴdQ.\t\/PGA\\a :DE}AizH' ̵8&$w&0%8j{FMB= QGŃsFc%JŶV \\\/]d8frZ`1;Q}(.}xJu\n_*eIR&g&\t 5%2bHc~Hd]'ˡ.J0VRmh\"fⷃu<Oa0\t0kkҜ`nHX8tL|Vf x7UAmdy\ts_HC.Q2<ѽuUwk&zaڪ׽MJU`#KwSe!'͞X%v9=YG1+R*]zJ&\t\rՎja0X0O>tn5FbT.  8gU|Z0\\>#ב-:s'2wĄ|K\"Q-LHw<Ϝ2I`>u7'37X2NTH*1c㬱ܘ9Ab.Ueܚ|۽m\/@~@GCR5 Identity Adobe M\"mGwnY,VI:<*<ĳgOߞ7y5~0z\\pq.<=\\eobNO~NT'?|<=y\/Fxuz\"i'H7BC! rnGgS6ӛxt8y sx(k
ERROR - 2026-01-06 10:55:29 --> AI API DEBUG: Raw contents array count: 1
ERROR - 2026-01-06 10:55:29 --> AI API DEBUG: First content item: {"role":"user","parts":[{"text":"You are an AI teaching assistant helping with educational content.\n\nDocument Context:\nen F\u058ep:_8ASwk2m\u0109!eUtT'U\u0485jpAfg^\u0103\u062292G:dZ\rI^S\\d$\n\\#'\u01cf}##CW:rw'eRS.<v-K[;GI8pZBSKxsGvD\/]Iv0#J?kE\u0612.aK^^UGRZflTRv9+*SPbNK5^]^S\u0746V\r<i;#x9~\u04fc\u0447a9Yi~g<KdPykda9s,*9IWfF7\n\u04a5W7U.oy\u040eMousv\ufc17a\ue808oD?'jf\u0616ZN@jmi\uda1a\uddb98Y6zPNS|YX\u0612Ti|!Q'PtD0\/O.w[n4-8~xw;Ii\u0461p\u05ab\t7Mhbi;}@h$(|3X^+rC~kol%\\\r1%-fa*g&\u0278u\nw{;#^hi$9\ud9eb\udc37<z-V>lqt\"c\tv+;O\u0445D;&I\tANRl_HX\"Qe#I\u00aab'w'V(|A2v{L#$\r-<PY(p\nO:#\u065b#7Hsn1A<TA\n._?@i<\u01d3#@B!2u-\u026a\u1b64|}+E\t'n=\u03372\\-t>\u8930QNe,DMM?usyS\u01d7;\n,=^'O'$7m9_#tJVEzd2C\r\u04f4dQ.\t\/PGA\\a :DE}AizH' \u03358&$w&0%8j{FMB= QG\u0143sFc%J\u0176V \\\/]d8frZ`1;Q}(.}xJu\n_*eIR&g&\t 5%2bHc~Hd]'\u02e1.J0VRmh\"f\u2dc3u<Oa0\t0kk\u049c`nHX8tL|Vf x7UAmdy\ts_HC.Q2<\u047duUwk&za\u06aa\u05fdMJU`#KwSe!'\u035eX%v9=YG1+R*]zJ&\t\r\u054eja0X0O>tn5FbT.  8gU|Z0\\>#\u05d1-:s'2w\u0104|K\"Q-LHw<\u03dc2I`>u7'37X2NTH*1c\u3b31\u07189Ab.Ue\u071a|\u06fdm\/@~@GCR5 Identity Adobe M\"mGwnY,VI:<*<\u0133gO\u07de7y5~0z\\pq.<=\\eobNO~NT'?|<=y\/Fxuz\"i'H7BC! rnGgS6\u04dbxt8y sx(k3xx\r&af\"{?Pt\u05e6$;*(v<u\"uc_uc[b8]YOM7i\u45567\u075cA\u8de3\u0129K\u011a4sY$nS\rI\u7949N]'8X7'Zh@ #(KT*\/IaFO\n\nG+\u025eENUc\u0367n<W0\u043f\/j1Bb\u0221bc RHjz{7sFZ\tD\rN VnuVP\u2c9cB&i{G4 =LA n\\1FGmx>\uaa3ff-\tcGB(l|\rf` uD-\tK9[t!e:g[.Fl(\uf89by\t8\u00efX \u0084}nenOER-\u0294\r\n\u051b4dF&fw<E1qTK88RS8ql3N!dAV\t\u043fg\u04bf\/lY(Zmr;MBr[\u03bak7@\n=\u056a\u2b2ebDt~1~\"j2r g}zx2JC\/T],\u0694RJ\/;kl<+\rR\u0372aZ^mqh *Y4x]1A1_4\u069fE\u00df\u04452W(!9c\\Q2c9\u04dc\u05ae24.HzP$\r\u0515r.k\u0492e'r5\"\n\uc3c9\";Fxf\u0326;Zp2\u03a6Qn[TZ\u0259+\u023c`ye\u042e2OB31Z<?82I`C9\u0621\n2YzM wA\"{\u07df\u032c:\u06d2TME'M\"\u028e9QN8$}e}W+k}yn.\u058bYN?oPIR\u04b6\u00e3`09%\nb|Z-Az\u065fxp_A4\u04bd\u06f56m\u2723ZrR?e?qyZTnoFDL$&fig7\"\/A@\u020fH]'\u07e8gm{jcK!~'e$$%\u010a\u0143t8f \u04c3! Identity Adobe Identity Adobe k5+b+:#$6\/t Hqs|8!\n\ngive me summary"}]}
ERROR - 2026-01-06 10:59:20 --> AI CHAT DEBUG: Starting chat with 1 messages, system_prompt: YES
ERROR - 2026-01-06 10:59:20 --> AI CHAT DEBUG: Added system prompt, length: 3086
ERROR - 2026-01-06 10:59:20 --> AI CHAT DEBUG: Message 0 is object, role: user, has content: YES
ERROR - 2026-01-06 10:59:20 --> AI CHAT DEBUG: Added message 0 to formatted_messages
ERROR - 2026-01-06 10:59:20 --> AI CHAT DEBUG: Total formatted messages: 2
ERROR - 2026-01-06 10:59:20 --> AI API DEBUG: Received 2 messages to process
ERROR - 2026-01-06 10:59:20 --> AI API DEBUG: Found system message, length: 3086
ERROR - 2026-01-06 10:59:20 --> AI API DEBUG: Added user message, length: 15
ERROR - 2026-01-06 10:59:20 --> AI API DEBUG: After initial processing, contents count: 1
ERROR - 2026-01-06 10:59:20 --> AI API DEBUG: After filtering, contents count: 1
ERROR - 2026-01-06 10:59:20 --> AI API DEBUG: Prepended system instruction. Original: 15, New: 3103
ERROR - 2026-01-06 10:59:20 --> AI API DEBUG: Final contents count before sending: 1
ERROR - 2026-01-06 10:59:20 --> AI API DEBUG: Contents structure: [{"role":"user","text_length":3103}]
ERROR - 2026-01-06 10:59:20 --> AI API DEBUG: Data structure to send: {"contents_count":1}
ERROR - 2026-01-06 10:59:20 --> AI API DEBUG: JSON encode error code: 0
ERROR - 2026-01-06 10:59:20 --> AI API DEBUG: JSON payload length: 1869
ERROR - 2026-01-06 10:59:20 --> AI API DEBUG: JSON payload (first 1000 chars): {"contents":[{"role":"user","parts":[{"text":"You are an AI teaching assistant helping with educational content.\n\nDocument Context:\nǮ*˾kz(13C2e>|NK!5e^7mØ>|I~N^m^ӬLw[ݛ}o_^w:w{scoqqǽG]I^\/ΫӪ?YVin7856+0P'Pӝu{;_Ebr,G}&B4ҕuڏuK3hA\"VerLе<mUMvKlyz[_b_(vCWmURE~N[J<Ʋ:laj\r6vHRj7OQۘY*bs7rU7C5\nwUޕoq{>4ZH_h6oۮ];N'\"ܕcw.f赴Cy\\j(oeR5s1EiT^]5hZ}krXеy׌2CiN@~C9mCMQ1oTEPLCͫooފ(S3@G\\\t1n<jȋaVI0\t+ƣrqL$˅cCoGEvOI\/GtRZPr\\_*f[%-2zRETE>QPN\"7b5\"Y4_oH e }L#\tc9dN\\Dhq~|9D\nlsT8a#\n ,hUH2N8=C4H0k<ҋ7ACaY\nZW0d#[w\r(Di+\/I{; W\tI1\"ViE48VfV\t7lUBw#$q7ybL1*Q[cw 5`?W\r2A-ULL̍ҊkӐs _'O%EQtH]g.ehd^\\Ѯϋ<V5\\hU|7dL~BZפ$i\r|F.ovGFH|;M a`uԧ!vwmU_CZS]?dOwh[]oC38ufAǱZ>S׶Yy蜐zUcxɮ=NL'\r&h4i{\nDShQv5Bys_\\bIЗHh}N3LXGw(v^'_m\"(˝ڜ}4`FDX4\rc#E~hg#?=D#\r76FndcGod:Rl8\t.'dcl:iHNgK6G,O*J4FNw$rl\n[l.Lit!_T#+MuP5d,$'tAذlPSXcjQ]EK5eChCv}Sd]WH%|9\/B `r\/fW:L2EBLH8d^8T+sCF^C&+4d|tfؚ3,x+~#;c<^p&u4ueG]\\p1vVO:OI-\r,v:fo\\PV%.}wS\n8$ńpjz[,@٢-paȍ\"s_!M&Rzf!'W ÂOBO6H+zJyiE5PR|Wv+ЍnmJ
ERROR - 2026-01-06 10:59:20 --> AI API DEBUG: Raw contents array count: 1
ERROR - 2026-01-06 10:59:20 --> AI API DEBUG: First content item: {"role":"user","parts":[{"text":"You are an AI teaching assistant helping with educational content.\n\nDocument Context:\n\u01ee*\u02fekz(13C2e>|NK!5e^7m\u00d8>|I~N^m^\u04ecLw[\u075b}o_^w:w{scoqq\u01fdG]I^\/\u03ab\u04ea?YVin7856+0P'P\u04ddu{;_Ebr,G}&B4\u0495u\u068fuK3hA\"VerL\u0435<mUMvKlyz[_b_(vCWmURE~N[J<\u01b2:laj\r6vHRj7OQ\u06d8Y*bs7rU7C5\nwU\u0795oq{>4ZH_h6o\u06ee];N'\"\u0715cw.f\u8d74Cy\\j(oeR5s1EiT^]5hZ}krX\u0435y\u05cc2CiN@~C9mCMQ1oTEPLC\u036boo\u078a(S3@G\\\t1n<j\u020baVI0\t+\u01a3rqL$\u02c5cCoGEvOI\/GtRZPr\\_*f[%-2zRETE>QPN\"7b5\"Y4_oH e }L#\tc9dN\\Dhq~|9D\nlsT8a#\n ,hUH2N8=C4H0k<\u048b7ACaY\nZW0d#[w\r(Di+\/I{; W\tI1\"ViE48VfV\t7lUBw#$q7ybL1*Q[cw 5`?W\r2A-ULL\u030d\u048ak\u04d0s \u0093_'O%EQtH]g.ehd^\\\u046e\u03cb<V5\\hU|7dL~BZ\u05e4$i\r|F.ovGFH|;M a`u\u0527!vwmU_CZS]?dOwh[]oC38ufA\u01f1Z>S\u05f6Yy\u8710zUcx\u026e=NL'\r&h4i{\nDShQv5Bys_\\bI\u0417Hh}N3LXGw(v^'_m\"(\u02dd\u069c}4`FDX4\rc#E~hg#?=D#\r76FndcGod:Rl8\t.'dcl:iHNgK6G,O*J4FNw$rl\n[l.Lit!_T#+MuP5d,$'tA\u0630lPSXcjQ]EK5eChCv}Sd]WH%|9\/B `r\/fW:L2EBLH8d^8T+sCF^C&+4d|tf\u061a3,x+~#;c<^p&u4ueG]\\p1vVO:OI-\r,v:fo\\PV%.}wS\n8$\u0144pjz[,@\u0662-pa\u020d\"s_!M&Rzf!'W \u00c2OBO6H+zJyiE5PR|Wv+\u040dnmJ\/&wAuQ%LY\u0609Mm2}~h@l\u049aL\u06ce{`D[0k\nl*\nLzYX@#O4ARqU8Y\"\rU1\r\n8p}lL^h,\u00c9\u03b4t[RL}t\u04b2P7VKH?m^5kl77}r ^kZ\\j_9`[Zq$q'#dJ \u062dn\ub725=*,kM7+6Ku>,&WZ\u027apFK9Yf\u038a\u019dSTm-`~H\/\u0585?LNFt\\u^$`n58-#Rn|:Y\n &J\u057cww\r~qy{\u035anHTD5Z}J[X\/jj`1Qo]MK|Ijs_?9\u0719\u050f(S\\yI\\(4\r\u05bcC\u0464T 2Z?&r\\-9c<\u071dSl\nB\/]\\#K\u046eOd''E $9e%gIc8m2\u047f2zD1=X`Oiq\u50223< \u01bfL3JGd\nendstream\nendobj\n1 0 obj\n<< \/Type \/Page \/Parent 2 0 R \/Resources 4 0 R \/Contents 3 0 R \/MediaBox [0 0 612 792]\n>>\nendobj\n4 0 obj\n<< \/ProcSet [ \/PDF \/Text ] \/ColorSpace << \/Cs1 5 0 R >> \/Font << \/TT2 7 0 R\n\/TT4 9 0 R \/TT6 11 0 R \/TT8 13 0 R \/TT10 15 0 R \/TT11 16 0 R \/TT13 18 0 R\n>> >>\nendobj\n19 0 obj\n<< \/N 3 \/Alternate \/DeviceRGB \/Length 2612 \/Filter \/FlateDecode >>\nstream\nxwTS\u03fd7\" %z\t ;HQIP&vDF L0_&l2E9r9hxg\n\ngive me summary"}]}
ERROR - 2026-01-06 11:01:48 --> 404 Page Not Found: Ai_buddy/dashboard
ERROR - 2026-01-06 11:02:14 --> AI CHAT DEBUG: Starting chat with 1 messages, system_prompt: YES
ERROR - 2026-01-06 11:02:14 --> AI CHAT DEBUG: Added system prompt, length: 3086
ERROR - 2026-01-06 11:02:14 --> AI CHAT DEBUG: Message 0 is object, role: user, has content: YES
ERROR - 2026-01-06 11:02:14 --> AI CHAT DEBUG: Added message 0 to formatted_messages
ERROR - 2026-01-06 11:02:14 --> AI CHAT DEBUG: Total formatted messages: 2
ERROR - 2026-01-06 11:02:14 --> AI API DEBUG: Received 2 messages to process
ERROR - 2026-01-06 11:02:14 --> AI API DEBUG: Found system message, length: 3086
ERROR - 2026-01-06 11:02:14 --> AI API DEBUG: Added user message, length: 15
ERROR - 2026-01-06 11:02:14 --> AI API DEBUG: After initial processing, contents count: 1
ERROR - 2026-01-06 11:02:14 --> AI API DEBUG: After filtering, contents count: 1
ERROR - 2026-01-06 11:02:14 --> AI API DEBUG: Prepended system instruction. Original: 15, New: 3103
ERROR - 2026-01-06 11:02:14 --> AI API DEBUG: Final contents count before sending: 1
ERROR - 2026-01-06 11:02:14 --> AI API DEBUG: Contents structure: [{"role":"user","text_length":3103}]
ERROR - 2026-01-06 11:02:14 --> AI API DEBUG: Data structure to send: {"contents_count":1}
ERROR - 2026-01-06 11:02:14 --> AI API DEBUG: JSON encode error code: 0
ERROR - 2026-01-06 11:02:14 --> AI API DEBUG: JSON payload length: 1869
ERROR - 2026-01-06 11:02:14 --> AI API DEBUG: JSON payload (first 1000 chars): {"contents":[{"role":"user","parts":[{"text":"You are an AI teaching assistant helping with educational content.\n\nDocument Context:\nǮ*˾kz(13C2e>|NK!5e^7mØ>|I~N^m^ӬLw[ݛ}o_^w:w{scoqqǽG]I^\/ΫӪ?YVin7856+0P'Pӝu{;_Ebr,G}&B4ҕuڏuK3hA\"VerLе<mUMvKlyz[_b_(vCWmURE~N[J<Ʋ:laj\r6vHRj7OQۘY*bs7rU7C5\nwUޕoq{>4ZH_h6oۮ];N'\"ܕcw.f赴Cy\\j(oeR5s1EiT^]5hZ}krXеy׌2CiN@~C9mCMQ1oTEPLCͫooފ(S3@G\\\t1n<jȋaVI0\t+ƣrqL$˅cCoGEvOI\/GtRZPr\\_*f[%-2zRETE>QPN\"7b5\"Y4_oH e }L#\tc9dN\\Dhq~|9D\nlsT8a#\n ,hUH2N8=C4H0k<ҋ7ACaY\nZW0d#[w\r(Di+\/I{; W\tI1\"ViE48VfV\t7lUBw#$q7ybL1*Q[cw 5`?W\r2A-ULL̍ҊkӐs _'O%EQtH]g.ehd^\\Ѯϋ<V5\\hU|7dL~BZפ$i\r|F.ovGFH|;M a`uԧ!vwmU_CZS]?dOwh[]oC38ufAǱZ>S׶Yy蜐zUcxɮ=NL'\r&h4i{\nDShQv5Bys_\\bIЗHh}N3LXGw(v^'_m\"(˝ڜ}4`FDX4\rc#E~hg#?=D#\r76FndcGod:Rl8\t.'dcl:iHNgK6G,O*J4FNw$rl\n[l.Lit!_T#+MuP5d,$'tAذlPSXcjQ]EK5eChCv}Sd]WH%|9\/B `r\/fW:L2EBLH8d^8T+sCF^C&+4d|tfؚ3,x+~#;c<^p&u4ueG]\\p1vVO:OI-\r,v:fo\\PV%.}wS\n8$ńpjz[,@٢-paȍ\"s_!M&Rzf!'W ÂOBO6H+zJyiE5PR|Wv+ЍnmJ
ERROR - 2026-01-06 11:02:14 --> AI API DEBUG: Raw contents array count: 1
ERROR - 2026-01-06 11:02:14 --> AI API DEBUG: First content item: {"role":"user","parts":[{"text":"You are an AI teaching assistant helping with educational content.\n\nDocument Context:\n\u01ee*\u02fekz(13C2e>|NK!5e^7m\u00d8>|I~N^m^\u04ecLw[\u075b}o_^w:w{scoqq\u01fdG]I^\/\u03ab\u04ea?YVin7856+0P'P\u04ddu{;_Ebr,G}&B4\u0495u\u068fuK3hA\"VerL\u0435<mUMvKlyz[_b_(vCWmURE~N[J<\u01b2:laj\r6vHRj7OQ\u06d8Y*bs7rU7C5\nwU\u0795oq{>4ZH_h6o\u06ee];N'\"\u0715cw.f\u8d74Cy\\j(oeR5s1EiT^]5hZ}krX\u0435y\u05cc2CiN@~C9mCMQ1oTEPLC\u036boo\u078a(S3@G\\\t1n<j\u020baVI0\t+\u01a3rqL$\u02c5cCoGEvOI\/GtRZPr\\_*f[%-2zRETE>QPN\"7b5\"Y4_oH e }L#\tc9dN\\Dhq~|9D\nlsT8a#\n ,hUH2N8=C4H0k<\u048b7ACaY\nZW0d#[w\r(Di+\/I{; W\tI1\"ViE48VfV\t7lUBw#$q7ybL1*Q[cw 5`?W\r2A-ULL\u030d\u048ak\u04d0s \u0093_'O%EQtH]g.ehd^\\\u046e\u03cb<V5\\hU|7dL~BZ\u05e4$i\r|F.ovGFH|;M a`u\u0527!vwmU_CZS]?dOwh[]oC38ufA\u01f1Z>S\u05f6Yy\u8710zUcx\u026e=NL'\r&h4i{\nDShQv5Bys_\\bI\u0417Hh}N3LXGw(v^'_m\"(\u02dd\u069c}4`FDX4\rc#E~hg#?=D#\r76FndcGod:Rl8\t.'dcl:iHNgK6G,O*J4FNw$rl\n[l.Lit!_T#+MuP5d,$'tA\u0630lPSXcjQ]EK5eChCv}Sd]WH%|9\/B `r\/fW:L2EBLH8d^8T+sCF^C&+4d|tf\u061a3,x+~#;c<^p&u4ueG]\\p1vVO:OI-\r,v:fo\\PV%.}wS\n8$\u0144pjz[,@\u0662-pa\u020d\"s_!M&Rzf!'W \u00c2OBO6H+zJyiE5PR|Wv+\u040dnmJ\/&wAuQ%LY\u0609Mm2}~h@l\u049aL\u06ce{`D[0k\nl*\nLzYX@#O4ARqU8Y\"\rU1\r\n8p}lL^h,\u00c9\u03b4t[RL}t\u04b2P7VKH?m^5kl77}r ^kZ\\j_9`[Zq$q'#dJ \u062dn\ub725=*,kM7+6Ku>,&WZ\u027apFK9Yf\u038a\u019dSTm-`~H\/\u0585?LNFt\\u^$`n58-#Rn|:Y\n &J\u057cww\r~qy{\u035anHTD5Z}J[X\/jj`1Qo]MK|Ijs_?9\u0719\u050f(S\\yI\\(4\r\u05bcC\u0464T 2Z?&r\\-9c<\u071dSl\nB\/]\\#K\u046eOd''E $9e%gIc8m2\u047f2zD1=X`Oiq\u50223< \u01bfL3JGd\nendstream\nendobj\n1 0 obj\n<< \/Type \/Page \/Parent 2 0 R \/Resources 4 0 R \/Contents 3 0 R \/MediaBox [0 0 612 792]\n>>\nendobj\n4 0 obj\n<< \/ProcSet [ \/PDF \/Text ] \/ColorSpace << \/Cs1 5 0 R >> \/Font << \/TT2 7 0 R\n\/TT4 9 0 R \/TT6 11 0 R \/TT8 13 0 R \/TT10 15 0 R \/TT11 16 0 R \/TT13 18 0 R\n>> >>\nendobj\n19 0 obj\n<< \/N 3 \/Alternate \/DeviceRGB \/Length 2612 \/Filter \/FlateDecode >>\nstream\nxwTS\u03fd7\" %z\t ;HQIP&vDF L0_&l2E9r9hxg\n\ngive me summary"}]}
ERROR - 2026-01-06 11:04:41 --> AI Chat: Found resource file: uploads/resources/resource_1766565000_694ba48850c01.pdf, type: pdf
ERROR - 2026-01-06 11:04:41 --> AI Chat: Calling AI service PDF extraction
ERROR - 2026-01-06 11:04:41 --> PDF EXTRACTION: Starting extraction for: D:\Versions\UAI App\Neha's Version\FInal final\UAI Website\uploads/resources/resource_1766565000_694ba48850c01.pdf
ERROR - 2026-01-06 11:04:41 --> PDF EXTRACTION: Checking for vendor autoload at: D:\Versions\UAI App\Neha's Version\FInal final\UAI Website\vendor/autoload.php
ERROR - 2026-01-06 11:04:41 --> PDF EXTRACTION: Vendor autoload exists: YES
ERROR - 2026-01-06 11:04:41 --> PDF EXTRACTION: Vendor autoload loaded successfully
ERROR - 2026-01-06 11:04:41 --> PDF EXTRACTION: Creating Smalot parser instance
ERROR - 2026-01-06 11:04:41 --> PDF EXTRACTION: Parsing file...
ERROR - 2026-01-06 11:04:41 --> PDF EXTRACTION: Extracting text...
ERROR - 2026-01-06 11:04:41 --> PDF EXTRACTION: Raw text length: 6236
ERROR - 2026-01-06 11:04:41 --> PDF EXTRACTION: First 200 chars: ARTIFICIAL INTELLIGENCE IN 
MARKETING MANAGEMENT 
End Term Assessment Project 
________________________________________________________________________________ 
PROJECT OVERVIEW 
1.1 Project Title 
De
ERROR - 2026-01-06 11:04:41 --> PDF EXTRACTION: Success! Cleaning text...
ERROR - 2026-01-06 11:04:41 --> PDF EXTRACTION: Cleaned text length: 6091
ERROR - 2026-01-06 11:04:41 --> AI Chat: PDF extraction returned 6091 characters
ERROR - 2026-01-06 11:04:41 --> AI CHAT DEBUG: Starting chat with 1 messages, system_prompt: YES
ERROR - 2026-01-06 11:04:41 --> AI CHAT DEBUG: Added system prompt, length: 3086
ERROR - 2026-01-06 11:04:41 --> AI CHAT DEBUG: Message 0 is object, role: user, has content: YES
ERROR - 2026-01-06 11:04:41 --> AI CHAT DEBUG: Added message 0 to formatted_messages
ERROR - 2026-01-06 11:04:41 --> AI CHAT DEBUG: Total formatted messages: 2
ERROR - 2026-01-06 11:04:41 --> AI API DEBUG: Received 2 messages to process
ERROR - 2026-01-06 11:04:41 --> AI API DEBUG: Found system message, length: 3086
ERROR - 2026-01-06 11:04:41 --> AI API DEBUG: Added user message, length: 15
ERROR - 2026-01-06 11:04:41 --> AI API DEBUG: After initial processing, contents count: 1
ERROR - 2026-01-06 11:04:41 --> AI API DEBUG: After filtering, contents count: 1
ERROR - 2026-01-06 11:04:41 --> AI API DEBUG: Prepended system instruction. Original: 15, New: 3103
ERROR - 2026-01-06 11:04:41 --> AI API DEBUG: Final contents count before sending: 1
ERROR - 2026-01-06 11:04:41 --> AI API DEBUG: Contents structure: [{"role":"user","text_length":3103}]
ERROR - 2026-01-06 11:04:41 --> AI API DEBUG: Data structure to send: {"contents_count":1}
ERROR - 2026-01-06 11:04:41 --> AI API DEBUG: JSON encode error code: 0
ERROR - 2026-01-06 11:04:41 --> AI API DEBUG: JSON payload length: 3233
ERROR - 2026-01-06 11:04:41 --> AI API DEBUG: JSON payload (first 1000 chars): {"contents":[{"role":"user","parts":[{"text":"You are an AI teaching assistant helping with educational content.\n\nDocument Context:\nARTIFICIAL INTELLIGENCE IN MARKETING MANAGEMENT End Term Assessment Project ________________________________________________________________________________ PROJECT OVERVIEW 1.1 Project Title Development of an AI-Powered Competitive Product Strategy and Market Entry Plan 1.2 Learning Objectives • Apply AI technologies to develop comprehensive marketing strategies for new product development • Utilize no-code AI platforms to analyze competitor products and identify market opportunities • Implement ethical AI frameworks in marketing research and customer targeting • Create AI-driven personalization strategies and brand positioning frameworks • Develop data-driven marketing mix optimization using artificial intelligence tools • Evaluate the strategic impact of AI implementation across the entire customer journey 1.3 Project Context Business Sce
ERROR - 2026-01-06 11:04:41 --> AI API DEBUG: Raw contents array count: 1
ERROR - 2026-01-06 11:04:41 --> AI API DEBUG: First content item: {"role":"user","parts":[{"text":"You are an AI teaching assistant helping with educational content.\n\nDocument Context:\nARTIFICIAL INTELLIGENCE IN MARKETING MANAGEMENT End Term Assessment Project ________________________________________________________________________________ PROJECT OVERVIEW 1.1 Project Title Development of an AI-Powered Competitive Product Strategy and Market Entry Plan 1.2 Learning Objectives \u2022 Apply AI technologies to develop comprehensive marketing strategies for new product development \u2022 Utilize no-code AI platforms to analyze competitor products and identify market opportunities \u2022 Implement ethical AI frameworks in marketing research and customer targeting \u2022 Create AI-driven personalization strategies and brand positioning frameworks \u2022 Develop data-driven marketing mix optimization using artificial intelligence tools \u2022 Evaluate the strategic impact of AI implementation across the entire customer journey 1.3 Project Context Business Scenario: You are a Marketing Strategy Consultant hired by an emerging startup to challenge an established product in the online marketplace. Your task is to select an existing successful product from any major e-commerce platform and develop a comprehensive AI-powered strategy to launch a competing product that can capture significant market share. Challenge Requirements: \u2022 Select ONE existing product from online shopping platforms \u2022 Create a NEW competing product concept \u2022 Develop a complete AI-driven marketing strategy to rival the existing market leader \u2022 Demonstrate practical application of AI across all marketing functions Tools: Use the tools covered during the classroom and you are free to use another tool as per your preference PROJECT REQUIREMENTS AND DELIVERABLES 3.1 Phase 1: AI-Driven Market Research and Competitive Analysis Deliverable 1A: Product Selection and Competitive Intelligence Report Students must: \u2022 Select and justify choice of existing product from online marketplace \u2022 Conduct comprehensive competitive analysis using AI tools \u2022 Analyze customer reviews, ratings, and feedback patterns using sentiment analysis \u2022 Identify market gaps and opportunities for differentiation \u2022 Create competitor SWOT analysis with AI-generated insights Deliverable 1B: Customer Journey Mapping and Persona Development Students must: \u2022 Map complete customer journey from awareness to advocacy \u2022 Develop 3-5 detailed customer personas using AI-assisted segmentation \u2022 Analyze buying decision processes and pain points \u2022 Create customer empathy maps with behavioral insights \u2022 Document personalization opportunities at each touchpoint 3.2 Phase 2: AI-Enhanced Product Development and Brand Strategy Deliverable 2A: New Product Concept Development Students must create: \u2022 Innovative product concept with unique value propositions \u2022 AI-driven feature prioritization based on customer needs analysis \u2022 Product positioning strategy using AI competitive mapping \u2022 Brand identity development with AI-assisted creative elements \u2022 Value creation framework demonstrating competitive advantages\n\ngive me summary"}]}
ERROR - 2026-01-06 11:05:08 --> AI Chat: Found resource file: uploads/resources/resource_1766565000_694ba48850c01.pdf, type: pdf
ERROR - 2026-01-06 11:05:08 --> AI Chat: Calling AI service PDF extraction
ERROR - 2026-01-06 11:05:08 --> PDF EXTRACTION: Starting extraction for: D:\Versions\UAI App\Neha's Version\FInal final\UAI Website\uploads/resources/resource_1766565000_694ba48850c01.pdf
ERROR - 2026-01-06 11:05:08 --> PDF EXTRACTION: Checking for vendor autoload at: D:\Versions\UAI App\Neha's Version\FInal final\UAI Website\vendor/autoload.php
ERROR - 2026-01-06 11:05:08 --> PDF EXTRACTION: Vendor autoload exists: YES
ERROR - 2026-01-06 11:05:08 --> PDF EXTRACTION: Vendor autoload loaded successfully
ERROR - 2026-01-06 11:05:08 --> PDF EXTRACTION: Creating Smalot parser instance
ERROR - 2026-01-06 11:05:08 --> PDF EXTRACTION: Parsing file...
ERROR - 2026-01-06 11:05:08 --> PDF EXTRACTION: Extracting text...
ERROR - 2026-01-06 11:05:08 --> PDF EXTRACTION: Raw text length: 6236
ERROR - 2026-01-06 11:05:08 --> PDF EXTRACTION: First 200 chars: ARTIFICIAL INTELLIGENCE IN 
MARKETING MANAGEMENT 
End Term Assessment Project 
________________________________________________________________________________ 
PROJECT OVERVIEW 
1.1 Project Title 
De
ERROR - 2026-01-06 11:05:08 --> PDF EXTRACTION: Success! Cleaning text...
ERROR - 2026-01-06 11:05:08 --> PDF EXTRACTION: Cleaned text length: 6091
ERROR - 2026-01-06 11:05:08 --> AI Chat: PDF extraction returned 6091 characters
ERROR - 2026-01-06 11:05:08 --> AI CHAT DEBUG: Starting chat with 3 messages, system_prompt: YES
ERROR - 2026-01-06 11:05:08 --> AI CHAT DEBUG: Added system prompt, length: 3086
ERROR - 2026-01-06 11:05:08 --> AI CHAT DEBUG: Message 0 is object, role: user, has content: YES
ERROR - 2026-01-06 11:05:08 --> AI CHAT DEBUG: Added message 0 to formatted_messages
ERROR - 2026-01-06 11:05:08 --> AI CHAT DEBUG: Message 1 is object, role: assistant, has content: YES
ERROR - 2026-01-06 11:05:08 --> AI CHAT DEBUG: Added message 1 to formatted_messages
ERROR - 2026-01-06 11:05:08 --> AI CHAT DEBUG: Message 2 is object, role: user, has content: YES
ERROR - 2026-01-06 11:05:08 --> AI CHAT DEBUG: Added message 2 to formatted_messages
ERROR - 2026-01-06 11:05:08 --> AI CHAT DEBUG: Total formatted messages: 4
ERROR - 2026-01-06 11:05:08 --> AI API DEBUG: Received 4 messages to process
ERROR - 2026-01-06 11:05:08 --> AI API DEBUG: Found system message, length: 3086
ERROR - 2026-01-06 11:05:08 --> AI API DEBUG: Added user message, length: 15
ERROR - 2026-01-06 11:05:08 --> AI API DEBUG: Added model message, length: 987
ERROR - 2026-01-06 11:05:08 --> AI API DEBUG: Added user message, length: 34
ERROR - 2026-01-06 11:05:08 --> AI API DEBUG: After initial processing, contents count: 3
ERROR - 2026-01-06 11:05:08 --> AI API DEBUG: After filtering, contents count: 3
ERROR - 2026-01-06 11:05:08 --> AI API DEBUG: Prepended system instruction. Original: 15, New: 3103
ERROR - 2026-01-06 11:05:08 --> AI API DEBUG: Final contents count before sending: 3
ERROR - 2026-01-06 11:05:08 --> AI API DEBUG: Contents structure: [{"role":"user","text_length":3103},{"role":"model","text_length":987},{"role":"user","text_length":34}]
ERROR - 2026-01-06 11:05:08 --> AI API DEBUG: Data structure to send: {"contents_count":3}
ERROR - 2026-01-06 11:05:08 --> AI API DEBUG: JSON encode error code: 0
ERROR - 2026-01-06 11:05:08 --> AI API DEBUG: JSON payload length: 4341
ERROR - 2026-01-06 11:05:08 --> AI API DEBUG: JSON payload (first 1000 chars): {"contents":[{"role":"user","parts":[{"text":"You are an AI teaching assistant helping with educational content.\n\nDocument Context:\nARTIFICIAL INTELLIGENCE IN MARKETING MANAGEMENT End Term Assessment Project ________________________________________________________________________________ PROJECT OVERVIEW 1.1 Project Title Development of an AI-Powered Competitive Product Strategy and Market Entry Plan 1.2 Learning Objectives • Apply AI technologies to develop comprehensive marketing strategies for new product development • Utilize no-code AI platforms to analyze competitor products and identify market opportunities • Implement ethical AI frameworks in marketing research and customer targeting • Create AI-driven personalization strategies and brand positioning frameworks • Develop data-driven marketing mix optimization using artificial intelligence tools • Evaluate the strategic impact of AI implementation across the entire customer journey 1.3 Project Context Business Sce
ERROR - 2026-01-06 11:05:08 --> AI API DEBUG: Raw contents array count: 3
ERROR - 2026-01-06 11:05:08 --> AI API DEBUG: First content item: {"role":"user","parts":[{"text":"You are an AI teaching assistant helping with educational content.\n\nDocument Context:\nARTIFICIAL INTELLIGENCE IN MARKETING MANAGEMENT End Term Assessment Project ________________________________________________________________________________ PROJECT OVERVIEW 1.1 Project Title Development of an AI-Powered Competitive Product Strategy and Market Entry Plan 1.2 Learning Objectives \u2022 Apply AI technologies to develop comprehensive marketing strategies for new product development \u2022 Utilize no-code AI platforms to analyze competitor products and identify market opportunities \u2022 Implement ethical AI frameworks in marketing research and customer targeting \u2022 Create AI-driven personalization strategies and brand positioning frameworks \u2022 Develop data-driven marketing mix optimization using artificial intelligence tools \u2022 Evaluate the strategic impact of AI implementation across the entire customer journey 1.3 Project Context Business Scenario: You are a Marketing Strategy Consultant hired by an emerging startup to challenge an established product in the online marketplace. Your task is to select an existing successful product from any major e-commerce platform and develop a comprehensive AI-powered strategy to launch a competing product that can capture significant market share. Challenge Requirements: \u2022 Select ONE existing product from online shopping platforms \u2022 Create a NEW competing product concept \u2022 Develop a complete AI-driven marketing strategy to rival the existing market leader \u2022 Demonstrate practical application of AI across all marketing functions Tools: Use the tools covered during the classroom and you are free to use another tool as per your preference PROJECT REQUIREMENTS AND DELIVERABLES 3.1 Phase 1: AI-Driven Market Research and Competitive Analysis Deliverable 1A: Product Selection and Competitive Intelligence Report Students must: \u2022 Select and justify choice of existing product from online marketplace \u2022 Conduct comprehensive competitive analysis using AI tools \u2022 Analyze customer reviews, ratings, and feedback patterns using sentiment analysis \u2022 Identify market gaps and opportunities for differentiation \u2022 Create competitor SWOT analysis with AI-generated insights Deliverable 1B: Customer Journey Mapping and Persona Development Students must: \u2022 Map complete customer journey from awareness to advocacy \u2022 Develop 3-5 detailed customer personas using AI-assisted segmentation \u2022 Analyze buying decision processes and pain points \u2022 Create customer empathy maps with behavioral insights \u2022 Document personalization opportunities at each touchpoint 3.2 Phase 2: AI-Enhanced Product Development and Brand Strategy Deliverable 2A: New Product Concept Development Students must create: \u2022 Innovative product concept with unique value propositions \u2022 AI-driven feature prioritization based on customer needs analysis \u2022 Product positioning strategy using AI competitive mapping \u2022 Brand identity development with AI-assisted creative elements \u2022 Value creation framework demonstrating competitive advantages\n\ngive me summary"}]}
ERROR - 2026-01-06 11:10:40 --> AI Chat: Found resource file: uploads/resources/resource_1766565000_694ba48850c01.pdf, type: pdf
ERROR - 2026-01-06 11:10:40 --> AI Chat: Calling AI service PDF extraction
ERROR - 2026-01-06 11:10:40 --> PDF EXTRACTION: Starting extraction for: D:\Versions\UAI App\Neha's Version\FInal final\UAI Website\uploads/resources/resource_1766565000_694ba48850c01.pdf
ERROR - 2026-01-06 11:10:40 --> PDF EXTRACTION: Checking for vendor autoload at: D:\Versions\UAI App\Neha's Version\FInal final\UAI Website\vendor/autoload.php
ERROR - 2026-01-06 11:10:40 --> PDF EXTRACTION: Vendor autoload exists: YES
ERROR - 2026-01-06 11:10:40 --> PDF EXTRACTION: Vendor autoload loaded successfully
ERROR - 2026-01-06 11:10:40 --> PDF EXTRACTION: Creating Smalot parser instance
ERROR - 2026-01-06 11:10:40 --> PDF EXTRACTION: Parsing file...
ERROR - 2026-01-06 11:10:40 --> PDF EXTRACTION: Extracting text...
ERROR - 2026-01-06 11:10:40 --> PDF EXTRACTION: Raw text length: 6236
ERROR - 2026-01-06 11:10:40 --> PDF EXTRACTION: First 200 chars: ARTIFICIAL INTELLIGENCE IN 
MARKETING MANAGEMENT 
End Term Assessment Project 
________________________________________________________________________________ 
PROJECT OVERVIEW 
1.1 Project Title 
De
ERROR - 2026-01-06 11:10:40 --> PDF EXTRACTION: Success! Cleaning text...
ERROR - 2026-01-06 11:10:40 --> PDF EXTRACTION: Cleaned text length: 6091
ERROR - 2026-01-06 11:10:40 --> AI Chat: PDF extraction returned 6091 characters
ERROR - 2026-01-06 11:10:40 --> AI CHAT DEBUG: Starting chat with 1 messages, system_prompt: YES
ERROR - 2026-01-06 11:10:40 --> AI CHAT DEBUG: Added system prompt, length: 3086
ERROR - 2026-01-06 11:10:40 --> AI CHAT DEBUG: Message 0 is object, role: user, has content: YES
ERROR - 2026-01-06 11:10:40 --> AI CHAT DEBUG: Added message 0 to formatted_messages
ERROR - 2026-01-06 11:10:40 --> AI CHAT DEBUG: Total formatted messages: 2
ERROR - 2026-01-06 11:10:40 --> AI API DEBUG: Received 2 messages to process
ERROR - 2026-01-06 11:10:40 --> AI API DEBUG: Found system message, length: 3086
ERROR - 2026-01-06 11:10:40 --> AI API DEBUG: Added user message, length: 15
ERROR - 2026-01-06 11:10:40 --> AI API DEBUG: After initial processing, contents count: 1
ERROR - 2026-01-06 11:10:40 --> AI API DEBUG: After filtering, contents count: 1
ERROR - 2026-01-06 11:10:40 --> AI API DEBUG: Prepended system instruction. Original: 15, New: 3103
ERROR - 2026-01-06 11:10:40 --> AI API DEBUG: Final contents count before sending: 1
ERROR - 2026-01-06 11:10:40 --> AI API DEBUG: Contents structure: [{"role":"user","text_length":3103}]
ERROR - 2026-01-06 11:10:40 --> AI API DEBUG: Data structure to send: {"contents_count":1}
ERROR - 2026-01-06 11:10:40 --> AI API DEBUG: JSON encode error code: 0
ERROR - 2026-01-06 11:10:40 --> AI API DEBUG: JSON payload length: 3233
ERROR - 2026-01-06 11:10:40 --> AI API DEBUG: JSON payload (first 1000 chars): {"contents":[{"role":"user","parts":[{"text":"You are an AI teaching assistant helping with educational content.\n\nDocument Context:\nARTIFICIAL INTELLIGENCE IN MARKETING MANAGEMENT End Term Assessment Project ________________________________________________________________________________ PROJECT OVERVIEW 1.1 Project Title Development of an AI-Powered Competitive Product Strategy and Market Entry Plan 1.2 Learning Objectives • Apply AI technologies to develop comprehensive marketing strategies for new product development • Utilize no-code AI platforms to analyze competitor products and identify market opportunities • Implement ethical AI frameworks in marketing research and customer targeting • Create AI-driven personalization strategies and brand positioning frameworks • Develop data-driven marketing mix optimization using artificial intelligence tools • Evaluate the strategic impact of AI implementation across the entire customer journey 1.3 Project Context Business Sce
ERROR - 2026-01-06 11:10:40 --> AI API DEBUG: Raw contents array count: 1
ERROR - 2026-01-06 11:10:40 --> AI API DEBUG: First content item: {"role":"user","parts":[{"text":"You are an AI teaching assistant helping with educational content.\n\nDocument Context:\nARTIFICIAL INTELLIGENCE IN MARKETING MANAGEMENT End Term Assessment Project ________________________________________________________________________________ PROJECT OVERVIEW 1.1 Project Title Development of an AI-Powered Competitive Product Strategy and Market Entry Plan 1.2 Learning Objectives \u2022 Apply AI technologies to develop comprehensive marketing strategies for new product development \u2022 Utilize no-code AI platforms to analyze competitor products and identify market opportunities \u2022 Implement ethical AI frameworks in marketing research and customer targeting \u2022 Create AI-driven personalization strategies and brand positioning frameworks \u2022 Develop data-driven marketing mix optimization using artificial intelligence tools \u2022 Evaluate the strategic impact of AI implementation across the entire customer journey 1.3 Project Context Business Scenario: You are a Marketing Strategy Consultant hired by an emerging startup to challenge an established product in the online marketplace. Your task is to select an existing successful product from any major e-commerce platform and develop a comprehensive AI-powered strategy to launch a competing product that can capture significant market share. Challenge Requirements: \u2022 Select ONE existing product from online shopping platforms \u2022 Create a NEW competing product concept \u2022 Develop a complete AI-driven marketing strategy to rival the existing market leader \u2022 Demonstrate practical application of AI across all marketing functions Tools: Use the tools covered during the classroom and you are free to use another tool as per your preference PROJECT REQUIREMENTS AND DELIVERABLES 3.1 Phase 1: AI-Driven Market Research and Competitive Analysis Deliverable 1A: Product Selection and Competitive Intelligence Report Students must: \u2022 Select and justify choice of existing product from online marketplace \u2022 Conduct comprehensive competitive analysis using AI tools \u2022 Analyze customer reviews, ratings, and feedback patterns using sentiment analysis \u2022 Identify market gaps and opportunities for differentiation \u2022 Create competitor SWOT analysis with AI-generated insights Deliverable 1B: Customer Journey Mapping and Persona Development Students must: \u2022 Map complete customer journey from awareness to advocacy \u2022 Develop 3-5 detailed customer personas using AI-assisted segmentation \u2022 Analyze buying decision processes and pain points \u2022 Create customer empathy maps with behavioral insights \u2022 Document personalization opportunities at each touchpoint 3.2 Phase 2: AI-Enhanced Product Development and Brand Strategy Deliverable 2A: New Product Concept Development Students must create: \u2022 Innovative product concept with unique value propositions \u2022 AI-driven feature prioritization based on customer needs analysis \u2022 Product positioning strategy using AI competitive mapping \u2022 Brand identity development with AI-assisted creative elements \u2022 Value creation framework demonstrating competitive advantages\n\ngive me summary"}]}
ERROR - 2026-01-06 11:12:40 --> AI Chat: Found resource file: uploads/resources/resource_1767682424_695cb178a72de.pdf, type: pdf
ERROR - 2026-01-06 11:12:40 --> AI Chat: Calling AI service PDF extraction
ERROR - 2026-01-06 11:12:40 --> PDF EXTRACTION: Starting extraction for: D:\Versions\UAI App\Neha's Version\FInal final\UAI Website\uploads/resources/resource_1767682424_695cb178a72de.pdf
ERROR - 2026-01-06 11:12:40 --> PDF EXTRACTION: Checking for vendor autoload at: D:\Versions\UAI App\Neha's Version\FInal final\UAI Website\vendor/autoload.php
ERROR - 2026-01-06 11:12:40 --> PDF EXTRACTION: Vendor autoload exists: YES
ERROR - 2026-01-06 11:12:40 --> PDF EXTRACTION: Vendor autoload loaded successfully
ERROR - 2026-01-06 11:12:40 --> PDF EXTRACTION: Creating Smalot parser instance
ERROR - 2026-01-06 11:12:40 --> PDF EXTRACTION: Parsing file...
ERROR - 2026-01-06 11:12:40 --> PDF EXTRACTION: Extracting text...
ERROR - 2026-01-06 11:12:40 --> PDF EXTRACTION: Raw text length: 6848
ERROR - 2026-01-06 11:12:40 --> PDF EXTRACTION: First 200 chars: 1. What is stationarity in TSM? 
A time series is called stationary if its statistical properties like 
mean, variance, and autocorrelation do not change over time. 
Stationarity is very important in 
ERROR - 2026-01-06 11:12:40 --> PDF EXTRACTION: Success! Cleaning text...
ERROR - 2026-01-06 11:12:40 --> PDF EXTRACTION: Cleaned text length: 6694
ERROR - 2026-01-06 11:12:40 --> AI Chat: PDF extraction returned 6694 characters
ERROR - 2026-01-06 11:12:40 --> AI CHAT DEBUG: Starting chat with 1 messages, system_prompt: YES
ERROR - 2026-01-06 11:12:40 --> AI CHAT DEBUG: Added system prompt, length: 3086
ERROR - 2026-01-06 11:12:40 --> AI CHAT DEBUG: Message 0 is object, role: user, has content: YES
ERROR - 2026-01-06 11:12:40 --> AI CHAT DEBUG: Added message 0 to formatted_messages
ERROR - 2026-01-06 11:12:40 --> AI CHAT DEBUG: Total formatted messages: 2
ERROR - 2026-01-06 11:12:40 --> AI API DEBUG: Received 2 messages to process
ERROR - 2026-01-06 11:12:40 --> AI API DEBUG: Found system message, length: 3086
ERROR - 2026-01-06 11:12:40 --> AI API DEBUG: Added user message, length: 15
ERROR - 2026-01-06 11:12:40 --> AI API DEBUG: After initial processing, contents count: 1
ERROR - 2026-01-06 11:12:40 --> AI API DEBUG: After filtering, contents count: 1
ERROR - 2026-01-06 11:12:40 --> AI API DEBUG: Prepended system instruction. Original: 15, New: 3103
ERROR - 2026-01-06 11:12:40 --> AI API DEBUG: Final contents count before sending: 1
ERROR - 2026-01-06 11:12:40 --> AI API DEBUG: Contents structure: [{"role":"user","text_length":3103}]
ERROR - 2026-01-06 11:12:40 --> AI API DEBUG: Data structure to send: {"contents_count":1}
ERROR - 2026-01-06 11:12:40 --> AI API DEBUG: JSON encode error code: 0
ERROR - 2026-01-06 11:12:40 --> AI API DEBUG: JSON payload length: 3233
ERROR - 2026-01-06 11:12:40 --> AI API DEBUG: JSON payload (first 1000 chars): {"contents":[{"role":"user","parts":[{"text":"You are an AI teaching assistant helping with educational content.\n\nDocument Context:\n1. What is stationarity in TSM? A time series is called stationary if its statistical properties like mean, variance, and autocorrelation do not change over time. Stationarity is very important in forecasting because most models (like ARIMA) work only on stationary data. If a series is not stationary, we usually make it stationary using differencing, detrending, or removing seasonality. Points: • Mean and variance constant over time • No trend or seasonality • Easier to model and predict Diagram to draw: Compare one non-stationary series (with upward trend) and one stationary series (random fluctuations around mean 0). 2. Explain ARIMA in detail with diagram and explanation. ARIMA stands for Auto-Regressive Integrated Moving Average. • AR (Auto-Regressive): The current value depends on past values. • I (Integrated): Differencing of raw observa
ERROR - 2026-01-06 11:12:40 --> AI API DEBUG: Raw contents array count: 1
ERROR - 2026-01-06 11:12:40 --> AI API DEBUG: First content item: {"role":"user","parts":[{"text":"You are an AI teaching assistant helping with educational content.\n\nDocument Context:\n1. What is stationarity in TSM? A time series is called stationary if its statistical properties like mean, variance, and autocorrelation do not change over time. Stationarity is very important in forecasting because most models (like ARIMA) work only on stationary data. If a series is not stationary, we usually make it stationary using differencing, detrending, or removing seasonality. Points: \u2022 Mean and variance constant over time \u2022 No trend or seasonality \u2022 Easier to model and predict Diagram to draw: Compare one non-stationary series (with upward trend) and one stationary series (random fluctuations around mean 0). 2. Explain ARIMA in detail with diagram and explanation. ARIMA stands for Auto-Regressive Integrated Moving Average. \u2022 AR (Auto-Regressive): The current value depends on past values. \u2022 I (Integrated): Differencing of raw observations to make the series stationary. \u2022 MA (Moving Average): The current value depends on past error terms. It is written as ARIMA(p, d, q), where: \u2022 p = order of AR part \u2022 d = order of differencing \u2022 q = order of MA part Example: ARIMA(1,1,1) means 1 autoregressive term, differencing once, and 1 moving average term. Diagram to draw: A block diagram showi ng AR \u2192 Differencing \u2192 MA steps. 3. What is ACF? Explain in detail with diagram and example. ACF (Autocorrelation Function) measures the correlation of a time series with its own past values (lags). It helps to identify seasonality and the order of MA models. Points: \u2022 Shows how current values are related to previous values. \u2022 Useful in identifying patterns in the data. \u2022 ACF gradually decreases for AR models, but cuts off sharply after q lags for MA models. Diagram to draw: ACF bar chart (correlogram) showing spikes at lags. 4. What is PACF? Explain with example and diagram. PACF (Partial Autocorrelation Function) measures the correlation between a series and its lag, after removing the effects of intermediate lags. Points: \u2022 Helps identify the order of AR models. \u2022 PACF cuts off after p lags in AR models. \u2022 In MA models, PACF tails off gradually. Diagram to draw: PACF plot showing cutoff after certain lags. 5. Explain what is Moving Average with graph. A Moving Average (MA) is a statistical method used in time series analysis to smooth out short-term fluctuations and highlight long- term trends or patterns. It works by taking the average of data points over a fixed number of periods (like days, weeks, or months) and then updating this average as new data comes in. Points: \u2022 Simple method to smooth time series data. \u2022 Can be Simple Moving Average (SMA) or Weighted Moving Average (WMA). \u2022 Used for short-term forecasting. In the graph: \u2022 The small red and green lines represent the daily stock prices (they go up and down sharply). \u2022 The blue line is the 50-day Simple Moving Average (SMA). o This line is smoother because it averages the last 50 days of stock prices. o It reduces noise from daily ups and downs and show\n\ngive me summary"}]}
ERROR - 2026-01-06 11:32:54 --> Severity: Warning --> Undefined property: stdClass::$name D:\Versions\UAI App\Neha's Version\FInal final\UAI Website\application\views\simple_portal\generate_assignment.php 138
ERROR - 2026-01-06 11:32:54 --> Severity: Warning --> Undefined property: stdClass::$name D:\Versions\UAI App\Neha's Version\FInal final\UAI Website\application\views\simple_portal\generate_assignment.php 138
ERROR - 2026-01-06 11:32:54 --> Severity: Warning --> Undefined property: stdClass::$name D:\Versions\UAI App\Neha's Version\FInal final\UAI Website\application\views\simple_portal\generate_assignment.php 138
ERROR - 2026-01-06 11:32:54 --> Severity: Warning --> Undefined property: stdClass::$name D:\Versions\UAI App\Neha's Version\FInal final\UAI Website\application\views\simple_portal\generate_assignment.php 138
ERROR - 2026-01-06 11:32:54 --> Severity: Warning --> Undefined property: stdClass::$name D:\Versions\UAI App\Neha's Version\FInal final\UAI Website\application\views\simple_portal\generate_assignment.php 138
ERROR - 2026-01-06 11:32:54 --> Severity: Warning --> Undefined property: stdClass::$name D:\Versions\UAI App\Neha's Version\FInal final\UAI Website\application\views\simple_portal\generate_assignment.php 138
ERROR - 2026-01-06 11:32:54 --> Severity: Warning --> Undefined property: stdClass::$name D:\Versions\UAI App\Neha's Version\FInal final\UAI Website\application\views\simple_portal\generate_assignment.php 138
ERROR - 2026-01-06 11:32:54 --> Severity: Warning --> Undefined property: stdClass::$name D:\Versions\UAI App\Neha's Version\FInal final\UAI Website\application\views\simple_portal\generate_assignment.php 138
ERROR - 2026-01-06 11:32:54 --> Severity: Warning --> Undefined property: stdClass::$name D:\Versions\UAI App\Neha's Version\FInal final\UAI Website\application\views\simple_portal\generate_assignment.php 138
ERROR - 2026-01-06 11:32:54 --> Severity: Warning --> Undefined property: stdClass::$name D:\Versions\UAI App\Neha's Version\FInal final\UAI Website\application\views\simple_portal\generate_assignment.php 138
ERROR - 2026-01-06 11:32:54 --> Severity: Warning --> Undefined property: stdClass::$name D:\Versions\UAI App\Neha's Version\FInal final\UAI Website\application\views\simple_portal\generate_assignment.php 138
ERROR - 2026-01-06 11:32:54 --> Severity: Warning --> Undefined property: stdClass::$name D:\Versions\UAI App\Neha's Version\FInal final\UAI Website\application\views\simple_portal\generate_assignment.php 138
ERROR - 2026-01-06 11:32:54 --> Severity: Warning --> Undefined property: stdClass::$name D:\Versions\UAI App\Neha's Version\FInal final\UAI Website\application\views\simple_portal\generate_assignment.php 138
ERROR - 2026-01-06 11:32:54 --> Severity: Warning --> Undefined property: stdClass::$name D:\Versions\UAI App\Neha's Version\FInal final\UAI Website\application\views\simple_portal\generate_assignment.php 138
ERROR - 2026-01-06 11:32:54 --> Severity: Warning --> Undefined property: stdClass::$name D:\Versions\UAI App\Neha's Version\FInal final\UAI Website\application\views\simple_portal\generate_assignment.php 138
ERROR - 2026-01-06 11:32:54 --> Severity: Warning --> Undefined property: stdClass::$name D:\Versions\UAI App\Neha's Version\FInal final\UAI Website\application\views\simple_portal\generate_assignment.php 138
ERROR - 2026-01-06 11:32:54 --> Severity: Warning --> Undefined property: stdClass::$name D:\Versions\UAI App\Neha's Version\FInal final\UAI Website\application\views\simple_portal\generate_assignment.php 138
ERROR - 2026-01-06 11:32:54 --> Severity: Warning --> Undefined property: stdClass::$name D:\Versions\UAI App\Neha's Version\FInal final\UAI Website\application\views\simple_portal\generate_assignment.php 138
ERROR - 2026-01-06 11:32:54 --> Severity: Warning --> Undefined property: stdClass::$name D:\Versions\UAI App\Neha's Version\FInal final\UAI Website\application\views\simple_portal\generate_assignment.php 138
ERROR - 2026-01-06 11:32:54 --> Severity: Warning --> Undefined property: stdClass::$name D:\Versions\UAI App\Neha's Version\FInal final\UAI Website\application\views\simple_portal\generate_assignment.php 138
ERROR - 2026-01-06 11:32:54 --> Severity: Warning --> Undefined property: stdClass::$name D:\Versions\UAI App\Neha's Version\FInal final\UAI Website\application\views\simple_portal\generate_assignment.php 138
ERROR - 2026-01-06 11:32:54 --> Severity: Warning --> Undefined property: stdClass::$name D:\Versions\UAI App\Neha's Version\FInal final\UAI Website\application\views\simple_portal\generate_assignment.php 138
ERROR - 2026-01-06 11:32:54 --> Severity: Warning --> Undefined property: stdClass::$name D:\Versions\UAI App\Neha's Version\FInal final\UAI Website\application\views\simple_portal\generate_assignment.php 138
ERROR - 2026-01-06 11:32:54 --> Severity: Warning --> Undefined property: stdClass::$name D:\Versions\UAI App\Neha's Version\FInal final\UAI Website\application\views\simple_portal\generate_assignment.php 138
ERROR - 2026-01-06 11:32:54 --> Severity: Warning --> Undefined property: stdClass::$name D:\Versions\UAI App\Neha's Version\FInal final\UAI Website\application\views\simple_portal\generate_assignment.php 138
ERROR - 2026-01-06 11:32:54 --> Severity: Warning --> Undefined property: stdClass::$name D:\Versions\UAI App\Neha's Version\FInal final\UAI Website\application\views\simple_portal\generate_assignment.php 138
ERROR - 2026-01-06 11:32:54 --> Severity: Warning --> Undefined property: stdClass::$name D:\Versions\UAI App\Neha's Version\FInal final\UAI Website\application\views\simple_portal\generate_assignment.php 138
ERROR - 2026-01-06 11:32:54 --> Severity: Warning --> Undefined property: stdClass::$name D:\Versions\UAI App\Neha's Version\FInal final\UAI Website\application\views\simple_portal\generate_assignment.php 138
ERROR - 2026-01-06 11:32:54 --> Severity: Warning --> Undefined property: stdClass::$name D:\Versions\UAI App\Neha's Version\FInal final\UAI Website\application\views\simple_portal\generate_assignment.php 138
ERROR - 2026-01-06 11:32:54 --> Severity: Warning --> Undefined property: stdClass::$name D:\Versions\UAI App\Neha's Version\FInal final\UAI Website\application\views\simple_portal\generate_assignment.php 138
ERROR - 2026-01-06 11:32:54 --> Severity: Warning --> Undefined property: stdClass::$name D:\Versions\UAI App\Neha's Version\FInal final\UAI Website\application\views\simple_portal\generate_assignment.php 138
ERROR - 2026-01-06 11:32:54 --> Severity: Warning --> Undefined property: stdClass::$name D:\Versions\UAI App\Neha's Version\FInal final\UAI Website\application\views\simple_portal\generate_assignment.php 138
ERROR - 2026-01-06 11:45:58 --> PDF EXTRACTION: Starting extraction for: D:\Versions\UAI App\Neha's Version\FInal final\UAI Website\uploads/resources/resource_1767682424_695cb178a72de.pdf
ERROR - 2026-01-06 11:45:58 --> PDF EXTRACTION: Checking for vendor autoload at: D:\Versions\UAI App\Neha's Version\FInal final\UAI Website\vendor/autoload.php
ERROR - 2026-01-06 11:45:58 --> PDF EXTRACTION: Vendor autoload exists: YES
ERROR - 2026-01-06 11:45:58 --> PDF EXTRACTION: Vendor autoload loaded successfully
ERROR - 2026-01-06 11:45:58 --> PDF EXTRACTION: Creating Smalot parser instance
ERROR - 2026-01-06 11:45:58 --> PDF EXTRACTION: Parsing file...
ERROR - 2026-01-06 11:45:58 --> PDF EXTRACTION: Extracting text...
ERROR - 2026-01-06 11:45:58 --> PDF EXTRACTION: Raw text length: 6848
ERROR - 2026-01-06 11:45:58 --> PDF EXTRACTION: First 200 chars: 1. What is stationarity in TSM? 
A time series is called stationary if its statistical properties like 
mean, variance, and autocorrelation do not change over time. 
Stationarity is very important in 
ERROR - 2026-01-06 11:45:58 --> PDF EXTRACTION: Success! Cleaning text...
ERROR - 2026-01-06 11:45:58 --> PDF EXTRACTION: Cleaned text length: 6694
ERROR - 2026-01-06 11:45:58 --> AI API DEBUG: Received 2 messages to process
ERROR - 2026-01-06 11:45:58 --> AI API DEBUG: Found system message, length: 187
ERROR - 2026-01-06 11:45:58 --> AI API DEBUG: Added user message, length: 7832
ERROR - 2026-01-06 11:45:58 --> AI API DEBUG: After initial processing, contents count: 1
ERROR - 2026-01-06 11:45:58 --> AI API DEBUG: After filtering, contents count: 1
ERROR - 2026-01-06 11:45:58 --> AI API DEBUG: Prepended system instruction. Original: 7832, New: 8021
ERROR - 2026-01-06 11:45:58 --> AI API DEBUG: Final contents count before sending: 1
ERROR - 2026-01-06 11:45:58 --> AI API DEBUG: Contents structure: [{"role":"user","text_length":8021}]
ERROR - 2026-01-06 11:45:58 --> AI API DEBUG: Data structure to send: {"contents_count":1}
ERROR - 2026-01-06 11:45:58 --> AI API DEBUG: JSON encode error code: 0
ERROR - 2026-01-06 11:45:58 --> AI API DEBUG: JSON payload length: 8289
ERROR - 2026-01-06 11:45:58 --> AI API DEBUG: JSON payload (first 1000 chars): {"contents":[{"role":"user","parts":[{"text":"You are a JSON generator. You ONLY output JSON. Never use markdown. Never use code blocks. Never use ```json. Start with { and end with }. You are an expert educator creating assignments.\n\nCreate a research assignment requiring analysis and investigation based on the following document content. \r\n\r\nAssignment Requirements:\r\n- Title: time series assignment\r\n- Type: research\r\n- Difficulty: intermediate level with moderate complexity\r\n- Target word count: 1000 words\r\n- Due in: 2 weeks\r\n\r\nFormat the response as JSON with this structure:\r\n{\r\n  \"assignment\": {\r\n    \"title\": \"Assignment title\",\r\n    \"description\": \"Detailed assignment description\",\r\n    \"objectives\": [\"Learning objective 1\", \"Learning objective 2\"],\r\n    \"tasks\": [\r\n      {\r\n        \"task_number\": 1,\r\n        \"task_title\": \"Task title\",\r\n        \"description\": \"What students need to do\",\r\n        \"word_count\":
ERROR - 2026-01-06 11:45:58 --> AI API DEBUG: Raw contents array count: 1
ERROR - 2026-01-06 11:45:58 --> AI API DEBUG: First content item: {"role":"user","parts":[{"text":"You are a JSON generator. You ONLY output JSON. Never use markdown. Never use code blocks. Never use ```json. Start with { and end with }. You are an expert educator creating assignments.\n\nCreate a research assignment requiring analysis and investigation based on the following document content. \r\n\r\nAssignment Requirements:\r\n- Title: time series assignment\r\n- Type: research\r\n- Difficulty: intermediate level with moderate complexity\r\n- Target word count: 1000 words\r\n- Due in: 2 weeks\r\n\r\nFormat the response as JSON with this structure:\r\n{\r\n  \"assignment\": {\r\n    \"title\": \"Assignment title\",\r\n    \"description\": \"Detailed assignment description\",\r\n    \"objectives\": [\"Learning objective 1\", \"Learning objective 2\"],\r\n    \"tasks\": [\r\n      {\r\n        \"task_number\": 1,\r\n        \"task_title\": \"Task title\",\r\n        \"description\": \"What students need to do\",\r\n        \"word_count\": 300\r\n      }\r\n    ],\r\n    \"evaluation_criteria\": [\r\n      {\r\n        \"criterion\": \"Content Quality\",\r\n        \"weight\": \"40%\",\r\n        \"description\": \"How content will be evaluated\"\r\n      }\r\n    ],\r\n    \"resources\": [\"Suggested resource 1\", \"Suggested resource 2\"],\r\n    \"submission_guidelines\": [\"Guideline 1\", \"Guideline 2\"],\r\n    \"due_date\": \"Due in 2 weeks\",\r\n    \"total_marks\": 100\r\n  }\r\n}\r\n\r\nDocument Content:\r\n\n\n=== TimeSeries PDF ===\n1. What is stationarity in TSM? A time series is called stationary if its statistical properties like mean, variance, and autocorrelation do not change over time. Stationarity is very important in forecasting because most models (like ARIMA) work only on stationary data. If a series is not stationary, we usually make it stationary using differencing, detrending, or removing seasonality. Points: \u2022 Mean and variance constant over time \u2022 No trend or seasonality \u2022 Easier to model and predict Diagram to draw: Compare one non-stationary series (with upward trend) and one stationary series (random fluctuations around mean 0). 2. Explain ARIMA in detail with diagram and explanation. ARIMA stands for Auto-Regressive Integrated Moving Average. \u2022 AR (Auto-Regressive): The current value depends on past values. \u2022 I (Integrated): Differencing of raw observations to make the series stationary. \u2022 MA (Moving Average): The current value depends on past error terms. It is written as ARIMA(p, d, q), where: \u2022 p = order of AR part \u2022 d = order of differencing \u2022 q = order of MA part Example: ARIMA(1,1,1) means 1 autoregressive term, differencing once, and 1 moving average term. Diagram to draw: A block diagram showi ng AR \u2192 Differencing \u2192 MA steps. 3. What is ACF? Explain in detail with diagram and example. ACF (Autocorrelation Function) measures the correlation of a time series with its own past values (lags). It helps to identify seasonality and the order of MA models. Points: \u2022 Shows how current values are related to previous values. \u2022 Useful in identifying patterns in the data. \u2022 ACF gradually decreases for AR models, but cuts off sharply after q lags for MA models. Diagram to draw: ACF bar chart (correlogram) showing spikes at lags. 4. What is PACF? Explain with example and diagram. PACF (Partial Autocorrelation Function) measures the correlation between a series and its lag, after removing the effects of intermediate lags. Points: \u2022 Helps identify the order of AR models. \u2022 PACF cuts off after p lags in AR models. \u2022 In MA models, PACF tails off gradually. Diagram to draw: PACF plot showing cutoff after certain lags. 5. Explain what is Moving Average with graph. A Moving Average (MA) is a statistical method used in time series analysis to smooth out short-term fluctuations and highlight long- term trends or patterns. It works by taking the average of data points over a fixed number of periods (like days, weeks, or months) and then updating this average as new data comes in. Points: \u2022 Simple method to smooth time series data. \u2022 Can be Simple Moving Average (SMA) or Weighted Moving Average (WMA). \u2022 Used for short-term forecasting. In the graph: \u2022 The small red and green lines represent the daily stock prices (they go up and down sharply). \u2022 The blue line is the 50-day Simple Moving Average (SMA). o This line is smoother because it averages the last 50 days of stock prices. o It reduces noise from daily ups and downs and shows the overall trend (whether the stock is generally rising or falling). For example: \u2022 Around May\u2013July, the stock fell sharply, and the moving average also went down. \u2022 From Oct\u2013Dec, the stock rose again, and the moving average moved upward too. Diagram to draw: Original noisy series with a smooth moving average line. 6. Explain the graph of decomposition. Time series can be decomposed into: 1. Trend (T) \u2013 long-term increase or decrease 2. Seasonality (S) \u2013 repeating short-term cycle 3. Residual (R) \u2013 random noise So, Time Series = Trend + Seasonality + Residual. Explanation of the Graph The graph is divided into four panels: 1. Observed (Top graph): o This is the original time series (1949\u20131960). o We see both a rising trend and repeating seasonal fluctuations. 2. Trend (Second graph): o Shows the long-term upward movement. o The series is steadily increasing over time, meaning the values are growing overall. 3. Seasonal (Third graph): o Captures repeating patterns within each year. o Notice the same up-and-down cycle repeats every 12 months \u2192 this shows yearly seasonality. 4. Residual (Bottom graph): o Represents the irregular part of the data after removing trend and seasonality. o These are random variations, which don\u2019t follow a fixed pattern. Diagram to draw: Show decomposition plot (original series \u2192 trend \u2192 seasonality \u2192 residual). 7. What is SARIMA? Explain in detail. SARIMA (Seasonal Autoregressive Integrated Moving Average) is a time series forecasting model that is used when the data shows both trend and seasonality. It is an extension of the ARIMA model that adds seasonal components. SARIMA(p, d, q)(P, D, Q)m \u2022 (p, d, q) \u2192 ARIMA terms \u2022 (P, D, Q) \u2192 seasonal terms \u2022 m \u2192 length of seasonality Here, p is the order of autoregression, d is the order of differencing to remove trend, and q is the order of moving average. In simple terms, SARIMA first removes trends and seasonal patterns using differencing, then models short-term dependencies using AR and MA terms, and finally captures repeating seasonal effects using seasonal AR and MA terms. The steps to use SARIMA are: analyze the data, apply necessary differencing, choose suitable parameters, fit the model, check the residuals (errors), and then forecast future values. Example: For monthly sales with yearly pattern, SARIMA is useful. Diagram to draw: Show yearly repeating cycles with SARIMA model structure. 8. What is Exponential Smoothing? Exponential smoothing forecasts future values by giving more weight to recent observations while still considering older ones. Points: \u2022 Uses smoothing factor \u03b1 (0\u20131). \u2022 High \u03b1 \u2192 more weight to recent values. \u2022 Types: Simple, Double (Holt\u2019s), and Triple (Holt-Winters). Diagram to draw: Compare forecasts with high \u03b1 vs low \u03b1. 9. What is White Noise? White Noise is a random time series where values are completely uncorrelated, with constant mean and variance. Points: \u2022 No trend or seasonality \u2022 Mean = 0, constant variance \u2022 ACF shows no significant correlation Diagram to draw: Random scatter plot with no visible pattern. 10. Differencing concept explain in detail. Differencing is a way to turn a non-stationary time series (one with a trend or changing mean) into a stationary one by subtracting past values. A stationary series has a constant mean and variance over time, which many forecasting methods (like ARIMA) require. Types: \u2022 First-order differencing: Yt \u2013 Yt-1 \u2022 Second-order differencing: difference applied twice Points: \u2022 Removes trend and seasonality \u2022 Helps in ARIMA modeling Diagram to draw: Show non-stationary series and its differenced stationary version."}]}
ERROR - 2026-01-06 11:47:20 --> PDF EXTRACTION: Starting extraction for: D:\Versions\UAI App\Neha's Version\FInal final\UAI Website\uploads/resources/resource_1767682424_695cb178a72de.pdf
ERROR - 2026-01-06 11:47:20 --> PDF EXTRACTION: Checking for vendor autoload at: D:\Versions\UAI App\Neha's Version\FInal final\UAI Website\vendor/autoload.php
ERROR - 2026-01-06 11:47:20 --> PDF EXTRACTION: Vendor autoload exists: YES
ERROR - 2026-01-06 11:47:20 --> PDF EXTRACTION: Vendor autoload loaded successfully
ERROR - 2026-01-06 11:47:20 --> PDF EXTRACTION: Creating Smalot parser instance
ERROR - 2026-01-06 11:47:20 --> PDF EXTRACTION: Parsing file...
ERROR - 2026-01-06 11:47:20 --> PDF EXTRACTION: Extracting text...
ERROR - 2026-01-06 11:47:21 --> PDF EXTRACTION: Raw text length: 6848
ERROR - 2026-01-06 11:47:21 --> PDF EXTRACTION: First 200 chars: 1. What is stationarity in TSM? 
A time series is called stationary if its statistical properties like 
mean, variance, and autocorrelation do not change over time. 
Stationarity is very important in 
ERROR - 2026-01-06 11:47:21 --> PDF EXTRACTION: Success! Cleaning text...
ERROR - 2026-01-06 11:47:21 --> PDF EXTRACTION: Cleaned text length: 6694
ERROR - 2026-01-06 11:47:21 --> AI API DEBUG: Received 2 messages to process
ERROR - 2026-01-06 11:47:21 --> AI API DEBUG: Found system message, length: 187
ERROR - 2026-01-06 11:47:21 --> AI API DEBUG: Added user message, length: 7831
ERROR - 2026-01-06 11:47:21 --> AI API DEBUG: After initial processing, contents count: 1
ERROR - 2026-01-06 11:47:21 --> AI API DEBUG: After filtering, contents count: 1
ERROR - 2026-01-06 11:47:21 --> AI API DEBUG: Prepended system instruction. Original: 7831, New: 8020
ERROR - 2026-01-06 11:47:21 --> AI API DEBUG: Final contents count before sending: 1
ERROR - 2026-01-06 11:47:21 --> AI API DEBUG: Contents structure: [{"role":"user","text_length":8020}]
ERROR - 2026-01-06 11:47:21 --> AI API DEBUG: Data structure to send: {"contents_count":1}
ERROR - 2026-01-06 11:47:21 --> AI API DEBUG: JSON encode error code: 0
ERROR - 2026-01-06 11:47:21 --> AI API DEBUG: JSON payload length: 8288
ERROR - 2026-01-06 11:47:21 --> AI API DEBUG: JSON payload (first 1000 chars): {"contents":[{"role":"user","parts":[{"text":"You are a JSON generator. You ONLY output JSON. Never use markdown. Never use code blocks. Never use ```json. Start with { and end with }. You are an expert educator creating assignments.\n\nCreate a research assignment requiring analysis and investigation based on the following document content. \r\n\r\nAssignment Requirements:\r\n- Title: time series assignment\r\n- Type: research\r\n- Difficulty: intermediate level with moderate complexity\r\n- Target word count: 500 words\r\n- Due in: 2 weeks\r\n\r\nFormat the response as JSON with this structure:\r\n{\r\n  \"assignment\": {\r\n    \"title\": \"Assignment title\",\r\n    \"description\": \"Detailed assignment description\",\r\n    \"objectives\": [\"Learning objective 1\", \"Learning objective 2\"],\r\n    \"tasks\": [\r\n      {\r\n        \"task_number\": 1,\r\n        \"task_title\": \"Task title\",\r\n        \"description\": \"What students need to do\",\r\n        \"word_count\": 
ERROR - 2026-01-06 11:47:21 --> AI API DEBUG: Raw contents array count: 1
ERROR - 2026-01-06 11:47:21 --> AI API DEBUG: First content item: {"role":"user","parts":[{"text":"You are a JSON generator. You ONLY output JSON. Never use markdown. Never use code blocks. Never use ```json. Start with { and end with }. You are an expert educator creating assignments.\n\nCreate a research assignment requiring analysis and investigation based on the following document content. \r\n\r\nAssignment Requirements:\r\n- Title: time series assignment\r\n- Type: research\r\n- Difficulty: intermediate level with moderate complexity\r\n- Target word count: 500 words\r\n- Due in: 2 weeks\r\n\r\nFormat the response as JSON with this structure:\r\n{\r\n  \"assignment\": {\r\n    \"title\": \"Assignment title\",\r\n    \"description\": \"Detailed assignment description\",\r\n    \"objectives\": [\"Learning objective 1\", \"Learning objective 2\"],\r\n    \"tasks\": [\r\n      {\r\n        \"task_number\": 1,\r\n        \"task_title\": \"Task title\",\r\n        \"description\": \"What students need to do\",\r\n        \"word_count\": 300\r\n      }\r\n    ],\r\n    \"evaluation_criteria\": [\r\n      {\r\n        \"criterion\": \"Content Quality\",\r\n        \"weight\": \"40%\",\r\n        \"description\": \"How content will be evaluated\"\r\n      }\r\n    ],\r\n    \"resources\": [\"Suggested resource 1\", \"Suggested resource 2\"],\r\n    \"submission_guidelines\": [\"Guideline 1\", \"Guideline 2\"],\r\n    \"due_date\": \"Due in 2 weeks\",\r\n    \"total_marks\": 100\r\n  }\r\n}\r\n\r\nDocument Content:\r\n\n\n=== TimeSeries PDF ===\n1. What is stationarity in TSM? A time series is called stationary if its statistical properties like mean, variance, and autocorrelation do not change over time. Stationarity is very important in forecasting because most models (like ARIMA) work only on stationary data. If a series is not stationary, we usually make it stationary using differencing, detrending, or removing seasonality. Points: \u2022 Mean and variance constant over time \u2022 No trend or seasonality \u2022 Easier to model and predict Diagram to draw: Compare one non-stationary series (with upward trend) and one stationary series (random fluctuations around mean 0). 2. Explain ARIMA in detail with diagram and explanation. ARIMA stands for Auto-Regressive Integrated Moving Average. \u2022 AR (Auto-Regressive): The current value depends on past values. \u2022 I (Integrated): Differencing of raw observations to make the series stationary. \u2022 MA (Moving Average): The current value depends on past error terms. It is written as ARIMA(p, d, q), where: \u2022 p = order of AR part \u2022 d = order of differencing \u2022 q = order of MA part Example: ARIMA(1,1,1) means 1 autoregressive term, differencing once, and 1 moving average term. Diagram to draw: A block diagram showi ng AR \u2192 Differencing \u2192 MA steps. 3. What is ACF? Explain in detail with diagram and example. ACF (Autocorrelation Function) measures the correlation of a time series with its own past values (lags). It helps to identify seasonality and the order of MA models. Points: \u2022 Shows how current values are related to previous values. \u2022 Useful in identifying patterns in the data. \u2022 ACF gradually decreases for AR models, but cuts off sharply after q lags for MA models. Diagram to draw: ACF bar chart (correlogram) showing spikes at lags. 4. What is PACF? Explain with example and diagram. PACF (Partial Autocorrelation Function) measures the correlation between a series and its lag, after removing the effects of intermediate lags. Points: \u2022 Helps identify the order of AR models. \u2022 PACF cuts off after p lags in AR models. \u2022 In MA models, PACF tails off gradually. Diagram to draw: PACF plot showing cutoff after certain lags. 5. Explain what is Moving Average with graph. A Moving Average (MA) is a statistical method used in time series analysis to smooth out short-term fluctuations and highlight long- term trends or patterns. It works by taking the average of data points over a fixed number of periods (like days, weeks, or months) and then updating this average as new data comes in. Points: \u2022 Simple method to smooth time series data. \u2022 Can be Simple Moving Average (SMA) or Weighted Moving Average (WMA). \u2022 Used for short-term forecasting. In the graph: \u2022 The small red and green lines represent the daily stock prices (they go up and down sharply). \u2022 The blue line is the 50-day Simple Moving Average (SMA). o This line is smoother because it averages the last 50 days of stock prices. o It reduces noise from daily ups and downs and shows the overall trend (whether the stock is generally rising or falling). For example: \u2022 Around May\u2013July, the stock fell sharply, and the moving average also went down. \u2022 From Oct\u2013Dec, the stock rose again, and the moving average moved upward too. Diagram to draw: Original noisy series with a smooth moving average line. 6. Explain the graph of decomposition. Time series can be decomposed into: 1. Trend (T) \u2013 long-term increase or decrease 2. Seasonality (S) \u2013 repeating short-term cycle 3. Residual (R) \u2013 random noise So, Time Series = Trend + Seasonality + Residual. Explanation of the Graph The graph is divided into four panels: 1. Observed (Top graph): o This is the original time series (1949\u20131960). o We see both a rising trend and repeating seasonal fluctuations. 2. Trend (Second graph): o Shows the long-term upward movement. o The series is steadily increasing over time, meaning the values are growing overall. 3. Seasonal (Third graph): o Captures repeating patterns within each year. o Notice the same up-and-down cycle repeats every 12 months \u2192 this shows yearly seasonality. 4. Residual (Bottom graph): o Represents the irregular part of the data after removing trend and seasonality. o These are random variations, which don\u2019t follow a fixed pattern. Diagram to draw: Show decomposition plot (original series \u2192 trend \u2192 seasonality \u2192 residual). 7. What is SARIMA? Explain in detail. SARIMA (Seasonal Autoregressive Integrated Moving Average) is a time series forecasting model that is used when the data shows both trend and seasonality. It is an extension of the ARIMA model that adds seasonal components. SARIMA(p, d, q)(P, D, Q)m \u2022 (p, d, q) \u2192 ARIMA terms \u2022 (P, D, Q) \u2192 seasonal terms \u2022 m \u2192 length of seasonality Here, p is the order of autoregression, d is the order of differencing to remove trend, and q is the order of moving average. In simple terms, SARIMA first removes trends and seasonal patterns using differencing, then models short-term dependencies using AR and MA terms, and finally captures repeating seasonal effects using seasonal AR and MA terms. The steps to use SARIMA are: analyze the data, apply necessary differencing, choose suitable parameters, fit the model, check the residuals (errors), and then forecast future values. Example: For monthly sales with yearly pattern, SARIMA is useful. Diagram to draw: Show yearly repeating cycles with SARIMA model structure. 8. What is Exponential Smoothing? Exponential smoothing forecasts future values by giving more weight to recent observations while still considering older ones. Points: \u2022 Uses smoothing factor \u03b1 (0\u20131). \u2022 High \u03b1 \u2192 more weight to recent values. \u2022 Types: Simple, Double (Holt\u2019s), and Triple (Holt-Winters). Diagram to draw: Compare forecasts with high \u03b1 vs low \u03b1. 9. What is White Noise? White Noise is a random time series where values are completely uncorrelated, with constant mean and variance. Points: \u2022 No trend or seasonality \u2022 Mean = 0, constant variance \u2022 ACF shows no significant correlation Diagram to draw: Random scatter plot with no visible pattern. 10. Differencing concept explain in detail. Differencing is a way to turn a non-stationary time series (one with a trend or changing mean) into a stationary one by subtracting past values. A stationary series has a constant mean and variance over time, which many forecasting methods (like ARIMA) require. Types: \u2022 First-order differencing: Yt \u2013 Yt-1 \u2022 Second-order differencing: difference applied twice Points: \u2022 Removes trend and seasonality \u2022 Helps in ARIMA modeling Diagram to draw: Show non-stationary series and its differenced stationary version."}]}
ERROR - 2026-01-06 12:01:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2026-01-06 12:04:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2026-01-06 12:08:39 --> Severity: Warning --> Undefined property: stdClass::$question_count D:\Versions\UAI App\Neha's Version\FInal final\UAI Website\application\views\simple_portal\student_assignments.php 456
ERROR - 2026-01-06 12:08:50 --> Severity: Warning --> Undefined property: stdClass::$question_count D:\Versions\UAI App\Neha's Version\FInal final\UAI Website\application\views\simple_portal\student_quizzes.php 446
ERROR - 2026-01-06 12:08:50 --> Severity: Warning --> Undefined property: stdClass::$question_count D:\Versions\UAI App\Neha's Version\FInal final\UAI Website\application\views\simple_portal\student_quizzes.php 446
ERROR - 2026-01-06 12:08:50 --> Severity: Warning --> Undefined property: stdClass::$question_count D:\Versions\UAI App\Neha's Version\FInal final\UAI Website\application\views\simple_portal\student_quizzes.php 446
ERROR - 2026-01-06 12:08:54 --> Severity: Warning --> Undefined property: stdClass::$question_count D:\Versions\UAI App\Neha's Version\FInal final\UAI Website\application\views\simple_portal\student_assignments.php 456
ERROR - 2026-01-06 12:08:55 --> Severity: Warning --> Undefined property: stdClass::$question_count D:\Versions\UAI App\Neha's Version\FInal final\UAI Website\application\views\simple_portal\student_quizzes.php 446
ERROR - 2026-01-06 12:08:55 --> Severity: Warning --> Undefined property: stdClass::$question_count D:\Versions\UAI App\Neha's Version\FInal final\UAI Website\application\views\simple_portal\student_quizzes.php 446
ERROR - 2026-01-06 12:08:55 --> Severity: Warning --> Undefined property: stdClass::$question_count D:\Versions\UAI App\Neha's Version\FInal final\UAI Website\application\views\simple_portal\student_quizzes.php 446
ERROR - 2026-01-06 12:08:57 --> Severity: Warning --> Undefined property: stdClass::$question_count D:\Versions\UAI App\Neha's Version\FInal final\UAI Website\application\views\simple_portal\student_assignments.php 456
ERROR - 2026-01-06 12:08:59 --> Severity: Warning --> Undefined property: stdClass::$question_count D:\Versions\UAI App\Neha's Version\FInal final\UAI Website\application\views\simple_portal\student_quizzes.php 446
ERROR - 2026-01-06 12:08:59 --> Severity: Warning --> Undefined property: stdClass::$question_count D:\Versions\UAI App\Neha's Version\FInal final\UAI Website\application\views\simple_portal\student_quizzes.php 446
ERROR - 2026-01-06 12:08:59 --> Severity: Warning --> Undefined property: stdClass::$question_count D:\Versions\UAI App\Neha's Version\FInal final\UAI Website\application\views\simple_portal\student_quizzes.php 446
ERROR - 2026-01-06 12:09:01 --> Severity: Warning --> Undefined property: stdClass::$question_count D:\Versions\UAI App\Neha's Version\FInal final\UAI Website\application\views\simple_portal\student_assignments.php 456
ERROR - 2026-01-06 12:09:05 --> Severity: Warning --> Undefined property: stdClass::$question_count D:\Versions\UAI App\Neha's Version\FInal final\UAI Website\application\views\simple_portal\student_quizzes.php 446
ERROR - 2026-01-06 12:09:05 --> Severity: Warning --> Undefined property: stdClass::$question_count D:\Versions\UAI App\Neha's Version\FInal final\UAI Website\application\views\simple_portal\student_quizzes.php 446
ERROR - 2026-01-06 12:09:05 --> Severity: Warning --> Undefined property: stdClass::$question_count D:\Versions\UAI App\Neha's Version\FInal final\UAI Website\application\views\simple_portal\student_quizzes.php 446
ERROR - 2026-01-06 12:09:06 --> Severity: Warning --> Undefined property: stdClass::$question_count D:\Versions\UAI App\Neha's Version\FInal final\UAI Website\application\views\simple_portal\student_quizzes.php 446
ERROR - 2026-01-06 12:09:06 --> Severity: Warning --> Undefined property: stdClass::$question_count D:\Versions\UAI App\Neha's Version\FInal final\UAI Website\application\views\simple_portal\student_quizzes.php 446
ERROR - 2026-01-06 12:09:06 --> Severity: Warning --> Undefined property: stdClass::$question_count D:\Versions\UAI App\Neha's Version\FInal final\UAI Website\application\views\simple_portal\student_quizzes.php 446
ERROR - 2026-01-06 12:09:17 --> 404 Page Not Found: Ai_buddy/session
ERROR - 2026-01-06 15:06:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2026-01-06 15:06:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2026-01-06 17:00:18 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it C:\Users\nehas\Downloads\UAI Website to neha\UAI Website\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2026-01-06 17:00:18 --> Unable to connect to the database
ERROR - 2026-01-06 17:02:25 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it C:\Users\nehas\Downloads\UAI Website to neha\UAI Website\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2026-01-06 17:02:25 --> Unable to connect to the database
ERROR - 2026-01-06 17:03:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it C:\Users\nehas\Downloads\UAI Website to neha\UAI Website\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2026-01-06 17:03:02 --> Unable to connect to the database
ERROR - 2026-01-06 17:08:33 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it C:\Users\nehas\Downloads\UAI Website to neha\UAI Website\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2026-01-06 17:08:33 --> Unable to connect to the database
ERROR - 2026-01-06 18:38:24 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it C:\Users\nehas\Downloads\UAI Website to neha\UAI Website\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2026-01-06 18:38:24 --> Unable to connect to the database
ERROR - 2026-01-06 18:39:47 --> Query error: Table 'college_academic_portal.users' doesn't exist - Invalid query: SELECT *
FROM `users`
WHERE `username` = 'admin'
AND `role` = 'admin'
AND `is_active` = 1
ERROR - 2026-01-06 18:40:11 --> Query error: Table 'college_academic_portal.users' doesn't exist - Invalid query: SELECT *
FROM `users`
WHERE `username` = 'Admin'
AND `role` = 'admin'
AND `is_active` = 1
ERROR - 2026-01-06 19:14:42 --> Severity: Warning --> Undefined property: stdClass::$question_count C:\Users\nehas\Downloads\UAI Website to neha\UAI Website\application\views\simple_portal\student_quizzes.php 446
ERROR - 2026-01-06 19:14:42 --> Severity: Warning --> Undefined property: stdClass::$question_count C:\Users\nehas\Downloads\UAI Website to neha\UAI Website\application\views\simple_portal\student_quizzes.php 446
ERROR - 2026-01-06 19:14:42 --> Severity: Warning --> Undefined property: stdClass::$question_count C:\Users\nehas\Downloads\UAI Website to neha\UAI Website\application\views\simple_portal\student_quizzes.php 446
ERROR - 2026-01-06 19:14:51 --> Severity: Warning --> Undefined property: stdClass::$question_count C:\Users\nehas\Downloads\UAI Website to neha\UAI Website\application\views\simple_portal\student_assignments.php 456
ERROR - 2026-01-06 19:15:02 --> 404 Page Not Found: Simple_portal/view_resource
ERROR - 2026-01-06 19:15:07 --> 404 Page Not Found: Simple_portal/view_resource
ERROR - 2026-01-06 19:15:44 --> 404 Page Not Found: Ai_buddy/dashboard
ERROR - 2026-01-06 19:19:52 --> 404 Page Not Found: Ai_buddy/dashboard
ERROR - 2026-01-06 19:20:23 --> 404 Page Not Found: Ai_buddy/dashboard
ERROR - 2026-01-06 19:24:26 --> 404 Page Not Found: Simple_portal/faculty_dashboard
ERROR - 2026-01-06 19:25:46 --> AI Chat: Found resource file: uploads/resources/resource_1767682424_695cb178a72de.pdf, type: pdf
ERROR - 2026-01-06 19:25:46 --> AI Chat: Calling AI service PDF extraction
ERROR - 2026-01-06 19:25:46 --> PDF EXTRACTION: Starting extraction for: C:\Users\nehas\Downloads\UAI Website to neha\UAI Website\uploads/resources/resource_1767682424_695cb178a72de.pdf
ERROR - 2026-01-06 19:25:46 --> PDF EXTRACTION: Checking for vendor autoload at: C:\Users\nehas\Downloads\UAI Website to neha\UAI Website\vendor/autoload.php
ERROR - 2026-01-06 19:25:46 --> PDF EXTRACTION: Vendor autoload exists: YES
ERROR - 2026-01-06 19:25:46 --> PDF EXTRACTION: Vendor autoload loaded successfully
ERROR - 2026-01-06 19:25:46 --> PDF EXTRACTION: Creating Smalot parser instance
ERROR - 2026-01-06 19:25:46 --> PDF EXTRACTION: Parsing file...
ERROR - 2026-01-06 19:25:47 --> PDF EXTRACTION: Extracting text...
ERROR - 2026-01-06 19:25:47 --> PDF EXTRACTION: Raw text length: 6848
ERROR - 2026-01-06 19:25:47 --> PDF EXTRACTION: First 200 chars: 1. What is stationarity in TSM? 
A time series is called stationary if its statistical properties like 
mean, variance, and autocorrelation do not change over time. 
Stationarity is very important in 
ERROR - 2026-01-06 19:25:47 --> PDF EXTRACTION: Success! Cleaning text...
ERROR - 2026-01-06 19:25:47 --> PDF EXTRACTION: Cleaned text length: 6694
ERROR - 2026-01-06 19:25:47 --> AI Chat: PDF extraction returned 6694 characters
ERROR - 2026-01-06 19:25:47 --> AI CHAT DEBUG: Starting chat with 1 messages, system_prompt: YES
ERROR - 2026-01-06 19:25:47 --> AI CHAT DEBUG: Added system prompt, length: 3086
ERROR - 2026-01-06 19:25:47 --> AI CHAT DEBUG: Message 0 is object, role: user, has content: YES
ERROR - 2026-01-06 19:25:47 --> AI CHAT DEBUG: Added message 0 to formatted_messages
ERROR - 2026-01-06 19:25:47 --> AI CHAT DEBUG: Total formatted messages: 2
ERROR - 2026-01-06 19:25:47 --> AI API DEBUG: Received 2 messages to process
ERROR - 2026-01-06 19:25:47 --> AI API DEBUG: Found system message, length: 3086
ERROR - 2026-01-06 19:25:47 --> AI API DEBUG: Added user message, length: 12
ERROR - 2026-01-06 19:25:47 --> AI API DEBUG: After initial processing, contents count: 1
ERROR - 2026-01-06 19:25:47 --> AI API DEBUG: After filtering, contents count: 1
ERROR - 2026-01-06 19:25:47 --> AI API DEBUG: Prepended system instruction. Original: 12, New: 3100
ERROR - 2026-01-06 19:25:47 --> AI API DEBUG: Final contents count before sending: 1
ERROR - 2026-01-06 19:25:47 --> AI API DEBUG: Contents structure: [{"role":"user","text_length":3100}]
ERROR - 2026-01-06 19:25:47 --> AI API DEBUG: Data structure to send: {"contents_count":1}
ERROR - 2026-01-06 19:25:47 --> AI API DEBUG: JSON encode error code: 0
ERROR - 2026-01-06 19:25:47 --> AI API DEBUG: JSON payload length: 3230
ERROR - 2026-01-06 19:25:47 --> AI API DEBUG: JSON payload (first 1000 chars): {"contents":[{"role":"user","parts":[{"text":"You are an AI teaching assistant helping with educational content.\n\nDocument Context:\n1. What is stationarity in TSM? A time series is called stationary if its statistical properties like mean, variance, and autocorrelation do not change over time. Stationarity is very important in forecasting because most models (like ARIMA) work only on stationary data. If a series is not stationary, we usually make it stationary using differencing, detrending, or removing seasonality. Points: • Mean and variance constant over time • No trend or seasonality • Easier to model and predict Diagram to draw: Compare one non-stationary series (with upward trend) and one stationary series (random fluctuations around mean 0). 2. Explain ARIMA in detail with diagram and explanation. ARIMA stands for Auto-Regressive Integrated Moving Average. • AR (Auto-Regressive): The current value depends on past values. • I (Integrated): Differencing of raw observa
ERROR - 2026-01-06 19:25:47 --> AI API DEBUG: Raw contents array count: 1
ERROR - 2026-01-06 19:25:47 --> AI API DEBUG: First content item: {"role":"user","parts":[{"text":"You are an AI teaching assistant helping with educational content.\n\nDocument Context:\n1. What is stationarity in TSM? A time series is called stationary if its statistical properties like mean, variance, and autocorrelation do not change over time. Stationarity is very important in forecasting because most models (like ARIMA) work only on stationary data. If a series is not stationary, we usually make it stationary using differencing, detrending, or removing seasonality. Points: \u2022 Mean and variance constant over time \u2022 No trend or seasonality \u2022 Easier to model and predict Diagram to draw: Compare one non-stationary series (with upward trend) and one stationary series (random fluctuations around mean 0). 2. Explain ARIMA in detail with diagram and explanation. ARIMA stands for Auto-Regressive Integrated Moving Average. \u2022 AR (Auto-Regressive): The current value depends on past values. \u2022 I (Integrated): Differencing of raw observations to make the series stationary. \u2022 MA (Moving Average): The current value depends on past error terms. It is written as ARIMA(p, d, q), where: \u2022 p = order of AR part \u2022 d = order of differencing \u2022 q = order of MA part Example: ARIMA(1,1,1) means 1 autoregressive term, differencing once, and 1 moving average term. Diagram to draw: A block diagram showi ng AR \u2192 Differencing \u2192 MA steps. 3. What is ACF? Explain in detail with diagram and example. ACF (Autocorrelation Function) measures the correlation of a time series with its own past values (lags). It helps to identify seasonality and the order of MA models. Points: \u2022 Shows how current values are related to previous values. \u2022 Useful in identifying patterns in the data. \u2022 ACF gradually decreases for AR models, but cuts off sharply after q lags for MA models. Diagram to draw: ACF bar chart (correlogram) showing spikes at lags. 4. What is PACF? Explain with example and diagram. PACF (Partial Autocorrelation Function) measures the correlation between a series and its lag, after removing the effects of intermediate lags. Points: \u2022 Helps identify the order of AR models. \u2022 PACF cuts off after p lags in AR models. \u2022 In MA models, PACF tails off gradually. Diagram to draw: PACF plot showing cutoff after certain lags. 5. Explain what is Moving Average with graph. A Moving Average (MA) is a statistical method used in time series analysis to smooth out short-term fluctuations and highlight long- term trends or patterns. It works by taking the average of data points over a fixed number of periods (like days, weeks, or months) and then updating this average as new data comes in. Points: \u2022 Simple method to smooth time series data. \u2022 Can be Simple Moving Average (SMA) or Weighted Moving Average (WMA). \u2022 Used for short-term forecasting. In the graph: \u2022 The small red and green lines represent the daily stock prices (they go up and down sharply). \u2022 The blue line is the 50-day Simple Moving Average (SMA). o This line is smoother because it averages the last 50 days of stock prices. o It reduces noise from daily ups and downs and show\n\ngive summary"}]}
ERROR - 2026-01-06 19:45:07 --> 404 Page Not Found: Ai_buddy/dashboard
ERROR - 2026-01-06 19:56:41 --> Severity: Warning --> Undefined property: stdClass::$question_count C:\Users\nehas\Downloads\UAI Website to neha\UAI Website\application\views\simple_portal\student_quizzes.php 446
ERROR - 2026-01-06 19:56:41 --> Severity: Warning --> Undefined property: stdClass::$question_count C:\Users\nehas\Downloads\UAI Website to neha\UAI Website\application\views\simple_portal\student_quizzes.php 446
ERROR - 2026-01-06 19:56:41 --> Severity: Warning --> Undefined property: stdClass::$question_count C:\Users\nehas\Downloads\UAI Website to neha\UAI Website\application\views\simple_portal\student_quizzes.php 446
ERROR - 2026-01-06 19:57:43 --> 404 Page Not Found: Ai_buddy/dashboard
ERROR - 2026-01-06 19:58:03 --> Severity: Warning --> Undefined property: stdClass::$question_count C:\Users\nehas\Downloads\UAI Website to neha\UAI Website\application\views\simple_portal\student_quizzes.php 446
ERROR - 2026-01-06 19:58:03 --> Severity: Warning --> Undefined property: stdClass::$question_count C:\Users\nehas\Downloads\UAI Website to neha\UAI Website\application\views\simple_portal\student_quizzes.php 446
ERROR - 2026-01-06 19:58:03 --> Severity: Warning --> Undefined property: stdClass::$question_count C:\Users\nehas\Downloads\UAI Website to neha\UAI Website\application\views\simple_portal\student_quizzes.php 446
