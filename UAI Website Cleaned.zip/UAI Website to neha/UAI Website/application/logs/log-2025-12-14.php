<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-12-14 11:49:40 --> Query error: Table 'users' already exists - Invalid query: CREATE TABLE `users` (
	`id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
	`username` VARCHAR(50) NOT NULL UNIQUE,
	`email` VARCHAR(100) NOT NULL UNIQUE,
	`password_hash` VARCHAR(255) NOT NULL,
	`role` ENUM('admin','faculty','student') NOT NULL,
	`created_at` TIMESTAMP NOT NULL DEFAULT 'CURRENT_TIMESTAMP',
	`updated_at` TIMESTAMP NOT NULL DEFAULT 'CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP',
	`is_active` BOOLEAN NOT NULL DEFAULT 1,
	CONSTRAINT `pk_users` PRIMARY KEY(`id`),
	KEY `username` (`username`),
	KEY `role` (`role`),
	KEY `is_active` (`is_active`)
) DEFAULT CHARACTER SET = utf8 COLLATE = utf8_general_ci
ERROR - 2025-12-14 11:49:40 --> Query error: Table 'faculty' already exists - Invalid query: CREATE TABLE `faculty` (
	`id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
	`user_id` INT(11) UNSIGNED NOT NULL,
	`employee_id` VARCHAR(20) NULL UNIQUE,
	`department` VARCHAR(100) NULL,
	CONSTRAINT `pk_faculty` PRIMARY KEY(`id`),
	KEY `employee_id` (`employee_id`)
) DEFAULT CHARACTER SET = utf8 COLLATE = utf8_general_ci
ERROR - 2025-12-14 11:49:40 --> Query error: Table 'students' already exists - Invalid query: CREATE TABLE `students` (
	`id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
	`user_id` INT(11) UNSIGNED NOT NULL,
	`student_id` VARCHAR(20) NULL UNIQUE,
	`current_semester` INT(11) NOT NULL,
	`enrollment_year` YEAR NULL,
	CONSTRAINT `pk_students` PRIMARY KEY(`id`),
	KEY `student_id` (`student_id`),
	KEY `current_semester` (`current_semester`)
) DEFAULT CHARACTER SET = utf8 COLLATE = utf8_general_ci
ERROR - 2025-12-14 11:49:40 --> Query error: Table 'subjects' already exists - Invalid query: CREATE TABLE `subjects` (
	`id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
	`subject_code` VARCHAR(20) NOT NULL UNIQUE,
	`subject_name` VARCHAR(200) NOT NULL,
	`semester` INT(11) NOT NULL,
	`credits` INT(11) NOT NULL DEFAULT 3,
	`is_active` BOOLEAN NOT NULL DEFAULT 1,
	CONSTRAINT `pk_subjects` PRIMARY KEY(`id`),
	KEY `semester` (`semester`),
	KEY `subject_code` (`subject_code`),
	KEY `is_active` (`is_active`)
) DEFAULT CHARACTER SET = utf8 COLLATE = utf8_general_ci
ERROR - 2025-12-14 11:49:40 --> Query error: Invalid default value for 'assigned_at' - Invalid query: CREATE TABLE `faculty_subjects` (
	`id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
	`faculty_id` INT(11) UNSIGNED NOT NULL,
	`subject_id` INT(11) UNSIGNED NOT NULL,
	`assigned_at` TIMESTAMP NOT NULL DEFAULT 'CURRENT_TIMESTAMP',
	CONSTRAINT `pk_faculty_subjects` PRIMARY KEY(`id`),
	KEY `faculty_id` (`faculty_id`),
	KEY `subject_id` (`subject_id`)
) DEFAULT CHARACTER SET = utf8 COLLATE = utf8_general_ci
ERROR - 2025-12-14 11:49:40 --> Query error: Table 'college_academic_portal.faculty_subjects' doesn't exist - Invalid query: ALTER TABLE faculty_subjects ADD CONSTRAINT fk_faculty_subjects_faculty FOREIGN KEY (faculty_id) REFERENCES faculty(id) ON DELETE CASCADE
ERROR - 2025-12-14 11:49:40 --> Query error: Table 'college_academic_portal.faculty_subjects' doesn't exist - Invalid query: ALTER TABLE faculty_subjects ADD CONSTRAINT fk_faculty_subjects_subject FOREIGN KEY (subject_id) REFERENCES subjects(id) ON DELETE CASCADE
ERROR - 2025-12-14 11:49:40 --> Query error: Table 'college_academic_portal.faculty_subjects' doesn't exist - Invalid query: ALTER TABLE faculty_subjects ADD CONSTRAINT unique_assignment UNIQUE (faculty_id, subject_id)
ERROR - 2025-12-14 11:49:40 --> Query error: Table 'resources' already exists - Invalid query: CREATE TABLE `resources` (
	`id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
	`subject_id` INT(11) UNSIGNED NOT NULL,
	`faculty_id` INT(11) UNSIGNED NOT NULL,
	`title` VARCHAR(200) NOT NULL,
	`description` TEXT NULL,
	`file_type` ENUM('pdf','ppt','excel','csv','epub','weblink') NOT NULL,
	`file_path` VARCHAR(500) NULL,
	`file_size` BIGINT NULL,
	`upload_date` TIMESTAMP NOT NULL DEFAULT 'CURRENT_TIMESTAMP',
	`is_active` BOOLEAN NOT NULL DEFAULT 1,
	CONSTRAINT `pk_resources` PRIMARY KEY(`id`),
	KEY `subject_id` (`subject_id`),
	KEY `faculty_id` (`faculty_id`),
	KEY `upload_date` (`upload_date`),
	KEY `is_active` (`is_active`)
) DEFAULT CHARACTER SET = utf8 COLLATE = utf8_general_ci
ERROR - 2025-12-14 11:49:40 --> Query error: Table 'assignments' already exists - Invalid query: CREATE TABLE `assignments` (
	`id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
	`subject_id` INT(11) UNSIGNED NOT NULL,
	`faculty_id` INT(11) UNSIGNED NOT NULL,
	`title` VARCHAR(200) NOT NULL,
	`description` TEXT NULL,
	`total_marks` INT(11) NOT NULL,
	`due_date` DATETIME NULL,
	`created_at` TIMESTAMP NOT NULL DEFAULT 'CURRENT_TIMESTAMP',
	`is_ai_generated` BOOLEAN NOT NULL DEFAULT 0,
	CONSTRAINT `pk_assignments` PRIMARY KEY(`id`),
	KEY `subject_id` (`subject_id`),
	KEY `faculty_id` (`faculty_id`),
	KEY `due_date` (`due_date`)
) DEFAULT CHARACTER SET = utf8 COLLATE = utf8_general_ci
ERROR - 2025-12-14 11:49:40 --> Query error: Invalid default value for 'created_at' - Invalid query: CREATE TABLE `question_papers` (
	`id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
	`subject_id` INT(11) UNSIGNED NOT NULL,
	`faculty_id` INT(11) UNSIGNED NOT NULL,
	`title` VARCHAR(200) NOT NULL,
	`total_marks` INT(11) NOT NULL,
	`format_template_id` INT(11) NULL,
	`generated_content` TEXT NULL,
	`created_at` TIMESTAMP NOT NULL DEFAULT 'CURRENT_TIMESTAMP',
	CONSTRAINT `pk_question_papers` PRIMARY KEY(`id`),
	KEY `subject_id` (`subject_id`),
	KEY `faculty_id` (`faculty_id`)
) DEFAULT CHARACTER SET = utf8 COLLATE = utf8_general_ci
ERROR - 2025-12-14 11:49:40 --> Query error: Invalid default value for 'created_at' - Invalid query: CREATE TABLE `paper_formats` (
	`id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
	`faculty_id` INT(11) UNSIGNED NOT NULL,
	`template_name` VARCHAR(100) NOT NULL,
	`format_structure` JSON NULL,
	`sample_image_path` VARCHAR(500) NULL,
	`created_at` TIMESTAMP NOT NULL DEFAULT 'CURRENT_TIMESTAMP',
	CONSTRAINT `pk_paper_formats` PRIMARY KEY(`id`),
	KEY `faculty_id` (`faculty_id`)
) DEFAULT CHARACTER SET = utf8 COLLATE = utf8_general_ci
ERROR - 2025-12-14 11:49:40 --> Query error: Key column 'faculty_id' doesn't exist in table - Invalid query: ALTER TABLE resources ADD CONSTRAINT fk_resources_faculty FOREIGN KEY (faculty_id) REFERENCES faculty(id)
ERROR - 2025-12-14 11:49:40 --> Query error: Table 'college_academic_portal.question_papers' doesn't exist - Invalid query: ALTER TABLE question_papers ADD CONSTRAINT fk_question_papers_subject FOREIGN KEY (subject_id) REFERENCES subjects(id)
ERROR - 2025-12-14 11:49:40 --> Query error: Table 'college_academic_portal.question_papers' doesn't exist - Invalid query: ALTER TABLE question_papers ADD CONSTRAINT fk_question_papers_faculty FOREIGN KEY (faculty_id) REFERENCES faculty(id)
ERROR - 2025-12-14 11:49:40 --> Query error: Table 'college_academic_portal.paper_formats' doesn't exist - Invalid query: ALTER TABLE paper_formats ADD CONSTRAINT fk_paper_formats_faculty FOREIGN KEY (faculty_id) REFERENCES faculty(id)
ERROR - 2025-12-14 11:49:40 --> Query error: Duplicate key name 'session_token' - Invalid query: CREATE TABLE `chat_sessions` (
	`id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
	`student_id` INT(11) UNSIGNED NOT NULL,
	`resource_id` INT(11) UNSIGNED NOT NULL,
	`session_token` VARCHAR(100) NOT NULL UNIQUE,
	`created_at` TIMESTAMP NOT NULL DEFAULT 'CURRENT_TIMESTAMP',
	`last_activity` TIMESTAMP NOT NULL DEFAULT 'CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP',
	CONSTRAINT `pk_chat_sessions` PRIMARY KEY(`id`),
	KEY `student_id` (`student_id`),
	KEY `resource_id` (`resource_id`),
	KEY `session_token` (`session_token`),
	KEY `last_activity` (`last_activity`)
) DEFAULT CHARACTER SET = utf8 COLLATE = utf8_general_ci
ERROR - 2025-12-14 11:49:40 --> Query error: Invalid default value for 'timestamp' - Invalid query: CREATE TABLE `chat_messages` (
	`id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
	`session_id` INT(11) UNSIGNED NOT NULL,
	`message_type` ENUM('user','assistant') NOT NULL,
	`content` TEXT NOT NULL,
	`timestamp` TIMESTAMP NOT NULL DEFAULT 'CURRENT_TIMESTAMP',
	CONSTRAINT `pk_chat_messages` PRIMARY KEY(`id`),
	KEY `session_id` (`session_id`),
	KEY `timestamp` (`timestamp`)
) DEFAULT CHARACTER SET = utf8 COLLATE = utf8_general_ci
ERROR - 2025-12-14 11:49:40 --> Query error: Table 'college_academic_portal.chat_sessions' doesn't exist - Invalid query: ALTER TABLE chat_sessions ADD CONSTRAINT fk_chat_sessions_student FOREIGN KEY (student_id) REFERENCES students(id)
ERROR - 2025-12-14 11:49:40 --> Query error: Table 'college_academic_portal.chat_sessions' doesn't exist - Invalid query: ALTER TABLE chat_sessions ADD CONSTRAINT fk_chat_sessions_resource FOREIGN KEY (resource_id) REFERENCES resources(id) ON DELETE CASCADE
ERROR - 2025-12-14 11:49:40 --> Query error: Table 'college_academic_portal.chat_messages' doesn't exist - Invalid query: ALTER TABLE chat_messages ADD CONSTRAINT fk_chat_messages_session FOREIGN KEY (session_id) REFERENCES chat_sessions(id) ON DELETE CASCADE
ERROR - 2025-12-14 11:49:40 --> Query error: Duplicate entry 'admin' for key 'users.username' - Invalid query: INSERT INTO `users` (`username`, `email`, `password_hash`, `role`, `created_at`, `is_active`) VALUES ('admin', 'admin@college.edu', '$2y$12$7jPx8sTzTx4wjO99n.riq.fh1mVPVBRqJX/hItIN5bSqMJauSERtC', 'admin', '2025-12-14 11:49:40', 1)
ERROR - 2025-12-14 11:49:40 --> Query error: Unknown column 'is_active' in 'field list' - Invalid query: INSERT INTO `subjects` (`credits`, `is_active`, `semester`, `subject_code`, `subject_name`) VALUES (4,1,1,'CS101','Introduction to Computer Science'), (3,1,1,'MATH101','Calculus I'), (3,1,1,'ENG101','English Composition'), (4,1,2,'CS201','Data Structures'), (3,1,2,'MATH201','Calculus II'), (4,1,3,'CS301','Database Systems'), (4,1,3,'CS302','Software Engineering'), (4,1,4,'CS401','Artificial Intelligence')
ERROR - 2025-12-14 11:49:41 --> Query error: Table 'college_academic_portal.faculty_subjects' doesn't exist - Invalid query: INSERT INTO `faculty_subjects` (`assigned_at`, `faculty_id`, `subject_id`) VALUES ('2025-12-14 11:49:41',2,1), ('2025-12-14 11:49:41',2,4), ('2025-12-14 11:49:41',2,6)
ERROR - 2025-12-14 11:49:41 --> Severity: error --> Exception: Call to undefined method User_model::get_user_by_username() D:\UAI Website\setup_full_system.php 117
ERROR - 2025-12-14 11:49:41 --> Severity: Warning --> include(D:\UAI Website\application\views\errors\cli\error_exception.php): Failed to open stream: No such file or directory D:\UAI Website\system\core\Exceptions.php 220
ERROR - 2025-12-14 11:49:41 --> Severity: Warning --> include(): Failed opening 'D:\UAI Website\application\views\errors\cli\error_exception.php' for inclusion (include_path='.;C:\php\pear') D:\UAI Website\system\core\Exceptions.php 220
ERROR - 2025-12-14 11:51:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2025-12-14 11:59:54 --> 404 Page Not Found: Launcherphp/index
ERROR - 2025-12-14 12:59:47 --> Query error: Unknown column 's.name' in 'field list' - Invalid query: SELECT `r`.*, `s`.`name` as `subject_name`
FROM `resources` `r`
LEFT JOIN `subjects` `s` ON `s`.`id` = `r`.`subject_id`
WHERE `r`.`uploaded_by` = '2'
ORDER BY `r`.`upload_date` DESC
ERROR - 2025-12-14 13:01:14 --> Severity: error --> Exception: Call to undefined method User_model::get_user_by_username() D:\UAI Website\setup_full_system.php 117
ERROR - 2025-12-14 13:01:14 --> Severity: Warning --> include(D:\UAI Website\application\views\errors\cli\error_exception.php): Failed to open stream: No such file or directory D:\UAI Website\system\core\Exceptions.php 220
ERROR - 2025-12-14 13:01:14 --> Severity: Warning --> include(): Failed opening 'D:\UAI Website\application\views\errors\cli\error_exception.php' for inclusion (include_path='.;C:\php\pear') D:\UAI Website\system\core\Exceptions.php 220
ERROR - 2025-12-14 13:01:35 --> Query error: Unknown column 's.name' in 'field list' - Invalid query: SELECT `r`.*, `s`.`name` as `subject_name`
FROM `resources` `r`
LEFT JOIN `subjects` `s` ON `s`.`id` = `r`.`subject_id`
WHERE `r`.`uploaded_by` = '2'
ORDER BY `r`.`upload_date` DESC
ERROR - 2025-12-14 13:03:16 --> Query error: Unknown column 's.name' in 'field list' - Invalid query: SELECT `r`.*, `s`.`name` as `subject_name`
FROM `resources` `r`
LEFT JOIN `subjects` `s` ON `s`.`id` = `r`.`subject_id`
WHERE `r`.`uploaded_by` = '2'
ORDER BY `r`.`upload_date` DESC
ERROR - 2025-12-14 13:12:27 --> Query error: Unknown column 'upload_date' in 'order clause' - Invalid query: SELECT *
FROM `resources`
WHERE `uploaded_by` = '2'
ORDER BY `upload_date` DESC
ERROR - 2025-12-14 13:12:40 --> Query error: Unknown column 'upload_date' in 'order clause' - Invalid query: SELECT *
FROM `resources`
WHERE `uploaded_by` = '2'
ORDER BY `upload_date` DESC
ERROR - 2025-12-14 13:12:54 --> Severity: error --> Exception: Call to undefined method Resource_model::count_resources_by_faculty() D:\UAI Website\application\controllers\Faculty_working.php 35
ERROR - 2025-12-14 18:55:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2025-12-14 18:56:19 --> Query error: Unknown column 'upload_date' in 'order clause' - Invalid query: SELECT *
FROM `resources`
WHERE `uploaded_by` = '2'
ORDER BY `upload_date` DESC
ERROR - 2025-12-14 19:04:51 --> Query error: Unknown column 'name' in 'field list' - Invalid query: INSERT INTO `subjects` (`name`, `code`, `description`) VALUES ('Deep Learning', 'DL1', 'descc')
ERROR - 2025-12-14 19:35:30 --> Query error: Unknown column 'upload_date' in 'order clause' - Invalid query: SELECT *
FROM `resources`
WHERE `uploaded_by` = '2'
ORDER BY `upload_date` DESC
ERROR - 2025-12-14 19:51:47 --> Query error: Unknown column 'name' in 'field list' - Invalid query: INSERT INTO `subjects` (`name`, `code`, `description`) VALUES ('Deep Learning', 'DL1', 'Deep Learning')
ERROR - 2025-12-14 20:11:06 --> Query error: Duplicate entry 'STU001' for key 'students.student_id' - Invalid query: INSERT INTO `students` (`user_id`, `student_id`, `current_semester`, `enrollment_year`) VALUES (7, 'STU001', '2', '2025')
ERROR - 2025-12-14 20:12:40 --> Query error: Duplicate entry 'STU001' for key 'students.student_id' - Invalid query: INSERT INTO `students` (`user_id`, `student_id`, `current_semester`, `enrollment_year`) VALUES (8, 'STU001', '2', '2025')
ERROR - 2025-12-14 20:19:52 --> Severity: error --> Exception: Call to undefined function force_download() D:\UAI Website\application\controllers\Simple_portal.php 636
ERROR - 2025-12-14 20:26:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2025-12-14 20:30:16 --> Gemini API attempt 1 failed: cURL error: SSL certificate problem: unable to get local issuer certificate
ERROR - 2025-12-14 20:30:18 --> Gemini API attempt 2 failed: cURL error: SSL certificate problem: unable to get local issuer certificate
ERROR - 2025-12-14 20:30:20 --> Gemini API attempt 3 failed: cURL error: SSL certificate problem: unable to get local issuer certificate
ERROR - 2025-12-14 20:30:20 --> [AI_SERVICE] AI_API_CONNECTION_FAILED: AI service is temporarily unavailable. Please try again in a few moments.
ERROR - 2025-12-14 20:30:20 --> Severity: Warning --> Undefined array key "error" D:\UAI Website\application\controllers\Simple_portal.php 799
