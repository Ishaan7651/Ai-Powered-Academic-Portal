<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-12-25 06:52:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2025-12-25 06:59:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2025-12-25 07:04:36 --> Query error: Unknown column 's.name' in 'field list' - Invalid query: SELECT `s`.`id`, `s`.`name` as `subject_name`, `s`.`code` as `subject_code`, `s`.`semester`
FROM `subjects` `s`
JOIN `faculty_subjects` `fs` ON `s`.`id` = `fs`.`subject_id`
WHERE `fs`.`faculty_id` = '1'
ERROR - 2025-12-25 07:17:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2025-12-25 07:32:19 --> Severity: error --> Exception: Call to undefined method Resource_model::get_all_resources() D:\Versions\UAI App\Neha's Version\UAI Website\application\controllers\AI_buddy.php 256
ERROR - 2025-12-25 07:32:53 --> Severity: error --> Exception: Call to undefined method Resource_model::get_all_resources() D:\Versions\UAI App\Neha's Version\UAI Website\application\controllers\AI_buddy.php 256
ERROR - 2025-12-25 07:54:08 --> Severity: Warning --> Undefined array key "name" D:\Versions\UAI App\Neha's Version\UAI Website\application\libraries\AI_service.php 700
ERROR - 2025-12-25 07:54:08 --> Severity: Warning --> Undefined array key "name" D:\Versions\UAI App\Neha's Version\UAI Website\application\libraries\AI_service.php 700
ERROR - 2025-12-25 07:54:08 --> Severity: Warning --> Undefined array key "name" D:\Versions\UAI App\Neha's Version\UAI Website\application\libraries\AI_service.php 700
ERROR - 2025-12-25 07:54:27 --> AI response appears truncated. Last char: t, Brace diff: 3, Bracket diff: 2
ERROR - 2025-12-25 07:54:27 --> Invalid JSON from AI - Error: Syntax error
ERROR - 2025-12-25 07:54:27 --> Raw content (first 500 chars): {
  "sections": [
    {
      "section_name": "Section A",
      "section_marks": 20,
      "questions": [
        {
          "question_number": 1,
          "question_text": "Which of the following is NOT an advantage of deep learning over traditional machine learning for patient readmission prediction?",
          "marks": 2,
          "type": "mcq",
          "options": {
            "a": "Automatic Feature Learning",
            "b": "Multimodal Data Integration",
            "c": "Superior
ERROR - 2025-12-25 07:54:27 --> Content bytes: 7b0a20202273656374696f6e73223a205b0a202020207b0a2020202020202273656374696f6e5f6e616d65223a202253656374696f6e2041222c0a2020202020202273656374696f6e5f6d61726b73223a2032302c0a202020202020227175657374696f
ERROR - 2025-12-25 07:54:27 --> Severity: Warning --> Undefined array key "WARNING" D:\Versions\UAI App\Neha's Version\UAI Website\system\core\Log.php 181
ERROR - 2025-12-25 07:54:28 --> Severity: Warning --> Undefined array key "name" D:\Versions\UAI App\Neha's Version\UAI Website\application\libraries\AI_service.php 700
ERROR - 2025-12-25 07:54:28 --> Severity: Warning --> Undefined array key "name" D:\Versions\UAI App\Neha's Version\UAI Website\application\libraries\AI_service.php 700
ERROR - 2025-12-25 07:54:28 --> Severity: Warning --> Undefined array key "name" D:\Versions\UAI App\Neha's Version\UAI Website\application\libraries\AI_service.php 700
ERROR - 2025-12-25 07:54:49 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\Versions\UAI App\Neha's Version\UAI Website\system\core\Exceptions.php:272) D:\Versions\UAI App\Neha's Version\UAI Website\system\core\Common.php 571
ERROR - 2025-12-25 07:54:49 --> Severity: Error --> Maximum execution time of 30 seconds exceeded D:\Versions\UAI App\Neha's Version\UAI Website\application\libraries\AI_service.php 759
ERROR - 2025-12-25 08:16:33 --> Severity: Warning --> Undefined array key "name" D:\Versions\UAI App\Neha's Version\UAI Website\application\libraries\AI_service.php 707
ERROR - 2025-12-25 08:16:33 --> Severity: Warning --> Undefined array key "name" D:\Versions\UAI App\Neha's Version\UAI Website\application\libraries\AI_service.php 707
ERROR - 2025-12-25 08:16:33 --> Severity: Warning --> Undefined array key "name" D:\Versions\UAI App\Neha's Version\UAI Website\application\libraries\AI_service.php 707
ERROR - 2025-12-25 08:17:23 --> Severity: Warning --> Undefined array key "name" D:\Versions\UAI App\Neha's Version\UAI Website\application\libraries\AI_service.php 707
ERROR - 2025-12-25 08:17:23 --> Severity: Warning --> Undefined array key "name" D:\Versions\UAI App\Neha's Version\UAI Website\application\libraries\AI_service.php 707
ERROR - 2025-12-25 08:17:23 --> Severity: Warning --> Undefined array key "name" D:\Versions\UAI App\Neha's Version\UAI Website\application\libraries\AI_service.php 707
ERROR - 2025-12-25 13:22:14 --> Severity: error --> Exception: Unable to locate the model you have specified: User_model C:\Users\nehas\Downloads\UAI Website AI Questions-final\UAI Website\system\core\Loader.php 349
ERROR - 2025-12-25 14:52:01 --> Severity: Warning --> mysqli::__construct(): (HY000/2002): No connection could be made because the target machine actively refused it C:\Users\nehas\Downloads\UAI Website AI Questions-final\UAI Website\application\views\simple_portal\admin_dashboard.php 11
ERROR - 2025-12-25 14:52:36 --> Severity: Warning --> mysqli::__construct(): (HY000/2002): No connection could be made because the target machine actively refused it C:\Users\nehas\Downloads\UAI Website AI Questions-final\UAI Website\application\views\simple_portal\admin_dashboard.php 11
ERROR - 2025-12-25 14:55:47 --> Severity: Warning --> mysqli::__construct(): (HY000/2002): No connection could be made because the target machine actively refused it C:\Users\nehas\Downloads\UAI Website AI Questions-final\UAI Website\application\views\simple_portal\admin_dashboard.php 11
ERROR - 2025-12-25 15:13:43 --> Severity: Notice --> session_start(): Ignoring session_start() because a session is already active C:\Users\nehas\Downloads\UAI Website AI Questions-final\UAI Website\application\views\simple_portal\admin_dashboard.php 11
ERROR - 2025-12-25 15:13:47 --> Severity: Warning --> mysqli::__construct(): (HY000/2002): No connection could be made because the target machine actively refused it C:\Users\nehas\Downloads\UAI Website AI Questions-final\UAI Website\application\views\simple_portal\admin_dashboard.php 22
ERROR - 2025-12-25 15:19:36 --> Severity: Notice --> session_start(): Ignoring session_start() because a session is already active C:\Users\nehas\Downloads\UAI Website AI Questions-final\UAI Website\application\views\simple_portal\admin_dashboard.php 3
ERROR - 2025-12-25 15:19:40 --> Severity: Warning --> mysqli::__construct(): (HY000/2002): No connection could be made because the target machine actively refused it C:\Users\nehas\Downloads\UAI Website AI Questions-final\UAI Website\application\views\simple_portal\admin_dashboard.php 14
ERROR - 2025-12-25 15:33:34 --> Severity: Notice --> session_start(): Ignoring session_start() because a session is already active C:\Users\nehas\Downloads\UAI Website AI Questions-final\UAI Website\application\views\simple_portal\admin_dashboard.php 3
ERROR - 2025-12-25 15:33:39 --> Severity: Warning --> mysqli::__construct(): (HY000/2002): No connection could be made because the target machine actively refused it C:\Users\nehas\Downloads\UAI Website AI Questions-final\UAI Website\application\views\simple_portal\admin_dashboard.php 14
ERROR - 2025-12-25 15:33:54 --> Severity: Notice --> session_start(): Ignoring session_start() because a session is already active C:\Users\nehas\Downloads\UAI Website AI Questions-final\UAI Website\application\views\simple_portal\admin_dashboard.php 3
ERROR - 2025-12-25 15:33:58 --> Severity: Warning --> mysqli::__construct(): (HY000/2002): No connection could be made because the target machine actively refused it C:\Users\nehas\Downloads\UAI Website AI Questions-final\UAI Website\application\views\simple_portal\admin_dashboard.php 14
ERROR - 2025-12-25 15:38:28 --> Severity: Warning --> mysqli::__construct(): (HY000/2002): No connection could be made because the target machine actively refused it C:\Users\nehas\Downloads\UAI Website AI Questions-final\UAI Website\application\views\simple_portal\admin_dashboard.php 21
ERROR - 2025-12-25 15:41:59 --> Query error: Duplicate entry 'ravi@123' for key 'email' - Invalid query: INSERT INTO `users` (`username`, `email`, `password_hash`, `role`, `is_active`) VALUES ('ravii', 'ravi@123', '$2y$10$EWl4TRCSTjQix7kPnMRWquuVMzmV9ZVhX2U7TS3sw7yzJ2z3/01rC', 'faculty', 1)
ERROR - 2025-12-25 18:57:33 --> Severity: error --> Exception: Call to undefined method Simple_portal::get_subjects() C:\Users\nehas\Downloads\UAI Website AI Questions-final\UAI Website\application\controllers\Simple_portal.php 512
ERROR - 2025-12-25 18:58:04 --> Severity: error --> Exception: Call to undefined method Simple_portal::get_subjects() C:\Users\nehas\Downloads\UAI Website AI Questions-final\UAI Website\application\controllers\Simple_portal.php 512
ERROR - 2025-12-25 19:11:33 --> Severity: error --> Exception: Call to undefined method Simple_portal::get_subjects() C:\Users\nehas\Downloads\UAI Website AI Questions-final\UAI Website\application\controllers\Simple_portal.php 512
ERROR - 2025-12-25 19:11:46 --> Severity: error --> Exception: Call to undefined method Simple_portal::get_subjects() C:\Users\nehas\Downloads\UAI Website AI Questions-final\UAI Website\application\controllers\Simple_portal.php 512
ERROR - 2025-12-25 19:12:01 --> 404 Page Not Found: Ai_buddy/ai_chat
ERROR - 2025-12-25 19:12:04 --> 404 Page Not Found: Simple_portal/my_students
ERROR - 2025-12-25 19:12:17 --> Severity: error --> Exception: Call to undefined method Simple_portal::get_subjects() C:\Users\nehas\Downloads\UAI Website AI Questions-final\UAI Website\application\controllers\Simple_portal.php 512
ERROR - 2025-12-25 19:12:49 --> Severity: error --> Exception: Call to undefined method Simple_portal::get_subjects() C:\Users\nehas\Downloads\UAI Website AI Questions-final\UAI Website\application\controllers\Simple_portal.php 512
ERROR - 2025-12-25 19:29:45 --> 404 Page Not Found: Simple_portal/faculty_dashboard
ERROR - 2025-12-25 19:30:41 --> 404 Page Not Found: Simple_portal/my_students
ERROR - 2025-12-25 20:11:28 --> 404 Page Not Found: Simple_portal/profile
ERROR - 2025-12-25 20:30:04 --> Query error: Unknown column 'aq.subject_id' in 'on clause' - Invalid query: 
            (
                SELECT 
                    aq.id,
                    aq.title,
                    CONCAT('Created quiz: ', aq.title) as description,
                    s.subject_name,
                    aq.created_at,
                    'ai' as type,
                    'question-circle' as icon
                FROM ai_quizzes aq
                LEFT JOIN subjects s ON aq.subject_id = s.id
                WHERE aq.user_id = '12'
                ORDER BY aq.created_at DESC
                LIMIT 2
            )
            UNION ALL
            (
                SELECT 
                    aqp.id,
                    aqp.title,
                    CONCAT('Generated paper: ', aqp.title) as description,
                    s.subject_name,
                    aqp.created_at,
                    'ai' as type,
                    'file-alt' as icon
                FROM ai_question_papers aqp
                LEFT JOIN subjects s ON aqp.subject_id = s.id
                WHERE aqp.user_id = '12'
                ORDER BY aqp.created_at DESC
                LIMIT 2
            )
            ORDER BY created_at DESC
            LIMIT 4
        
ERROR - 2025-12-25 20:33:55 --> 404 Page Not Found: Ai_buddy/ai_chat
ERROR - 2025-12-25 20:33:59 --> 404 Page Not Found: Simple_portal/my_students
ERROR - 2025-12-25 21:08:10 --> 404 Page Not Found: Simple_portal/faculty_dashboard
