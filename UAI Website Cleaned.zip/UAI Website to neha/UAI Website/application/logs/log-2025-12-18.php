<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-12-18 11:11:14 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it C:\Users\nehas\Downloads\UAI Website Simple Portal\UAI Website\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2025-12-18 11:11:14 --> Unable to connect to the database
ERROR - 2025-12-18 11:33:04 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it C:\Users\nehas\Downloads\UAI Website Simple Portal\UAI Website\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2025-12-18 11:33:04 --> Unable to connect to the database
ERROR - 2025-12-18 11:33:22 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it C:\Users\nehas\Downloads\UAI Website Simple Portal\UAI Website\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2025-12-18 11:33:22 --> Unable to connect to the database
