<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2026-01-08 18:28:21 --> Severity: error --> Exception: Call to undefined method Faculty_model::get_assigned_subjects() C:\Users\nehas\Downloads\UAI Website to neha\UAI Website\application\controllers\Simple_portal.php 2936
ERROR - 2026-01-08 18:38:44 --> AI CHAT DEBUG: Starting chat with 1 messages, system_prompt: YES
ERROR - 2026-01-08 18:38:44 --> AI CHAT DEBUG: Added system prompt, length: 163
ERROR - 2026-01-08 18:38:44 --> AI CHAT DEBUG: Message 0 is object, role: user, has content: YES
ERROR - 2026-01-08 18:38:44 --> AI CHAT DEBUG: Added message 0 to formatted_messages
ERROR - 2026-01-08 18:38:44 --> AI CHAT DEBUG: Total formatted messages: 2
ERROR - 2026-01-08 18:38:44 --> AI API DEBUG: Received 2 messages to process
ERROR - 2026-01-08 18:38:44 --> AI API DEBUG: Found system message, length: 163
ERROR - 2026-01-08 18:38:44 --> AI API DEBUG: Added user message, length: 32
ERROR - 2026-01-08 18:38:44 --> AI API DEBUG: After initial processing, contents count: 1
ERROR - 2026-01-08 18:38:44 --> AI API DEBUG: After filtering, contents count: 1
ERROR - 2026-01-08 18:38:44 --> AI API DEBUG: Prepended system instruction. Original: 32, New: 197
ERROR - 2026-01-08 18:38:44 --> AI API DEBUG: Final contents count before sending: 1
ERROR - 2026-01-08 18:38:44 --> AI API DEBUG: Contents structure: [{"role":"user","text_length":197}]
ERROR - 2026-01-08 18:38:44 --> AI API DEBUG: Data structure to send: {"contents_count":1}
ERROR - 2026-01-08 18:38:44 --> AI API DEBUG: JSON encode error code: 0
ERROR - 2026-01-08 18:38:44 --> AI API DEBUG: JSON payload length: 326
ERROR - 2026-01-08 18:38:44 --> AI API DEBUG: JSON payload (first 1000 chars): {"contents":[{"role":"user","parts":[{"text":"You are an AI teaching assistant helping with educational content.\n\nNote: No specific document context is available. Please provide general educational assistance.\n\nGive me the summary of this file"}]}],"generationConfig":{"temperature":0.3,"maxOutputTokens":8000,"topP":0.8}}
ERROR - 2026-01-08 18:38:44 --> AI API DEBUG: Raw contents array count: 1
ERROR - 2026-01-08 18:38:44 --> AI API DEBUG: First content item: {"role":"user","parts":[{"text":"You are an AI teaching assistant helping with educational content.\n\nNote: No specific document context is available. Please provide general educational assistance.\n\nGive me the summary of this file"}]}
ERROR - 2026-01-08 18:39:14 --> AI Chat: Found resource file: uploads/resources/resource_1766645681_694cdfb12b250.pdf, type: pdf
ERROR - 2026-01-08 18:39:14 --> AI Chat: Calling AI service PDF extraction
ERROR - 2026-01-08 18:39:14 --> PDF EXTRACTION: Starting extraction for: C:\Users\nehas\Downloads\UAI Website to neha\UAI Website\uploads/resources/resource_1766645681_694cdfb12b250.pdf
ERROR - 2026-01-08 18:39:14 --> PDF EXTRACTION: Checking for vendor autoload at: C:\Users\nehas\Downloads\UAI Website to neha\UAI Website\vendor/autoload.php
ERROR - 2026-01-08 18:39:14 --> PDF EXTRACTION: Vendor autoload exists: YES
ERROR - 2026-01-08 18:39:15 --> PDF EXTRACTION: Vendor autoload loaded successfully
ERROR - 2026-01-08 18:39:15 --> PDF EXTRACTION: Creating Smalot parser instance
ERROR - 2026-01-08 18:39:15 --> PDF EXTRACTION: Parsing file...
ERROR - 2026-01-08 18:39:16 --> PDF EXTRACTION: Extracting text...
ERROR - 2026-01-08 18:39:18 --> PDF EXTRACTION: Raw text length: 25602
ERROR - 2026-01-08 18:39:18 --> PDF EXTRACTION: First 200 chars: Neural Networks Assignment  
Assignment: Deep Learning -- Neural Networks 
1. Deep Learning in Action  
Question: A healthcare startup wants to predict patient readmission risk using historical data. 
ERROR - 2026-01-08 18:39:18 --> PDF EXTRACTION: Success! Cleaning text...
ERROR - 2026-01-08 18:39:18 --> PDF EXTRACTION: Cleaned text length: 25124
ERROR - 2026-01-08 18:39:18 --> AI Chat: PDF extraction returned 25124 characters
ERROR - 2026-01-08 18:39:18 --> AI CHAT DEBUG: Starting chat with 1 messages, system_prompt: YES
ERROR - 2026-01-08 18:39:18 --> AI CHAT DEBUG: Added system prompt, length: 3086
ERROR - 2026-01-08 18:39:18 --> AI CHAT DEBUG: Message 0 is object, role: user, has content: YES
ERROR - 2026-01-08 18:39:18 --> AI CHAT DEBUG: Added message 0 to formatted_messages
ERROR - 2026-01-08 18:39:18 --> AI CHAT DEBUG: Total formatted messages: 2
ERROR - 2026-01-08 18:39:18 --> AI API DEBUG: Received 2 messages to process
ERROR - 2026-01-08 18:39:18 --> AI API DEBUG: Found system message, length: 3086
ERROR - 2026-01-08 18:39:18 --> AI API DEBUG: Added user message, length: 32
ERROR - 2026-01-08 18:39:18 --> AI API DEBUG: After initial processing, contents count: 1
ERROR - 2026-01-08 18:39:18 --> AI API DEBUG: After filtering, contents count: 1
ERROR - 2026-01-08 18:39:18 --> AI API DEBUG: Prepended system instruction. Original: 32, New: 3120
ERROR - 2026-01-08 18:39:18 --> AI API DEBUG: Final contents count before sending: 1
ERROR - 2026-01-08 18:39:18 --> AI API DEBUG: Contents structure: [{"role":"user","text_length":3120}]
ERROR - 2026-01-08 18:39:18 --> AI API DEBUG: Data structure to send: {"contents_count":1}
ERROR - 2026-01-08 18:39:18 --> AI API DEBUG: JSON encode error code: 0
ERROR - 2026-01-08 18:39:18 --> AI API DEBUG: JSON payload length: 3251
ERROR - 2026-01-08 18:39:18 --> AI API DEBUG: JSON payload (first 1000 chars): {"contents":[{"role":"user","parts":[{"text":"You are an AI teaching assistant helping with educational content.\n\nDocument Context:\nNeural Networks Assignment Assignment: Deep Learning -- Neural Networks 1. Deep Learning in Action Question: A healthcare startup wants to predict patient readmission risk using historical data. How can deep learning be applied in this scenario? What advantages does it offer over traditional machine learning? Answer: Deep learning can be applied to patient readmission prediction through several approaches: Application Methods: • Multi-layered Neural Networks: Process complex patient data including demographics, medical history, vital signs, lab results, and discharge summaries to identify patterns predictive of readmission risk • Recurrent Neural Networks (RNNs\/LSTMs): Handle temporal sequences of patient data, capturing how patient conditions evolve over time during hospitalization • Natural Language Processing: Analyze unstructured clinical not
ERROR - 2026-01-08 18:39:18 --> AI API DEBUG: Raw contents array count: 1
ERROR - 2026-01-08 18:39:18 --> AI API DEBUG: First content item: {"role":"user","parts":[{"text":"You are an AI teaching assistant helping with educational content.\n\nDocument Context:\nNeural Networks Assignment Assignment: Deep Learning -- Neural Networks 1. Deep Learning in Action Question: A healthcare startup wants to predict patient readmission risk using historical data. How can deep learning be applied in this scenario? What advantages does it offer over traditional machine learning? Answer: Deep learning can be applied to patient readmission prediction through several approaches: Application Methods: \u2022 Multi-layered Neural Networks: Process complex patient data including demographics, medical history, vital signs, lab results, and discharge summaries to identify patterns predictive of readmission risk \u2022 Recurrent Neural Networks (RNNs\/LSTMs): Handle temporal sequences of patient data, capturing how patient conditions evolve over time during hospitalization \u2022 Natural Language Processing: Analyze unstructured clinical notes and discharge summaries to extract relevant biomedical concepts that traditional methods might miss \u2022 Ensemble Deep Learning: Combine multiple neural network architectures to improve prediction accuracy and robustness Advantages over Traditional Machine Learning: 1. Automatic Feature Learning: Deep learning automatically discovers complex patterns and interactions in patient data without requiring manual feature engineering, which is particularly valuable given the high-dimensional nature of medical data 2. Handling Complex Relationships: Can model non-linear relationships between multiple variables (e.g., interactions between medications, comorbidities, and patient demographics) that traditional linear models struggle to capture 3. Multimodal Data Integration: Effectively processes diverse data types simultaneously - structured data (lab values, vital signs), unstructured text (clinical notes), and temporal sequences (treatment timelines) 4. Superior Performance on Large Datasets: Research shows deep learning models achieve higher accuracy (94% recall, 75% AUC) compared to traditional methods when sufficient data is available 5. Continuous Learning: Can adapt to new patterns and evolving medical practices by retraining on updated datasets 6. Handling Missing Data: More robust to incomplete patient records, which are common in healthcare settings 2. Neural Network Mechanics Question: You're designing a neural network to classify handwritten digits (0\u20139). Describe how the network processes input from pixel data to output predictions. Include the role of layers and weights. Answer: Network Architecture for Digit Classification: Input Processing: \u2022 Input layer receives 784 neurons (28\u00d728 pixel values) representing grayscale intensities (0-255, normalized to 0-1) \u2022 Each pixel value serves as a feature representing local image characteristics Layer-by-Layer Processing: 1. Hidden Layers: o First Hidden Layer: Detects basic features like edges, curves, and orientations o Deeper Hidden Layers: Combine simple features into complex patterns (loops, straight lines, intersections) o Each neuron comp\n\nGive me the summary of this file"}]}
