<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-12-24 08:18:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2025-12-24 08:58:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2025-12-24 09:00:21 --> Severity: error --> Exception: Unable to locate the model you have specified: Assignment_model D:\Versions\UAI App\Neha's Version\UAI Website\system\core\Loader.php 349
ERROR - 2025-12-24 09:00:50 --> Severity: error --> Exception: Unable to locate the model you have specified: Assignment_model D:\Versions\UAI App\Neha's Version\UAI Website\system\core\Loader.php 349
ERROR - 2025-12-24 09:05:10 --> Severity: error --> Exception: Unable to locate the model you have specified: Assignment_model D:\Versions\UAI App\Neha's Version\UAI Website\system\core\Loader.php 349
ERROR - 2025-12-24 09:05:16 --> Severity: error --> Exception: Unable to locate the model you have specified: Assignment_model D:\Versions\UAI App\Neha's Version\UAI Website\system\core\Loader.php 349
ERROR - 2025-12-24 09:05:20 --> Severity: error --> Exception: Unable to locate the model you have specified: User_model D:\Versions\UAI App\Neha's Version\UAI Website\system\core\Loader.php 349
ERROR - 2025-12-24 12:48:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2025-12-24 13:08:12 --> 404 Page Not Found: Simple_portal/faculty_dashboard
ERROR - 2025-12-24 13:09:57 --> 404 Page Not Found: Simple_portal/student_dashboard
ERROR - 2025-12-24 13:21:05 --> Severity: Warning --> Undefined array key "WARNING" D:\Versions\UAI App\Neha's Version\UAI Website\system\core\Log.php 181
ERROR - 2025-12-24 20:15:36 --> Smalot PDF parser error: Invalid PDF data: Missing `%PDF-` header.
ERROR - 2025-12-24 20:15:36 --> Severity: error --> Exception: Call to undefined method AI_service::decode_pdf_string() D:\Versions\UAI App\Neha's Version\UAI Website\application\libraries\AI_service.php 261
ERROR - 2025-12-24 20:15:36 --> Severity: Warning --> include(D:\Versions\UAI App\Neha's Version\UAI Website\application\views\errors\cli\error_exception.php): Failed to open stream: No such file or directory D:\Versions\UAI App\Neha's Version\UAI Website\system\core\Exceptions.php 220
ERROR - 2025-12-24 20:15:36 --> Severity: Warning --> include(): Failed opening 'D:\Versions\UAI App\Neha's Version\UAI Website\application\views\errors\cli\error_exception.php' for inclusion (include_path='.;C:\php\pear') D:\Versions\UAI App\Neha's Version\UAI Website\system\core\Exceptions.php 220
ERROR - 2025-12-24 20:30:03 --> 404 Page Not Found: Simple_portal/student_dashboard
ERROR - 2025-12-24 20:30:54 --> 404 Page Not Found: Simple_portal/student_dashboard
ERROR - 2025-12-24 20:37:07 --> 404 Page Not Found: Simple_portal/student_dashboard
ERROR - 2025-12-24 20:37:09 --> 404 Page Not Found: Simple_portal/student_dashboard
ERROR - 2025-12-24 20:37:15 --> 404 Page Not Found: Simple_portal/student_dashboard
ERROR - 2025-12-24 20:40:22 --> 404 Page Not Found: Simple_portal/student_dashboard
ERROR - 2025-12-24 20:40:42 --> 404 Page Not Found: Simple_portal/student_dashboard
